# Zrill AI v5.6 — Native Market Reasoning

This release strengthens the local/native reasoning layer without adding GPT, Gemini, or another AI model.

## Decision architecture

1. Validate authoritative TradingView feed.
2. Observe H4/H1/M15/M5 structure and market regime.
3. Build independent BUY and SELL hypotheses.
4. Evaluate liquidity sweep, displacement, structure, location and MTF alignment.
5. Evaluate USD macro events using Actual/Forecast/Previous when available.
6. Optionally confirm with live TradingView DXY and US10Y percentage change.
7. Run an adversarial check: search for evidence that invalidates the leading hypothesis.
8. Apply bounded native learning from realized TP/SL/reversal outcomes.
9. Decide only when directional evidence is sufficiently separated; otherwise NO_VALID_SETUP.

## Fundamental safety

- Missing DXY/US10Y data is neutral, never synthesized.
- Fundamental context cannot create a trade without technical structure.
- Confidence is evidence quality, not a win-rate probability.
- Pre-release logic never uses Actual before release.
- Actual-vs-Forecast is treated as a surprise signal; Forecast-vs-Previous is only a weaker expectation signal.

## Cross-asset symbols

- DXY: `TVC:DXY`
- US10Y: `TVC:US10Y`

If those feeds are unavailable, Zrill continues with neutral cross-asset evidence rather than fake values.
