# Zrill AI v5.5 — Native Cognitive Learning

Zrill v5.5 remains independent of GPT/Gemini/other external AI models for its reasoning path. It adds an online learning layer that updates bounded local weights from **realized signal outcomes**.

## Cognitive loop

LIVE DATA → OBSERVE → BUILD BUY/SELL HYPOTHESES → COUNTER-CHECK → CONFLICT RESOLUTION → DECISION → OUTCOME → LOCAL WEIGHT UPDATE → NEXT OBSERVATION

The engine now maintains:
- bounded feature weights
- sample count / win-loss count
- feature statistics
- learned fit for BUY and SELL hypotheses
- persistent model state in `data/zrill-native-learning.json`

Learning is deliberately conservative. It cannot create a trade by itself: structural requirements such as liquidity sweep, displacement, sufficient evidence and non-consolidation remain mandatory.

## Real training

Training begins only from actual closed outcomes. The server feeds TP, SL, confirmed reversal and stale/no-trade outcomes back into the native learner. No synthetic outcomes or hard-coded 100% accuracy are inserted.

This is autonomous software learning, not human consciousness. The system does not claim subjective awareness or genuine emotions. `emotionalState` is a behavioral state representing uncertainty, conflict and risk.

## Deployment

No external AI API key is required for the native reasoning/learning path. Google AI Studio only runs the application. TradingView remains the authoritative market feed.


## v5.6 Native Market Reasoning

Zrill now performs a multi-pass native decision process for technical + fundamental analysis without calling GPT/Gemini. Fundamental reasoning uses the real economic-calendar values (Actual/Forecast/Previous when available) and optional live TradingView DXY/US10Y confirmation. Cross-asset data is secondary evidence only; missing data is treated as neutral, never synthesized.

The engine evaluates both BUY and SELL hypotheses, performs an adversarial invalidation check, and only then makes a directional decision. Confidence is evidence quality, not a win-rate probability.
