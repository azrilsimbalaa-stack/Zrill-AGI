# Zrill AI — TradingView Market Brain v5

Signal path is fail-closed and uses the same TradingView market source for chart/signal OHLC:

TradingView realtime quote + TradingView M1/M5/M15/H1/H4/D1 OHLC
→ feed integrity validation
→ closed-candle isolation
→ volatility/regime engine
→ H4/H1 structure alignment
→ M15 pivot liquidity sweep
→ displacement + MSS/BOS close confirmation
→ fresh OB/FVG confluence
→ independent M5 confirmation
→ Forex Factory high-impact USD news filter
→ structural SL
→ opposing H1 structural target
→ RR >= 1:2
→ immutable market signal

Additional protections:
- No Binance/PAXG candle fallback for signal generation.
- No synthetic/random price or candle fallback.
- Each timeframe has its own TradingView dataset.
- Missing, invalid, non-monotonic, or stale candles produce FEED_RECOVERY.
- Consolidation/range blocks signal generation.
- HTF neutral/misaligned blocks signal generation.
- Score never forces a direction.
- Entry/SL/TP are locked at creation.
- Active signals are persisted to `data/zrill-signal-state.json` and restored on restart when valid.
- TP/SL/reversal/stale lifecycle remains authoritative in `server.ts`.
