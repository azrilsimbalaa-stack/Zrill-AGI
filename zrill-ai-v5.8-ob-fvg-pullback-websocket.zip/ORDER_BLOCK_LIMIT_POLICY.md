# Zrill v5.8 Strong Order Block / FVG Limit Policy

UI is intentionally untouched.

- Bullish market direction -> BUY LIMIT only.
- Bearish market direction -> SELL LIMIT only.
- Strong same-direction Order Block -> pending limit at OB equilibrium.
- If no strong OB exists, strong same-direction FVG may be used.
- OB has priority over FVG.
- No strong aligned OB/FVG -> NO SIGNAL.
- Counter-direction zones are ignored.
- No BOS/CHOCH/liquidity-sweep/candle confirmation is required for the pending-order decision.
- Fibonacci, SNR, generic supply/demand and other fallback zones cannot manufacture a pending signal.
- WebSocket realtime feed remains the realtime market-data path.
