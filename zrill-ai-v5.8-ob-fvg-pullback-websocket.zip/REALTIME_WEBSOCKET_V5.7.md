# Zrill AI v5.7 — Realtime WebSocket

- Upstream TradingView quote feed remains a persistent WebSocket connection.
- Zrill server exposes a browser WebSocket gateway at `/ws/market`.
- Browser receives price ticks immediately when the upstream feed updates.
- Browser reconnects automatically after disconnects.
- Server heartbeat detects dead browser connections.
- No fake prices are generated.
- Stale/invalid feed is not treated as live.
- Historical candle requests remain throttled HTTP requests to avoid TradingView 429 bursts.
- The reasoning/signal lifecycle is unchanged: locked signals are not mutated by UI refreshes.

Google AI Studio / Cloud Run should expose the same HTTP server and WebSocket upgrade path. Use `wss://<host>/ws/market` from HTTPS deployments; the frontend selects `ws:` or `wss:` automatically.
