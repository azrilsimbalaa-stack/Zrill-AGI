// Web Worker for asynchronous, non-blocking Smart Money Concepts (SMC) & ICT analysis

let prevFirstBarTime: any = null;
let cachedConfirmedSwings: any[] = [];
let prevBarCount = 0;

self.onmessage = (event: MessageEvent) => {
  const { id, data } = event.data;
  if (!data || !Array.isArray(data)) {
    self.postMessage({ id, result: null });
    return;
  }

  const result = analyzeSMCInWorker(data);
  self.postMessage({ id, result });
};

function analyzeSMCInWorker(data: any[]) {
  const emptyResult = {
    markers: [],
    drawings: {
      bullishFVG: null,
      bearishFVG: null,
      ob: null,
      sd: null,
      support: null,
      resistance: null,
      bos: null,
      choch: null,
      ibos: null,
      sweep: null,
      trendlines: { support: null, resistance: null },
    },
    state: {
      trend: "SIDEWAYS",
      lastStruct: "NONE",
      fvg: "NONE",
      ob: "NONE",
      sweep: "NONE",
      recentStructures: [] as any[],
      bos: "NONE",
      choch: "NONE",
      patterns: [] as any[],
      sentiment: { buy: 50, sell: 50 },
    },
  };

  if (!data || data.length < 50) return emptyResult;

  const markers: any[] = [];

  // Optimized range calculation over recent window
  const recentSlice = data.slice(-200);
  const totalRange =
    Math.max(...recentSlice.map((d) => d.high)) - Math.min(...recentSlice.map((d) => d.low));

  const leftBars = 10;
  const rightBars = 5;

  // Incremental processing: detect symbol/timeframe switches and maintain swing cache
  const firstBarTime = data[0]?.time;
  if (firstBarTime !== prevFirstBarTime || data.length < prevBarCount - 5) {
    cachedConfirmedSwings = [];
  }
  prevFirstBarTime = firstBarTime;
  prevBarCount = data.length;

  // Process only recent 120 bars incrementally on tick updates
  const windowStart = Math.max(leftBars, data.length - 120);
  const confirmedSwings = cachedConfirmedSwings.filter((s) => s.index < windowStart);

  let newSwings: any[] = [];
  for (let i = windowStart; i < data.length - rightBars; i++) {
    let isHigh = true;
    let isLow = true;
    for (let j = 1; j <= leftBars; j++) {
      if (data[i - j].high >= data[i].high) isHigh = false;
      if (data[i - j].low <= data[i].low) isLow = false;
    }
    for (let j = 1; j <= rightBars; j++) {
      if (data[i + j].high >= data[i].high) isHigh = false;
      if (data[i + j].low <= data[i].low) isLow = false;
    }
    if (isHigh)
      newSwings.push({
        type: "High",
        index: i,
        price: data[i].high,
        time: data[i].time,
      });
    if (isLow)
      newSwings.push({
        type: "Low",
        index: i,
        price: data[i].low,
        time: data[i].time,
      });
  }

  const swings = [...confirmedSwings, ...newSwings];
  cachedConfirmedSwings = swings;

  let filteredSwings: any[] = [];
  let lastType = "";
  for (let s of swings) {
    if (s.type !== lastType) {
      filteredSwings.push(s);
      lastType = s.type;
    } else {
      if (
        s.type === "High" &&
        s.price > filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      } else if (
        s.type === "Low" &&
        s.price < filteredSwings[filteredSwings.length - 1].price
      ) {
        filteredSwings[filteredSwings.length - 1] = s;
      }
    }
  }

  let structure = [];
  let lastHigh = null;
  let lastLow = null;
  let trend = "SIDEWAYS";

  for (let i = 0; i < filteredSwings.length; i++) {
    let s = filteredSwings[i];
    if (s.type === "High") {
      if (lastHigh === null) {
        s.label = "High";
      } else if (s.price > lastHigh.price) {
        s.label = "HH";
      } else {
        s.label = "LH";
      }
      lastHigh = s;
    } else {
      if (lastLow === null) {
        s.label = "Low";
      } else if (s.price > lastLow.price) {
        s.label = "HL";
      } else {
        s.label = "LL";
      }
      lastLow = s;
    }
    structure.push(s);
  }

  if (structure.length >= 4) {
    const last4 = structure.slice(-4).map((s) => s.label);
    if (last4.includes("HH") && last4.includes("HL")) trend = "BULLISH";
    else if (last4.includes("LH") && last4.includes("LL")) trend = "BEARISH";
    else trend = "SIDEWAYS";
  }

  const recentStructs = structure.slice(-15);
  for (let s of recentStructs) {
    markers.push({
      time: s.time,
      position: s.type === "High" ? "aboveBar" : "belowBar",
      color: s.type === "High" ? "#ef4444" : "#10b981",
      shape: s.type === "High" ? "arrowDown" : "arrowUp",
      text: "",
      size: 1,
    });
  }

  const lastTime = data[data.length - 1].time;
  const extendedTime = lastTime + 3600 * 24;

  let bullishFVG = null;
  let bearishFVG = null;
  for (let i = data.length - 25; i < data.length - 1; i++) {
    if (i < 2) continue;
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    const atr = Math.abs(c2.high - c2.low);

    if (
      c1.high < c3.low &&
      c2.close > c2.open &&
      c3.low - c1.high > atr * 0.15
    ) {
      bullishFVG = {
        type: "BULLISH",
        time: c2.time,
        top: c3.low,
        bottom: c1.high,
        endTime: extendedTime,
      };
    }
    if (
      c1.low > c3.high &&
      c2.close < c2.open &&
      c1.low - c3.high > atr * 0.15
    ) {
      bearishFVG = {
        type: "BEARISH",
        time: c2.time,
        top: c1.low,
        bottom: c3.high,
        endTime: extendedTime,
      };
    }
  }

  let lastOB = null;
  for (let i = data.length - 30; i < data.length - 1; i++) {
    const c1 = data[i - 2];
    const c2 = data[i - 1];
    const c3 = data[i];
    if (!c1 || !c2 || !c3) continue;

    let ob = null;
    if (
      c1.close < c1.open &&
      c2.close > c2.open &&
      c3.close > c3.open &&
      c3.close - c2.open > (c1.open - c1.close) * 2
    ) {
      ob = {
        type: "BULLISH",
        time: c1.time,
        top: c1.open,
        bottom: c1.low,
        endTime: extendedTime,
        mitigated: false,
      };
    }
    if (
      c1.close > c1.open &&
      c2.close < c2.open &&
      c3.close < c3.open &&
      c2.open - c3.close > (c1.close - c1.open) * 2
    ) {
      ob = {
        type: "BEARISH",
        time: c1.time,
        top: c1.high,
        bottom: c1.open,
        endTime: extendedTime,
        mitigated: false,
      };
    }

    if (ob) {
      for (let j = i + 1; j < data.length; j++) {
        const testC = data[j];
        if (ob.type === "BULLISH" && testC.low <= ob.top) {
          ob.mitigated = true;
          (ob as any).mitigationTime = testC.time;
          break;
        }
        if (ob.type === "BEARISH" && testC.high >= ob.bottom) {
          ob.mitigated = true;
          (ob as any).mitigationTime = testC.time;
          break;
        }
      }
      lastOB = ob;
    }
  }

  let lastSD = null;
  for (let i = data.length - 30; i < data.length - 5; i++) {
    const range = data.slice(i, i + 5);
    const high = Math.max(...range.map((d) => d.high));
    const low = Math.min(...range.map((d) => d.low));
    const bodySize = Math.abs(high - low);

    const nextCandle = data[i + 5];
    if (nextCandle.close > high + bodySize) {
      lastSD = {
        type: "DEMAND",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    } else if (nextCandle.close < low - bodySize) {
      lastSD = {
        type: "SUPPLY",
        time: data[i].time,
        top: high,
        bottom: low,
        endTime: extendedTime,
      };
    }
  }

  const lastCandle = data[data.length - 1];
  let sweep = null;
  const recentHighs = swings.filter((s) => s.type === "High").slice(-5);
  const recentLows = swings.filter((s) => s.type === "Low").slice(-5);

  for (let h of recentHighs) {
    if (lastCandle.high > h.price && lastCandle.close < h.price) {
      sweep = {
        type: "BEARISH",
        price: h.price,
        time: lastCandle.time,
      };
      markers.push({
        time: lastCandle.time,
        position: "aboveBar",
        color: "#f59e0b",
        shape: "circle",
        text: "",
        size: 1,
      });
      break;
    }
  }
  if (!sweep) {
    for (let l of recentLows) {
      if (lastCandle.low < l.price && lastCandle.close > l.price) {
        sweep = {
          type: "BULLISH",
          price: l.price,
          time: lastCandle.time,
        };
        markers.push({
          time: lastCandle.time,
          position: "belowBar",
          color: "#f59e0b",
          shape: "circle",
          text: "",
          size: 1,
        });
        break;
      }
    }
  }

  let bos = null;
  let choch = null;
  if (structure.length >= 2) {
    const lastSwing = structure[structure.length - 1];
    const prevSameType = structure
      .slice(0, -1)
      .reverse()
      .find((s) => s.type === lastSwing.type);

    if (prevSameType) {
      if (lastSwing.type === "High" && lastCandle.close > prevSameType.price) {
        if (trend === "BEARISH") {
          choch = {
            type: "BULLISH",
            price: prevSameType.price,
            time: lastCandle.time,
          };
        } else {
          bos = {
            type: "BULLISH",
            price: prevSameType.price,
            time: lastCandle.time,
          };
        }
      } else if (
        lastSwing.type === "Low" &&
        lastCandle.close < prevSameType.price
      ) {
        if (trend === "BULLISH") {
          choch = {
            type: "BEARISH",
            price: prevSameType.price,
            time: lastCandle.time,
          };
        } else {
          bos = {
            type: "BEARISH",
            price: prevSameType.price,
            time: lastCandle.time,
          };
        }
      }
    }
  }

  let buyPoints = 0;
  let sellPoints = 0;

  if (trend === "BULLISH") buyPoints += 2;
  if (trend === "BEARISH") sellPoints += 2;

  if (bullishFVG) buyPoints += 1.5;
  if (bearishFVG) sellPoints += 1.5;

  if (lastOB && (lastOB as any).type === "BULLISH" && !(lastOB as any).mitigated) buyPoints += 2;
  if (lastOB && (lastOB as any).type === "BEARISH" && !(lastOB as any).mitigated) sellPoints += 2;

  if (sweep && sweep.type === "BULLISH") buyPoints += 2.5;
  if (sweep && sweep.type === "BEARISH") sellPoints += 2.5;

  if (choch && choch.type === "BULLISH") buyPoints += 2;
  if (choch && choch.type === "BEARISH") sellPoints += 2;

  // S&R Support and Resistance Calculation in Worker
  let workerSupport: any = null;
  let workerResistance: any = null;

  if (lastLow) {
    workerSupport = {
      type: "SUPPORT",
      time: lastLow.time,
      price: Number(lastLow.price.toFixed(2)),
      top: Number((lastLow.price * 1.0008).toFixed(2)),
      bottom: Number((lastLow.price * 0.9992).toFixed(2)),
      endTime: extendedTime,
      touches: 1,
      strength: "MODERAT",
    };
  } else if (data.length > 0) {
    const minLow = Math.min(...data.slice(-30).map((d) => d.low));
    workerSupport = {
      type: "SUPPORT",
      time: data[0].time,
      price: Number(minLow.toFixed(2)),
      top: Number((minLow * 1.0008).toFixed(2)),
      bottom: Number((minLow * 0.9992).toFixed(2)),
      endTime: extendedTime,
      touches: 1,
      strength: "MODERAT",
    };
  }

  if (lastHigh) {
    workerResistance = {
      type: "RESISTANCE",
      time: lastHigh.time,
      price: Number(lastHigh.price.toFixed(2)),
      top: Number((lastHigh.price * 1.0008).toFixed(2)),
      bottom: Number((lastHigh.price * 0.9992).toFixed(2)),
      endTime: extendedTime,
      touches: 1,
      strength: "MODERAT",
    };
  } else if (data.length > 0) {
    const maxHigh = Math.max(...data.slice(-30).map((d) => d.high));
    workerResistance = {
      type: "RESISTANCE",
      time: data[0].time,
      price: Number(maxHigh.toFixed(2)),
      top: Number((maxHigh * 1.0008).toFixed(2)),
      bottom: Number((maxHigh * 0.9992).toFixed(2)),
      endTime: extendedTime,
      touches: 1,
      strength: "MODERAT",
    };
  }

  // --- 6 POLA KLASIK & PREDIKSI BREAKOUT / BREAKDOWN ---
  const currentClose = data[data.length - 1].close;
  const detectedClassicPatterns: any[] = [];
  const lowSwings = swings.filter((s) => s.type === "Low");
  const highSwings = swings.filter((s) => s.type === "High");

  // 1. Double Bottom (2 Low hampir sama -> Breakout Neckline -> BUY)
  if (lowSwings.length >= 2) {
    for (let i = lowSwings.length - 1; i >= 1; i--) {
      const l2 = lowSwings[i];
      const l1 = lowSwings[i - 1];
      if (l2.index - l1.index >= 4 && l2.index - l1.index <= 45) {
        const diff = Math.abs(l1.price - l2.price) / ((l1.price + l2.price) / 2);
        if (diff <= 0.009) {
          const midHighs = highSwings.filter((h) => h.index > l1.index && h.index < l2.index);
          if (midHighs.length > 0) {
            const neck = midHighs.reduce((m, h) => (h.price > m.price ? h : m));
            const isBreakout = currentClose >= neck.price;
            detectedClassicPatterns.push({
              name: "Double Bottom",
              type: "BULLISH",
              status: isBreakout ? "BREAKOUT_CONFIRMED" : "POTENTIAL_BREAKOUT",
              statusLabel: isBreakout ? " BREAKOUT TERKONFIRMASI (BUY)" : " PREDIKSI BREAKOUT (BUY ON BREAKOUT)",
              actionRecommendation: isBreakout ? "BUY" : "WAITING BREAKOUT",
              definition: "Dua titik rendah yang hampir sama, lalu breakout di atas leher (neckline). BUY setelah breakout.",
              necklinePrice: Number(neck.price.toFixed(2)),
              targetPrice: Number((neck.price + (neck.price - Math.min(l1.price, l2.price))).toFixed(2)),
              stopLossPrice: Number((Math.min(l1.price, l2.price) * 0.998).toFixed(2)),
              probabilityScore: isBreakout ? 92 : 86,
            });
            break;
          }
        }
      }
    }
  }

  // 2. Double Top (2 High hampir sama -> Breakdown Neckline -> SELL)
  if (highSwings.length >= 2) {
    for (let i = highSwings.length - 1; i >= 1; i--) {
      const h2 = highSwings[i];
      const h1 = highSwings[i - 1];
      if (h2.index - h1.index >= 4 && h2.index - h1.index <= 45) {
        const diff = Math.abs(h1.price - h2.price) / ((h1.price + h2.price) / 2);
        if (diff <= 0.009) {
          const midLows = lowSwings.filter((l) => l.index > h1.index && l.index < h2.index);
          if (midLows.length > 0) {
            const neck = midLows.reduce((m, l) => (l.price < m.price ? l : m));
            const isBreakdown = currentClose <= neck.price;
            detectedClassicPatterns.push({
              name: "Double Top",
              type: "BEARISH",
              status: isBreakdown ? "BREAKDOWN_CONFIRMED" : "POTENTIAL_BREAKDOWN",
              statusLabel: isBreakdown ? " BREAKDOWN TERKONFIRMASI (SELL)" : " PREDIKSI BREAKDOWN (SELL ON BREAKDOWN)",
              actionRecommendation: isBreakdown ? "SELL" : "WAITING BREAKDOWN",
              definition: "Dua titik tinggi yang hampir sama, lalu breakdown di bawah leher. SELL setelah breakdown.",
              necklinePrice: Number(neck.price.toFixed(2)),
              targetPrice: Number((neck.price - (Math.max(h1.price, h2.price) - neck.price)).toFixed(2)),
              stopLossPrice: Number((Math.max(h1.price, h2.price) * 1.002).toFixed(2)),
              probabilityScore: isBreakdown ? 92 : 86,
            });
            break;
          }
        }
      }
    }
  }

  // 3. Head & Shoulders (3 puncak, tengah lebih tinggi -> Breakdown leher -> SELL)
  if (highSwings.length >= 3) {
    for (let i = highSwings.length - 1; i >= 2; i--) {
      const rShoulder = highSwings[i];
      const head = highSwings[i - 1];
      const lShoulder = highSwings[i - 2];
      if (head.price > lShoulder.price && head.price > rShoulder.price) {
        const shoulderDiff = Math.abs(lShoulder.price - rShoulder.price) / ((lShoulder.price + rShoulder.price) / 2);
        if (shoulderDiff <= 0.018) {
          const low1 = lowSwings.find((l) => l.index > lShoulder.index && l.index < head.index);
          const low2 = lowSwings.find((l) => l.index > head.index && l.index < rShoulder.index);
          if (low1 && low2) {
            const neckPrice = (low1.price + low2.price) / 2;
            const isBreakdown = currentClose <= neckPrice;
            detectedClassicPatterns.push({
              name: "Head & Shoulders",
              type: "BEARISH",
              status: isBreakdown ? "BREAKDOWN_CONFIRMED" : "POTENTIAL_BREAKDOWN",
              statusLabel: isBreakdown ? " BREAKDOWN LEHER H&S (SELL)" : " PREDIKSI BREAKDOWN H&S (SELL ON BREAKDOWN)",
              actionRecommendation: isBreakdown ? "SELL" : "WAITING BREAKDOWN",
              definition: "Tiga puncak, yang tengah lebih tinggi, lalu breakdown di leher. SELL setelah breakdown.",
              necklinePrice: Number(neckPrice.toFixed(2)),
              targetPrice: Number((neckPrice - (head.price - neckPrice)).toFixed(2)),
              stopLossPrice: Number((rShoulder.price * 1.002).toFixed(2)),
              probabilityScore: isBreakdown ? 94 : 88,
            });
            break;
          }
        }
      }
    }
  }

  // 4. Inverse H&S (3 lembah, tengah lebih rendah -> Breakout leher -> BUY)
  if (lowSwings.length >= 3) {
    for (let i = lowSwings.length - 1; i >= 2; i--) {
      const rShoulder = lowSwings[i];
      const head = lowSwings[i - 1];
      const lShoulder = lowSwings[i - 2];
      if (head.price < lShoulder.price && head.price < rShoulder.price) {
        const shoulderDiff = Math.abs(lShoulder.price - rShoulder.price) / ((lShoulder.price + rShoulder.price) / 2);
        if (shoulderDiff <= 0.018) {
          const high1 = highSwings.find((h) => h.index > lShoulder.index && h.index < head.index);
          const high2 = highSwings.find((h) => h.index > head.index && h.index < rShoulder.index);
          if (high1 && high2) {
            const neckPrice = (high1.price + high2.price) / 2;
            const isBreakout = currentClose >= neckPrice;
            detectedClassicPatterns.push({
              name: "Inverse H&S",
              type: "BULLISH",
              status: isBreakout ? "BREAKOUT_CONFIRMED" : "POTENTIAL_BREAKOUT",
              statusLabel: isBreakout ? " BREAKOUT LEHER INVERSE H&S (BUY)" : " PREDIKSI BREAKOUT INVERSE H&S (BUY ON BREAKOUT)",
              actionRecommendation: isBreakout ? "BUY" : "WAITING BREAKOUT",
              definition: "Tiga lembah, yang tengah lebih rendah, lalu breakout di leher. BUY setelah breakout.",
              necklinePrice: Number(neckPrice.toFixed(2)),
              targetPrice: Number((neckPrice + (neckPrice - head.price)).toFixed(2)),
              stopLossPrice: Number((rShoulder.price * 0.998).toFixed(2)),
              probabilityScore: isBreakout ? 94 : 88,
            });
            break;
          }
        }
      }
    }
  }

  // 5. Bullish Flag & 6. Bearish Flag
  if (data.length >= 25) {
    const flagLen = 8;
    const poleLen = 12;
    const pStart = data.length - 1 - flagLen - poleLen;
    const fStart = data.length - 1 - flagLen;
    if (pStart >= 0) {
      const poleStart = data[pStart];
      const poleEnd = data[fStart];
      const flagSlice = data.slice(fStart);
      const flagH = Math.max(...flagSlice.map((c) => c.high));
      const flagL = Math.min(...flagSlice.map((c) => c.low));

      // Bullish Flag: Rally tajam lalu konsolidasi
      if (poleEnd.high - poleStart.low > (totalRange * 0.25) && poleEnd.high > poleStart.low) {
        const isBreakout = currentClose >= flagH;
        detectedClassicPatterns.push({
          name: "Bullish Flag",
          type: "BULLISH",
          status: isBreakout ? "BREAKOUT_CONFIRMED" : "POTENTIAL_BREAKOUT",
          statusLabel: isBreakout ? " BREAKOUT BULLISH FLAG (BUY)" : " PREDIKSI BREAKOUT BULLISH FLAG (BUY ON BREAKOUT)",
          actionRecommendation: isBreakout ? "BUY" : "WAITING BREAKOUT",
          definition: "Konsolidasi setelah tren naik, lalu breakout ke atas. BUY setelah breakout.",
          necklinePrice: Number(flagH.toFixed(2)),
          targetPrice: Number((flagH + (poleEnd.high - poleStart.low)).toFixed(2)),
          stopLossPrice: Number((flagL * 0.998).toFixed(2)),
          probabilityScore: isBreakout ? 90 : 85,
        });
      }
      // Bearish Flag: Drop tajam lalu konsolidasi
      else if (poleStart.high - poleEnd.low > (totalRange * 0.25) && poleStart.high > poleEnd.low) {
        const isBreakdown = currentClose <= flagL;
        detectedClassicPatterns.push({
          name: "Bearish Flag",
          type: "BEARISH",
          status: isBreakdown ? "BREAKDOWN_CONFIRMED" : "POTENTIAL_BREAKDOWN",
          statusLabel: isBreakdown ? " BREAKDOWN BEARISH FLAG (SELL)" : " PREDIKSI BREAKDOWN BEARISH FLAG (SELL ON BREAKDOWN)",
          actionRecommendation: isBreakdown ? "SELL" : "WAITING BREAKDOWN",
          definition: "Konsolidasi setelah tren turun, lalu breakdown ke bawah. SELL setelah breakdown.",
          necklinePrice: Number(flagL.toFixed(2)),
          targetPrice: Number((flagL - (poleStart.high - poleEnd.low)).toFixed(2)),
          stopLossPrice: Number((flagH * 1.002).toFixed(2)),
          probabilityScore: isBreakdown ? 90 : 85,
        });
      }
    }
  }

  const primaryClassicPattern = detectedClassicPatterns.length > 0 ? detectedClassicPatterns[0] : null;

  const totalPoints = buyPoints + sellPoints || 1;
  const buySentiment = Math.round((buyPoints / totalPoints) * 100);
  const sellSentiment = 100 - buySentiment;

  return {
    markers,
    drawings: {
      bullishFVG,
      bearishFVG,
      ob: lastOB,
      sd: lastSD,
      support: workerSupport,
      resistance: workerResistance,
      bos,
      choch,
      ibos: null,
      sweep,
      trendlines: { support: null, resistance: null },
    },
    state: {
      trend,
      lastStruct: structure.length > 0 ? structure[structure.length - 1].label : "NONE",
      fvg: bullishFVG ? "BULLISH" : bearishFVG ? "BEARISH" : "NONE",
      ob: lastOB ? (lastOB as any).type : "NONE",
      sweep: sweep ? sweep.type : "NONE",
      recentStructures: recentStructs,
      bos: bos ? bos.type : "NONE",
      choch: choch ? choch.type : "NONE",
      patterns: detectedClassicPatterns,
      activePattern: primaryClassicPattern,
      sentiment: { buy: buySentiment, sell: sellSentiment },
    },
  };
}
