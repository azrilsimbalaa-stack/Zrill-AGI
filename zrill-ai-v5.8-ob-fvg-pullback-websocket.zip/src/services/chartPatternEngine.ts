// =========================================================================================
// ZRILL AGI v5.0 - CLASSIC CHART PATTERN & BREAKOUT/BREAKDOWN PREDICTION ENGINE
// =========================================================================================
// Mendeteksi 6 Pola Klasik Utama & Prediksi Breakout/Breakdown sesuai spesifikasi:
// 1. Double Bottom: 2 titik rendah hampir sama, breakout di atas leher (neckline) -> BUY
// 2. Double Top: 2 titik tinggi hampir sama, breakdown di bawah leher -> SELL
// 3. Head & Shoulders: 3 puncak (tengah lebih tinggi), breakdown di leher -> SELL
// 4. Inverse H&S: 3 lembah (tengah lebih rendah), breakout di leher -> BUY
// 5. Bullish Flag: Konsolidasi setelah tren naik, breakout ke atas -> BUY
// 6. Bearish Flag: Konsolidasi setelah tren turun, breakdown ke bawah -> SELL
// =========================================================================================

export type PatternName =
  | "Double Bottom"
  | "Double Top"
  | "Head & Shoulders"
  | "Inverse H&S"
  | "Bullish Flag"
  | "Bearish Flag";

export type PatternType = "BULLISH" | "BEARISH";

export type PatternStatus =
  | "FORMING"
  | "POTENTIAL_BREAKOUT"
  | "POTENTIAL_BREAKDOWN"
  | "BREAKOUT_CONFIRMED"
  | "BREAKDOWN_CONFIRMED";

export interface PatternKeyPoint {
  label: string; // e.g., "Bottom 1", "Bottom 2", "Neckline", "Left Shoulder", "Head", "Right Shoulder", "Flagpole", "Flag High", "Flag Low"
  time: number;
  price: number;
}

export interface DetectedChartPattern {
  id: string;
  name: PatternName;
  type: PatternType;
  status: PatternStatus;
  statusLabel: string;
  badgeColor: "emerald" | "rose" | "amber" | "blue";
  actionRecommendation: "BUY" | "SELL" | "WAITING BREAKOUT" | "WAITING BREAKDOWN";
  definition: string;
  necklinePrice: number;
  triggerPrice: number;
  targetPrice: number;
  stopLossPrice: number;
  currentPrice: number;
  distanceToNecklinePips: number;
  probabilityScore: number; // 0 - 100%
  isBreakoutActive: boolean;
  isBreakdownActive: boolean;
  predictionSummary: string;
  tradingGuideline: string;
  keyPoints: PatternKeyPoint[];
  measuredMove: number;
  riskRewardRatio: string;
}

export interface CandleLike {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

interface SwingPoint {
  index: number;
  time: number;
  price: number;
  type: "HIGH" | "LOW";
}

/**
 * Deteksi Swing High dan Swing Low dengan fractal lookback
 */
function findSwings(candles: CandleLike[], leftBars = 4, rightBars = 3): SwingPoint[] {
  const swings: SwingPoint[] = [];
  if (!candles || candles.length < leftBars + rightBars + 1) return swings;

  for (let i = leftBars; i < candles.length - rightBars; i++) {
    const currentHigh = candles[i].high;
    const currentLow = candles[i].low;

    let isHigh = true;
    let isLow = true;

    for (let j = 1; j <= leftBars; j++) {
      if (candles[i - j].high >= currentHigh) isHigh = false;
      if (candles[i - j].low <= currentLow) isLow = false;
    }
    for (let j = 1; j <= rightBars; j++) {
      if (candles[i + j].high >= currentHigh) isHigh = false;
      if (candles[i + j].low <= currentLow) isLow = false;
    }

    if (isHigh) {
      swings.push({
        index: i,
        time: candles[i].time,
        price: currentHigh,
        type: "HIGH",
      });
    }
    if (isLow) {
      swings.push({
        index: i,
        time: candles[i].time,
        price: currentLow,
        type: "LOW",
      });
    }
  }

  // Filter alternating swings
  const filtered: SwingPoint[] = [];
  let lastType: "HIGH" | "LOW" | null = null;

  for (const s of swings) {
    if (s.type !== lastType) {
      filtered.push(s);
      lastType = s.type;
    } else if (filtered.length > 0) {
      const prev = filtered[filtered.length - 1];
      if (s.type === "HIGH" && s.price > prev.price) {
        filtered[filtered.length - 1] = s;
      } else if (s.type === "LOW" && s.price < prev.price) {
        filtered[filtered.length - 1] = s;
      }
    }
  }

  return filtered;
}

/**
 * Deteksi Pola Double Bottom
 * Dua titik rendah yang hampir sama, lalu breakout di atas leher (neckline). BUY setelah breakout.
 */
function detectDoubleBottom(
  candles: CandleLike[],
  swings: SwingPoint[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  const lows = swings.filter((s) => s.type === "LOW");
  if (lows.length < 2) return null;

  for (let i = lows.length - 1; i >= 1; i--) {
    const l2 = lows[i];
    const l1 = lows[i - 1];

    const candleDiff = l2.index - l1.index;
    if (candleDiff < 4 || candleDiff > 45) continue;

    // Cek selisih harga antara kedua low (toleransi ~0.8% atau 1.5 ATR)
    const priceDiff = Math.abs(l1.price - l2.price);
    const avgPrice = (l1.price + l2.price) / 2;
    if (priceDiff / avgPrice > 0.009) continue;

    // Cari swing high tertinggi di antara L1 dan L2 sebagai Neckline
    const interveningHighs = swings.filter(
      (s) => s.type === "HIGH" && s.index > l1.index && s.index < l2.index
    );
    if (interveningHighs.length === 0) continue;

    const necklineSwing = interveningHighs.reduce((max, h) =>
      h.price > max.price ? h : max
    );
    const necklinePrice = Number(necklineSwing.price.toFixed(2));
    const lowestBottom = Math.min(l1.price, l2.price);
    const patternHeight = necklinePrice - lowestBottom;

    if (patternHeight <= 0) continue;

    const measuredMove = patternHeight;
    const targetPrice = Number((necklinePrice + measuredMove).toFixed(2));
    const stopLossPrice = Number((lowestBottom - atr * 0.5).toFixed(2));
    const distancePips = Math.round(Math.abs(currentPrice - necklinePrice) * 10);

    const isBreakoutActive = currentPrice >= necklinePrice;
    const status: PatternStatus = isBreakoutActive
      ? "BREAKOUT_CONFIRMED"
      : "POTENTIAL_BREAKOUT";

    const risk = Math.max(0.1, necklinePrice - stopLossPrice);
    const reward = Math.max(0.1, targetPrice - necklinePrice);
    const rrRatio = `1:${(reward / risk).toFixed(1)}`;

    return {
      id: `pattern-db-${l2.time}`,
      name: "Double Bottom",
      type: "BULLISH",
      status,
      statusLabel: isBreakoutActive
        ? " BREAKOUT TERKONFIRMASI (DI ATAS NECKLINE)"
        : " PREDIKSI BREAKOUT (POLA TERBENTUK)",
      badgeColor: isBreakoutActive ? "emerald" : "blue",
      actionRecommendation: isBreakoutActive ? "BUY" : "WAITING BREAKOUT",
      definition:
        "Dua titik rendah yang hampir sama, lalu breakout di atas leher (neckline). BUY setelah breakout.",
      necklinePrice,
      triggerPrice: necklinePrice,
      targetPrice,
      stopLossPrice,
      currentPrice,
      distanceToNecklinePips: distancePips,
      probabilityScore: isBreakoutActive ? 92 : 86,
      isBreakoutActive,
      isBreakdownActive: false,
      predictionSummary: isBreakoutActive
        ? `Breakout valid telah terjadi di atas leher $${necklinePrice}. Target ekstensi diproyeksikan menuju $${targetPrice}.`
        : `Pola Double Bottom selesai di level $${lowestBottom.toFixed(2)}. Prediksi BUY aktif saat harga berhasil menembus leher $${necklinePrice}.`,
      tradingGuideline: isBreakoutActive
        ? `Lakukan eksekusi BUY dengan SL di $${stopLossPrice} dan TP di $${targetPrice}.`
        : `Tunggu konfirmasi candle close menembus di atas $${necklinePrice} sebelum membuka posisi BUY.`,
      keyPoints: [
        { label: "Lembah 1 (Low 1)", time: l1.time, price: l1.price },
        { label: "Leher (Neckline)", time: necklineSwing.time, price: necklineSwing.price },
        { label: "Lembah 2 (Low 2)", time: l2.time, price: l2.price },
      ],
      measuredMove,
      riskRewardRatio: rrRatio,
    };
  }
  return null;
}

/**
 * Deteksi Pola Double Top
 * Dua titik tinggi yang hampir sama, lalu breakdown di bawah leher. SELL setelah breakdown.
 */
function detectDoubleTop(
  candles: CandleLike[],
  swings: SwingPoint[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  const highs = swings.filter((s) => s.type === "HIGH");
  if (highs.length < 2) return null;

  for (let i = highs.length - 1; i >= 1; i--) {
    const h2 = highs[i];
    const h1 = highs[i - 1];

    const candleDiff = h2.index - h1.index;
    if (candleDiff < 4 || candleDiff > 45) continue;

    const priceDiff = Math.abs(h1.price - h2.price);
    const avgPrice = (h1.price + h2.price) / 2;
    if (priceDiff / avgPrice > 0.009) continue;

    const interveningLows = swings.filter(
      (s) => s.type === "LOW" && s.index > h1.index && s.index < h2.index
    );
    if (interveningLows.length === 0) continue;

    const necklineSwing = interveningLows.reduce((min, l) =>
      l.price < min.price ? l : min
    );
    const necklinePrice = Number(necklineSwing.price.toFixed(2));
    const highestTop = Math.max(h1.price, h2.price);
    const patternHeight = highestTop - necklinePrice;

    if (patternHeight <= 0) continue;

    const measuredMove = patternHeight;
    const targetPrice = Number((necklinePrice - measuredMove).toFixed(2));
    const stopLossPrice = Number((highestTop + atr * 0.5).toFixed(2));
    const distancePips = Math.round(Math.abs(currentPrice - necklinePrice) * 10);

    const isBreakdownActive = currentPrice <= necklinePrice;
    const status: PatternStatus = isBreakdownActive
      ? "BREAKDOWN_CONFIRMED"
      : "POTENTIAL_BREAKDOWN";

    const risk = Math.max(0.1, stopLossPrice - necklinePrice);
    const reward = Math.max(0.1, necklinePrice - targetPrice);
    const rrRatio = `1:${(reward / risk).toFixed(1)}`;

    return {
      id: `pattern-dt-${h2.time}`,
      name: "Double Top",
      type: "BEARISH",
      status,
      statusLabel: isBreakdownActive
        ? " BREAKDOWN TERKONFIRMASI (DI BAWAH NECKLINE)"
        : " PREDIKSI BREAKDOWN (POLA TERBENTUK)",
      badgeColor: isBreakdownActive ? "rose" : "amber",
      actionRecommendation: isBreakdownActive ? "SELL" : "WAITING BREAKDOWN",
      definition:
        "Dua titik tinggi yang hampir sama, lalu breakdown di bawah leher. SELL setelah breakdown.",
      necklinePrice,
      triggerPrice: necklinePrice,
      targetPrice,
      stopLossPrice,
      currentPrice,
      distanceToNecklinePips: distancePips,
      probabilityScore: isBreakdownActive ? 92 : 86,
      isBreakoutActive: false,
      isBreakdownActive,
      predictionSummary: isBreakdownActive
        ? `Breakdown valid telah terjadi di bawah leher $${necklinePrice}. Target penurunan diproyeksikan ke $${targetPrice}.`
        : `Pola Double Top selesai di level $${highestTop.toFixed(2)}. Prediksi SELL aktif saat harga menembus ke bawah leher $${necklinePrice}.`,
      tradingGuideline: isBreakdownActive
        ? `Lakukan eksekusi SELL dengan SL di $${stopLossPrice} dan TP di $${targetPrice}.`
        : `Tunggu konfirmasi candle close menembus ke bawah $${necklinePrice} sebelum membuka posisi SELL.`,
      keyPoints: [
        { label: "Puncak 1 (High 1)", time: h1.time, price: h1.price },
        { label: "Leher (Neckline)", time: necklineSwing.time, price: necklineSwing.price },
        { label: "Puncak 2 (High 2)", time: h2.time, price: h2.price },
      ],
      measuredMove,
      riskRewardRatio: rrRatio,
    };
  }
  return null;
}

/**
 * Deteksi Pola Head & Shoulders
 * Tiga puncak, yang tengah lebih tinggi, lalu breakdown di leher. SELL setelah breakdown.
 */
function detectHeadAndShoulders(
  candles: CandleLike[],
  swings: SwingPoint[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  const highs = swings.filter((s) => s.type === "HIGH");
  if (highs.length < 3) return null;

  for (let i = highs.length - 1; i >= 2; i--) {
    const rShoulder = highs[i];
    const head = highs[i - 1];
    const lShoulder = highs[i - 2];

    // Kepala harus lebih tinggi dari kedua bahu
    if (head.price <= lShoulder.price || head.price <= rShoulder.price) continue;

    // Kedua bahu memiliki ketinggian yang relatif seimbang (toleransi 1.5%)
    const shoulderDiff = Math.abs(lShoulder.price - rShoulder.price);
    const avgShoulder = (lShoulder.price + rShoulder.price) / 2;
    if (shoulderDiff / avgShoulder > 0.018) continue;

    // Cari titik leher di antara bahu kiri - kepala dan kepala - bahu kanan
    const low1 = swings.find(
      (s) => s.type === "LOW" && s.index > lShoulder.index && s.index < head.index
    );
    const low2 = swings.find(
      (s) => s.type === "LOW" && s.index > head.index && s.index < rShoulder.index
    );

    if (!low1 || !low2) continue;

    const necklinePrice = Number(((low1.price + low2.price) / 2).toFixed(2));
    const headHeight = head.price - necklinePrice;
    if (headHeight <= 0) continue;

    const measuredMove = headHeight;
    const targetPrice = Number((necklinePrice - measuredMove).toFixed(2));
    const stopLossPrice = Number((rShoulder.price + atr * 0.4).toFixed(2));
    const distancePips = Math.round(Math.abs(currentPrice - necklinePrice) * 10);

    const isBreakdownActive = currentPrice <= necklinePrice;
    const status: PatternStatus = isBreakdownActive
      ? "BREAKDOWN_CONFIRMED"
      : "POTENTIAL_BREAKDOWN";

    const risk = Math.max(0.1, stopLossPrice - necklinePrice);
    const reward = Math.max(0.1, necklinePrice - targetPrice);
    const rrRatio = `1:${(reward / risk).toFixed(1)}`;

    return {
      id: `pattern-hs-${rShoulder.time}`,
      name: "Head & Shoulders",
      type: "BEARISH",
      status,
      statusLabel: isBreakdownActive
        ? " BREAKDOWN LEHER H&S TERKONFIRMASI"
        : " PREDIKSI BREAKDOWN: POLA H&S TERBENTUK",
      badgeColor: isBreakdownActive ? "rose" : "amber",
      actionRecommendation: isBreakdownActive ? "SELL" : "WAITING BREAKDOWN",
      definition:
        "Tiga puncak, yang tengah lebih tinggi, lalu breakdown di leher. SELL setelah breakdown.",
      necklinePrice,
      triggerPrice: necklinePrice,
      targetPrice,
      stopLossPrice,
      currentPrice,
      distanceToNecklinePips: distancePips,
      probabilityScore: isBreakdownActive ? 94 : 88,
      isBreakoutActive: false,
      isBreakdownActive,
      predictionSummary: isBreakdownActive
        ? `Breakdown garis leher H&S telah terkonfirmasi di $${necklinePrice}. Target distribusi penurunan di $${targetPrice}.`
        : `Pola Head & Shoulders lengkap dengan Bahu Kanan terbentuk. Prediksi SELL aktif saat tembus leher $${necklinePrice}.`,
      tradingGuideline: isBreakdownActive
        ? `Eksekusi SELL dengan Stop Loss di atas Bahu Kanan ($${stopLossPrice}) dan Take Profit di $${targetPrice}.`
        : `Pasang Sell Stop atau tunggu konfirmasi breakdown di bawah leher $${necklinePrice}.`,
      keyPoints: [
        { label: "Bahu Kiri", time: lShoulder.time, price: lShoulder.price },
        { label: "Kepala (Head)", time: head.time, price: head.price },
        { label: "Bahu Kanan", time: rShoulder.time, price: rShoulder.price },
        { label: "Garis Leher", time: low2.time, price: necklinePrice },
      ],
      measuredMove,
      riskRewardRatio: rrRatio,
    };
  }
  return null;
}

/**
 * Deteksi Pola Inverse Head & Shoulders
 * Tiga lembah, yang tengah lebih rendah, lalu breakout di leher. BUY setelah breakout.
 */
function detectInverseHeadAndShoulders(
  candles: CandleLike[],
  swings: SwingPoint[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  const lows = swings.filter((s) => s.type === "LOW");
  if (lows.length < 3) return null;

  for (let i = lows.length - 1; i >= 2; i--) {
    const rShoulder = lows[i];
    const head = lows[i - 1];
    const lShoulder = lows[i - 2];

    // Kepala harus lebih rendah dari kedua bahu
    if (head.price >= lShoulder.price || head.price >= rShoulder.price) continue;

    // Kedua bahu seimbang (toleransi 1.8%)
    const shoulderDiff = Math.abs(lShoulder.price - rShoulder.price);
    const avgShoulder = (lShoulder.price + rShoulder.price) / 2;
    if (shoulderDiff / avgShoulder > 0.018) continue;

    // Cari titik leher di antara puncak
    const high1 = swings.find(
      (s) => s.type === "HIGH" && s.index > lShoulder.index && s.index < head.index
    );
    const high2 = swings.find(
      (s) => s.type === "HIGH" && s.index > head.index && s.index < rShoulder.index
    );

    if (!high1 || !high2) continue;

    const necklinePrice = Number(((high1.price + high2.price) / 2).toFixed(2));
    const headDepth = necklinePrice - head.price;
    if (headDepth <= 0) continue;

    const measuredMove = headDepth;
    const targetPrice = Number((necklinePrice + measuredMove).toFixed(2));
    const stopLossPrice = Number((rShoulder.price - atr * 0.4).toFixed(2));
    const distancePips = Math.round(Math.abs(currentPrice - necklinePrice) * 10);

    const isBreakoutActive = currentPrice >= necklinePrice;
    const status: PatternStatus = isBreakoutActive
      ? "BREAKOUT_CONFIRMED"
      : "POTENTIAL_BREAKOUT";

    const risk = Math.max(0.1, necklinePrice - stopLossPrice);
    const reward = Math.max(0.1, targetPrice - necklinePrice);
    const rrRatio = `1:${(reward / risk).toFixed(1)}`;

    return {
      id: `pattern-ihs-${rShoulder.time}`,
      name: "Inverse H&S",
      type: "BULLISH",
      status,
      statusLabel: isBreakoutActive
        ? " BREAKOUT LEHER INVERSE H&S TERKONFIRMASI"
        : " PREDIKSI BREAKOUT: INVERSE H&S TERBENTUK",
      badgeColor: isBreakoutActive ? "emerald" : "blue",
      actionRecommendation: isBreakoutActive ? "BUY" : "WAITING BREAKOUT",
      definition:
        "Tiga lembah, yang tengah lebih rendah, lalu breakout di leher. BUY setelah breakout.",
      necklinePrice,
      triggerPrice: necklinePrice,
      targetPrice,
      stopLossPrice,
      currentPrice,
      distanceToNecklinePips: distancePips,
      probabilityScore: isBreakoutActive ? 94 : 88,
      isBreakoutActive,
      isBreakdownActive: false,
      predictionSummary: isBreakoutActive
        ? `Breakout garis leher Inverse H&S terkonfirmasi di $${necklinePrice}. Target akumulasi mengarah ke $${targetPrice}.`
        : `Pola Inverse H&S selesai di Bahu Kanan $${rShoulder.price.toFixed(2)}. Prediksi BUY aktif saat breakout di atas leher $${necklinePrice}.`,
      tradingGuideline: isBreakoutActive
        ? `Eksekusi BUY dengan Stop Loss di bawah Bahu Kanan ($${stopLossPrice}) dan Take Profit di $${targetPrice}.`
        : `Pasang Buy Stop di atas $${necklinePrice} atau tunggu lilin penembusan terkonfirmasi.`,
      keyPoints: [
        { label: "Bahu Kiri", time: lShoulder.time, price: lShoulder.price },
        { label: "Kepala Bawah", time: head.time, price: head.price },
        { label: "Bahu Kanan", time: rShoulder.time, price: rShoulder.price },
        { label: "Garis Leher", time: high2.time, price: necklinePrice },
      ],
      measuredMove,
      riskRewardRatio: rrRatio,
    };
  }
  return null;
}

/**
 * Deteksi Pola Bullish Flag
 * Konsolidasi setelah tren naik, lalu breakout ke atas. BUY setelah breakout.
 */
function detectBullishFlag(
  candles: CandleLike[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  if (candles.length < 25) return null;

  // 1. Deteksi Flagpole (Rally kuat 5-15 lilin sebelum konsolidasi)
  const consolidationLength = 10;
  const flagpoleLength = 12;
  const endIndex = candles.length - 1;
  const flagStartIndex = endIndex - consolidationLength;
  const poleStartIndex = flagStartIndex - flagpoleLength;

  if (poleStartIndex < 0) return null;

  const poleStartCandle = candles[poleStartIndex];
  const poleEndCandle = candles[flagStartIndex];

  const poleHeight = poleEndCandle.high - poleStartCandle.low;
  // Syarat Flagpole: Kenaikan signifikan minimal 3x ATR
  if (poleHeight < atr * 3.5 || poleEndCandle.high <= poleStartCandle.low) return null;

  // 2. Deteksi Channel Konsolidasi (Flag)
  const flagCandles = candles.slice(flagStartIndex, endIndex + 1);
  const flagHigh = Math.max(...flagCandles.map((c) => c.high));
  const flagLow = Math.min(...flagCandles.map((c) => c.low));
  const flagRetracement = poleEndCandle.high - flagLow;

  // Flag tidak boleh retrace lebih dari 50% dari tiang bendera
  if (flagRetracement > poleHeight * 0.55 || flagHigh - flagLow <= 0) return null;

  const upperResistance = Number(flagHigh.toFixed(2));
  const targetPrice = Number((upperResistance + poleHeight).toFixed(2));
  const stopLossPrice = Number((flagLow - atr * 0.4).toFixed(2));
  const distancePips = Math.round(Math.abs(currentPrice - upperResistance) * 10);

  const isBreakoutActive = currentPrice >= upperResistance;
  const status: PatternStatus = isBreakoutActive
    ? "BREAKOUT_CONFIRMED"
    : "POTENTIAL_BREAKOUT";

  const risk = Math.max(0.1, upperResistance - stopLossPrice);
  const reward = Math.max(0.1, targetPrice - upperResistance);
  const rrRatio = `1:${(reward / risk).toFixed(1)}`;

  return {
    id: `pattern-bflag-${candles[flagStartIndex].time}`,
    name: "Bullish Flag",
    type: "BULLISH",
    status,
    statusLabel: isBreakoutActive
      ? " BREAKOUT BULLISH FLAG (TEMBUS KE ATAS)"
      : " PREDIKSI BREAKOUT: KONSOLIDASI BENDERA NAIK",
    badgeColor: isBreakoutActive ? "emerald" : "blue",
    actionRecommendation: isBreakoutActive ? "BUY" : "WAITING BREAKOUT",
    definition:
      "Konsolidasi setelah tren naik, lalu breakout ke atas. BUY setelah breakout.",
    necklinePrice: upperResistance,
    triggerPrice: upperResistance,
    targetPrice,
    stopLossPrice,
    currentPrice,
    distanceToNecklinePips: distancePips,
    probabilityScore: isBreakoutActive ? 90 : 85,
    isBreakoutActive,
    isBreakdownActive: false,
    predictionSummary: isBreakoutActive
      ? `Breakout dari saluran bendera telah terjadi di $${upperResistance}. Proyeksi tiang bendera (flagpole move) menargetkan $${targetPrice}.`
      : `Konsolidasi Bullish Flag terbentuk setelah kenaikan tajam. Prediksi BUY aktif saat harga breakout di atas $${upperResistance}.`,
    tradingGuideline: isBreakoutActive
      ? `Buka posisi BUY dengan Stop Loss di bawah batas bawah bendera ($${stopLossPrice}) dan Take Profit di $${targetPrice}.`
      : `Tunggu penembusan resistance bendera di $${upperResistance} sebelum melakukan buy order.`,
    keyPoints: [
      { label: "Awal Tiang (Pole Start)", time: poleStartCandle.time, price: poleStartCandle.low },
      { label: "Puncak Tiang (Pole High)", time: poleEndCandle.time, price: poleEndCandle.high },
      { label: "Resistance Bendera", time: candles[endIndex].time, price: upperResistance },
      { label: "Support Bendera", time: candles[endIndex].time, price: flagLow },
    ],
    measuredMove: poleHeight,
    riskRewardRatio: rrRatio,
  };
}

/**
 * Deteksi Pola Bearish Flag
 * Konsolidasi setelah tren turun, lalu breakdown ke bawah. SELL setelah breakdown.
 */
function detectBearishFlag(
  candles: CandleLike[],
  currentPrice: number,
  atr: number
): DetectedChartPattern | null {
  if (candles.length < 25) return null;

  const consolidationLength = 10;
  const flagpoleLength = 12;
  const endIndex = candles.length - 1;
  const flagStartIndex = endIndex - consolidationLength;
  const poleStartIndex = flagStartIndex - flagpoleLength;

  if (poleStartIndex < 0) return null;

  const poleStartCandle = candles[poleStartIndex];
  const poleEndCandle = candles[flagStartIndex];

  const poleHeight = poleStartCandle.high - poleEndCandle.low;
  // Syarat Flagpole: Penurunan tajam minimal 3.5x ATR
  if (poleHeight < atr * 3.5 || poleStartCandle.high <= poleEndCandle.low) return null;

  const flagCandles = candles.slice(flagStartIndex, endIndex + 1);
  const flagHigh = Math.max(...flagCandles.map((c) => c.high));
  const flagLow = Math.min(...flagCandles.map((c) => c.low));
  const flagRetracement = flagHigh - poleEndCandle.low;

  if (flagRetracement > poleHeight * 0.55 || flagHigh - flagLow <= 0) return null;

  const lowerSupport = Number(flagLow.toFixed(2));
  const targetPrice = Number((lowerSupport - poleHeight).toFixed(2));
  const stopLossPrice = Number((flagHigh + atr * 0.4).toFixed(2));
  const distancePips = Math.round(Math.abs(currentPrice - lowerSupport) * 10);

  const isBreakdownActive = currentPrice <= lowerSupport;
  const status: PatternStatus = isBreakdownActive
    ? "BREAKDOWN_CONFIRMED"
    : "POTENTIAL_BREAKDOWN";

  const risk = Math.max(0.1, stopLossPrice - lowerSupport);
  const reward = Math.max(0.1, lowerSupport - targetPrice);
  const rrRatio = `1:${(reward / risk).toFixed(1)}`;

  return {
    id: `pattern-bearflag-${candles[flagStartIndex].time}`,
    name: "Bearish Flag",
    type: "BEARISH",
    status,
    statusLabel: isBreakdownActive
      ? " BREAKDOWN BEARISH FLAG (TEMBUS KE BAWAH)"
      : " PREDIKSI BREAKDOWN: KONSOLIDASI BENDERA TURUN",
    badgeColor: isBreakdownActive ? "rose" : "amber",
    actionRecommendation: isBreakdownActive ? "SELL" : "WAITING BREAKDOWN",
    definition:
      "Konsolidasi setelah tren turun, lalu breakdown ke bawah. SELL setelah breakdown.",
    necklinePrice: lowerSupport,
    triggerPrice: lowerSupport,
    targetPrice,
    stopLossPrice,
    currentPrice,
    distanceToNecklinePips: distancePips,
    probabilityScore: isBreakdownActive ? 90 : 85,
    isBreakoutActive: false,
    isBreakdownActive,
    predictionSummary: isBreakdownActive
      ? `Breakdown dari saluran bendera telah terjadi di $${lowerSupport}. Proyeksi penurunan tiang bendera menargetkan $${targetPrice}.`
      : `Konsolidasi Bearish Flag terbentuk setelah penurunan tajam. Prediksi SELL aktif saat harga breakdown di bawah $${lowerSupport}.`,
    tradingGuideline: isBreakdownActive
      ? `Buka posisi SELL dengan Stop Loss di atas batas atas bendera ($${stopLossPrice}) dan Take Profit di $${targetPrice}.`
      : `Tunggu penembusan support bendera di $${lowerSupport} sebelum melakukan sell order.`,
    keyPoints: [
      { label: "Awal Tiang (Pole High)", time: poleStartCandle.time, price: poleStartCandle.high },
      { label: "Dasar Tiang (Pole Low)", time: poleEndCandle.time, price: poleEndCandle.low },
      { label: "Support Bendera", time: candles[endIndex].time, price: lowerSupport },
      { label: "Resistance Bendera", time: candles[endIndex].time, price: flagHigh },
    ],
    measuredMove: poleHeight,
    riskRewardRatio: rrRatio,
  };
}

/**
 * Master Scanner untuk menemukan semua pola klasik dan memilih pola terbaik/teraktif
 */
export function detectAllClassicPatterns(
  candles: CandleLike[],
  currentPrice: number,
  atr = 2.5
): DetectedChartPattern[] {
  if (!candles || candles.length < 20) return [];

  const swings = findSwings(candles, 4, 3);
  const detected: DetectedChartPattern[] = [];

  const db = detectDoubleBottom(candles, swings, currentPrice, atr);
  if (db) detected.push(db);

  const dt = detectDoubleTop(candles, swings, currentPrice, atr);
  if (dt) detected.push(dt);

  const hs = detectHeadAndShoulders(candles, swings, currentPrice, atr);
  if (hs) detected.push(hs);

  const ihs = detectInverseHeadAndShoulders(candles, swings, currentPrice, atr);
  if (ihs) detected.push(ihs);

  const bFlag = detectBullishFlag(candles, currentPrice, atr);
  if (bFlag) detected.push(bFlag);

  const bearFlag = detectBearishFlag(candles, currentPrice, atr);
  if (bearFlag) detected.push(bearFlag);

  // Urutkan: Terkonfirmasi breakout/breakdown di posisi teratas, lalu probabilitas tertinggi
  return detected.sort((a, b) => {
    if (
      (a.status === "BREAKOUT_CONFIRMED" || a.status === "BREAKDOWN_CONFIRMED") &&
      !(b.status === "BREAKOUT_CONFIRMED" || b.status === "BREAKDOWN_CONFIRMED")
    ) {
      return -1;
    }
    if (
      (b.status === "BREAKOUT_CONFIRMED" || b.status === "BREAKDOWN_CONFIRMED") &&
      !(a.status === "BREAKOUT_CONFIRMED" || a.status === "BREAKDOWN_CONFIRMED")
    ) {
      return 1;
    }
    return b.probabilityScore - a.probabilityScore;
  });
}

/**
 * Mengambil satu pola paling dominan / aktif
 */
export function getPrimaryChartPattern(
  candles: CandleLike[],
  currentPrice: number,
  atr = 2.5
): DetectedChartPattern | null {
  const patterns = detectAllClassicPatterns(candles, currentPrice, atr);
  return patterns.length > 0 ? patterns[0] : null;
}
