export type NewsClassification = "PENGGERAK_PASAR" | "GANGGUAN";
export type NewsSentiment = "BULLISH" | "BEARISH" | "NEUTRAL";
export type ImpactStrength = "KRITIKAL" | "TINGGI" | "SEDANG" | "RENDAH";

export interface PersonalizedNewsArticle {
  id: string;
  title: string;
  source: string;
  url: string;
  publishedAt: number;
  body: string;
  category: "FOREX" | "CRYPTO" | "MACRO" | "COMMODITY";
  targetAsset: "XAUUSD" | "BTCUSD" | "ALL" | string;
  classification: NewsClassification;
  classificationRationale: string;
  sentiment: NewsSentiment;
  sentimentScore: number; // -100 to +100
  assetImpactScore: number; // 0 to 100
  impactStrength: ImpactStrength;
  marketDriverTags: string[];
  noiseReason?: string;
  actionableAdvice: string;
  institutionalCorrelation?: string;
  expectedPipsImpact?: string;
}

export interface AssetNewsIntelligence {
  symbolId: string;
  dominantBias: "BULLISH" | "BEARISH" | "NEUTRAL";
  sentimentScore: number; // -100 to +100
  marketMoversCount: number;
  noiseCount: number;
  totalArticles: number;
  signalToNoiseRatio: number; // percentage (0 - 100%)
  
  // Dynamic Volatility Adaptation Parameters
  volatilityShockMultiplier: number; // 1.0x to 1.8x
  dynamicAtrBufferPips: number; // Additional safety buffer
  volatilityRegime: "KOMPRESI (SQUEEZE)" | "EKSPANSI MODERAT" | "VOLATILITAS TINGGI (EXPANSION)" | "LONJAKAN EKSTRIM (SHOCK SPIKE)";
  volatilityActionAdvice: string;
  
  // Signal Strengthening Metrics
  confluenceConfidenceBoost: number; // e.g. +3% to +5%
  isMoverAlignedWithSignal: (direction: "BUY" | "SELL") => boolean;
  topCatalysts: string[];
  actionableSignalVerdict: string;
  institutionalSynthesis: string;
  latestMover?: PersonalizedNewsArticle;
  articles: PersonalizedNewsArticle[];
}

// Master Institutional Knowledgebase for Asset-Filtered News
export const MASTER_ASSET_NEWS_ARTICLES: PersonalizedNewsArticle[] = [
  // --- XAUUSD / GOLD SPECIFIC PENGGERAK PASAR & GANGGUAN ---
  {
    id: "xau-mover-1",
    title: "Federal Reserve & Kevin Warsh Sinyalkan Siklus Pemotongan Suku Bunga Agresif Pasca Data Tenaga Kerja Mendingin",
    source: "Bloomberg Macro Intelligence",
    url: "https://www.bloomberg.com/markets",
    publishedAt: Date.now() - 7 * 60 * 1000,
    body: "Pernyataan terbaru pejabat The Fed menegaskan kesiapan penurunan suku bunga acuan (Fed Funds Rate) 25-50 bps. Yield US 10-Tahun turun ke 4.07% dan DXY tertekan ke 103.45.",
    category: "MACRO",
    targetAsset: "XAUUSD",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Pelonggaran moneter The Fed dan pelemahan yield riil obligasi merupakan katalis fundamental utama penentu tren reli Spot Gold (XAUUSD). Arus modal langsung berpindah ke aset tanpa imbal hasil (non-yielding bullion).",
    sentiment: "BULLISH",
    sentimentScore: 92,
    assetImpactScore: 96,
    impactStrength: "KRITIKAL",
    marketDriverTags: ["Kebijakan The Fed", "Pelemahan DXY", "Yield Drop", "Siklus Dovish"],
    actionableAdvice: "Validasi kuat untuk posisi BUY XAUUSD. Tunggu diskon retracement ke level OTE (Fibonacci 0.618) untuk eksekusi tanpa mengejar harga pucuk.",
    institutionalCorrelation: "Korelasi negatif DXY (-0.89). JPMorgan & Goldman Sachs mencatat inflow bullion +$420M.",
    expectedPipsImpact: "+120 s/d +180 Pips Ekspansi Bullish"
  },
  {
    id: "xau-mover-2",
    title: "Bank Sentral Global (PBoC & RBI) Tambah Akumulasi Cadangan Emas Fisik 40.7 Ton Bulan Ini",
    source: "Reuters Financial / World Gold Council",
    url: "https://www.reuters.com",
    publishedAt: Date.now() - 28 * 60 * 1000,
    body: "Laporan resmi World Gold Council menunjukkan pembelian emas oleh People's Bank of China dan Reserve Bank of India mencapai rekor tertinggi kuartal ini untuk dedolarisasi cadangan devisa.",
    category: "COMMODITY",
    targetAsset: "XAUUSD",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Pembelian bank sentral adalah order flow institusional permanen tanpa leverage yang menciptakan 'Structural Floor Price' pada level support mayor.",
    sentiment: "BULLISH",
    sentimentScore: 88,
    assetImpactScore: 91,
    impactStrength: "TINGGI",
    marketDriverTags: ["Central Bank Inflow", "Dedolarisasi", "Structural Support"],
    actionableAdvice: "Support demand level divalidasi sangat kokoh. Pantang mengambil posisi SELL jangka menengah saat bank sentral terus menyerap supply.",
    institutionalCorrelation: "Net buying institusi +40.7 Ton/bulan mengunci likuiditas jual.",
    expectedPipsImpact: "+75 s/d +110 Pips Penopang Support"
  },
  {
    id: "xau-noise-1",
    title: "Analis Medsos Prediksi Emas Turun Karena Pola Candlestick 1-Menit di Akun Twitter/X",
    source: "Retail Trader Social Digest",
    url: "https://twitter.com",
    publishedAt: Date.now() - 14 * 60 * 1000,
    body: "Sebuah tweet viral mengklaim emas akan crash akibat pembentukan double top di chart M1 dengan volume perdagangan rendah pada akhir sesi Asia.",
    category: "COMMODITY",
    targetAsset: "XAUUSD",
    classification: "GANGGUAN",
    classificationRationale: "Analisis bersumber dari opini retail time-frame sangat rendah (M1) tanpa backing volume institusi dan tanpa korelasi data makroekonomi riil. Pola ini rentan terhadap noise likuiditas.",
    noiseReason: "Opini Spekulatif Retail Tanpa Bobot Makro / Noise M1",
    sentiment: "NEUTRAL",
    sentimentScore: -5,
    assetImpactScore: 12,
    impactStrength: "RENDAH",
    marketDriverTags: ["Noise Retail", "Spekulasi Medsos", "False Alarm"],
    actionableAdvice: "Abaikan total (Filter Noise Aktif). Jangan terprovokasi menutup posisi BUY atau panik mengambil SELL prematur hanya karena obrolan media sosial.",
    institutionalCorrelation: "Nol interaksi pada institutional order book COMEX.",
    expectedPipsImpact: "0 Pips (Netral / Fluktuasi Spreading)"
  },
  {
    id: "xau-mover-3",
    title: "Departemen Keuangan AS Rilis Jadwal Lelang Obligasi $36T: Menkeu Scott Bessent Jaga Yield Tetap Terkendali",
    source: "Financial Times",
    url: "https://www.ft.com",
    publishedAt: Date.now() - 48 * 60 * 1000,
    body: "Menkeu Scott Bessent memprioritaskan batas imbal hasil obligasi jangka panjang guna menjaga stabilitas pasar surat utang negara, mencegah lonjakan yield riil obligasi AS.",
    category: "MACRO",
    targetAsset: "XAUUSD",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Kebijakan capping yield oleh US Treasury membatasi penguatan Dolar AS dan memberikan ruang napas tak terbatas bagi reli aset lindung nilai logam mulia.",
    sentiment: "BULLISH",
    sentimentScore: 84,
    assetImpactScore: 87,
    impactStrength: "TINGGI",
    marketDriverTags: ["US Treasury", "Yield Management", "Macro Driver"],
    actionableAdvice: "Momentum pasar mendukung kelanjutan bullish swing. Pasang trailing stop loss di bawah swing low H1 untuk mengunci profit bertahap.",
    institutionalCorrelation: "Wall Street Primary Dealers mempertahankan alokasi overweight Gold.",
    expectedPipsImpact: "+60 s/d +95 Pips"
  },
  {
    id: "xau-noise-2",
    title: "Perusahaan Tambang Emas Lokal di Peru Laporkan Pemeliharaan Mesin Rutin Selama 2 Hari",
    source: "Mining Regional Gazette",
    url: "https://mining.com",
    publishedAt: Date.now() - 65 * 60 * 1000,
    body: "Tambang skala menengah mengumumkan penundaan produksi minor untuk servis alat berat rutin. Tidak memengaruhi neraca supply bullion global secara material.",
    category: "COMMODITY",
    targetAsset: "XAUUSD",
    classification: "GANGGUAN",
    classificationRationale: "Peristiwa operasional mikro lokal yang tidak memiliki dampak signifikan terhadap neraca perdagangan global atau harga spot COMEX/LBMA.",
    noiseReason: "Informasi Mikro Lokal Tidak Berdampak Sistemik",
    sentiment: "NEUTRAL",
    sentimentScore: 0,
    assetImpactScore: 8,
    impactStrength: "RENDAH",
    marketDriverTags: ["Mikro Lokal", "Noise Supply", "Non-Katalis"],
    actionableAdvice: "Abaikan. Tidak memerlukan penyesuaian strategi trading atau manajemen lot.",
    institutionalCorrelation: "Tidak ada pengaruh terhadap spread atau likuiditas London fixing.",
    expectedPipsImpact: "0 Pips"
  },

  // --- BTCUSD / BITCOIN SPECIFIC PENGGERAK PASAR & GANGGUAN ---
  {
    id: "btc-mover-1",
    title: "Spot Bitcoin ETF Catat Net Inflow Institusional +$1.85 Miliar dalam 48 Jam Terakhir",
    source: "CoinDesk / Bloomberg Terminal",
    url: "https://www.coindesk.com",
    publishedAt: Date.now() - 11 * 60 * 1000,
    body: "BlackRock IBIT dan Fidelity FBTC melaporkan lonjakan penyerapan likuiditas Bitcoin dari dana pensiun dan manajer investasi global. Order book spot mengalami supply crunch.",
    category: "CRYPTO",
    targetAsset: "BTCUSD",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Arus modal masuk institusional (Institutional ETF Inflow) langsung mengurangi pasokan koin di bursa terpusat, menjadi pendorong utama dorongan reli harga spot.",
    sentiment: "BULLISH",
    sentimentScore: 94,
    assetImpactScore: 98,
    impactStrength: "KRITIKAL",
    marketDriverTags: ["ETF Spot Inflow", "Supply Squeeze", "Institutional Liquidity"],
    actionableAdvice: "Konfirmasi kuat sinyal BUY BTCUSD. Prioritaskan entry pada retest level Support/Order Block M15-H1.",
    institutionalCorrelation: "Net inflow kas riil +$1.85B langsung memicu likuidasi posisi short penjual.",
    expectedPipsImpact: "+$1,500 s/d +$3,200 Pergerakan Harga BTC"
  },
  {
    id: "btc-mover-2",
    title: "Donald Trump & Regulator AS Percepat Kerangka Hukum Cadangan Strategis Aset Kripto Nasional",
    source: "Wall Street Journal",
    url: "https://www.wsj.com",
    publishedAt: Date.now() - 32 * 60 * 1000,
    body: "Inisiatif pembuatan 'Strategic Bitcoin Reserve' dan deregulasi industri perbankan kripto mendapat persetujuan komite legislatif, menghapus hambatan regulasi.",
    category: "CRYPTO",
    targetAsset: "BTCUSD",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Regulasi tingkat negara adidaya memberikan legitimasi status aset berdaulat bagi Bitcoin, memicu reposisi portofolio institusi multi-miliar dolar.",
    sentiment: "BULLISH",
    sentimentScore: 90,
    assetImpactScore: 93,
    impactStrength: "TINGGI",
    marketDriverTags: ["Regulasi AS", "Strategic Reserve", "Legitimasi Kripto"],
    actionableAdvice: "Pertahankan bias trend-following bullish. Hindari melawan tren dengan melakukan counter-trend sell.",
    institutionalCorrelation: "Sentimen pasar derivatif mencatat Call/Put Ratio 3.8x (Dominasi Beli).",
    expectedPipsImpact: "+$1,200 s/d +$2,500"
  },
  {
    id: "btc-noise-1",
    title: "Akun Meme Kripto Klaim Koin Katak Akan Gantikan Dominasi Bitcoin di Musim Ini",
    source: "Meme Coin Hype Daily",
    url: "https://reddit.com/r/cryptocurrency",
    publishedAt: Date.now() - 19 * 60 * 1000,
    body: "Thread di forum media sosial mendiskusikan rotasi spekulatif ke altcoin mikro tanpa dasar likuiditas atau utilitas institusional riil.",
    category: "CRYPTO",
    targetAsset: "BTCUSD",
    classification: "GANGGUAN",
    classificationRationale: "Distraksi spekulatif ritel murni. Tidak ada volume dana institusional atau dampak likuiditas terhadap pasangan perdagangan BTCUSD.",
    noiseReason: "Hype Spekulasi Altcoin / Distraksi Retail",
    sentiment: "NEUTRAL",
    sentimentScore: -2,
    assetImpactScore: 6,
    impactStrength: "RENDAH",
    marketDriverTags: ["Noise Ritel", "Meme Hype", "Non-Actionable"],
    actionableAdvice: "Abaikan total. Jangan terdistraksi dari setup sinyal kuantitatif aset utama.",
    institutionalCorrelation: "Nol dampak pada derivatif CME atau order book Binance.",
    expectedPipsImpact: "0 Pips"
  },
  {
    id: "btc-noise-2",
    title: "Bursa Kripto Skala Kecil di Negara Berkembang Lakukan Maintenance Server 30 Menit",
    source: "Crypto Infra Updates",
    url: "https://coingecko.com",
    publishedAt: Date.now() - 52 * 60 * 1000,
    body: "Exchange regional mengumumkan pemeliharaan database terjadwal. Volume perdagangan bursa tersebut mencakup kurang dari 0.01% pasar global.",
    category: "CRYPTO",
    targetAsset: "BTCUSD",
    classification: "GANGGUAN",
    classificationRationale: "Pemeliharaan teknis rutin bursa periferal tidak mengubah struktur likuiditas atau tren pasar makro.",
    noiseReason: "Maintenance Server Lokal Minor",
    sentiment: "NEUTRAL",
    sentimentScore: 0,
    assetImpactScore: 4,
    impactStrength: "RENDAH",
    marketDriverTags: ["Maintenance Rutin", "Noise Teknis"],
    actionableAdvice: "Tidak ada aksi yang diperlukan. Indikator dan chart beroperasi normal.",
    institutionalCorrelation: "Likuiditas global di Binance, Coinbase, dan Deribit 100% normal.",
    expectedPipsImpact: "0 Pips"
  },

  // --- MULTI-ASSET MACRO DRIVER ---
  {
    id: "macro-mover-core",
    title: "Konsensus Rilis Data Inflasi AS (Core PCE & CPI): Penurunan Berlanjut Mendekati Target 2.0%",
    source: "Federal Reserve Board / Bureau of Labor Statistics",
    url: "https://www.bls.gov",
    publishedAt: Date.now() - 41 * 60 * 1000,
    body: "Proyeksi inflasi konsumen menunjukkan tren disinflasi solid. Mengonfirmasi ruang bagi pelonggaran moneter simultan yang menguntungkan Emas (XAUUSD) dan Bitcoin (BTCUSD).",
    category: "MACRO",
    targetAsset: "ALL",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Data inflasi AS adalah rilis 'Tier-1 High Impact' nomor satu yang mengubah kalkulasi valuasi seluruh aset denominasi USD di seluruh dunia.",
    sentiment: "BULLISH",
    sentimentScore: 89,
    assetImpactScore: 95,
    impactStrength: "KRITIKAL",
    marketDriverTags: ["Core PCE", "CPI AS", "Disinflasi", "High Impact Tier-1"],
    actionableAdvice: "Sinyal BUY pada Gold & Bitcoin terkonfirmasi sangat valid (+EV). Amankan risiko dengan rasio risk-reward minimal 1:2.",
    institutionalCorrelation: "DXY Dollar melemah serentak terhadap komoditas dan kripto.",
    expectedPipsImpact: "+90 s/d +160 Pips XAUUSD | +$1,800 BTCUSD"
  },

  // --- US100 / NASDAQ SPECIFIC PENGGERAK PASAR & GANGGUAN ---
  {
    id: "us100-mover-1",
    title: "AI Infrastructure CapEx & Kinerja Keuangan Raksasa Teknologi Lampaui Estimasi Wall Street",
    source: "Wall Street Journal Technology Macro",
    url: "https://www.wsj.com/market-data",
    publishedAt: Date.now() - 11 * 60 * 1000,
    body: "Laporan laba kuartalan Magnificent 7 (NVIDIA, Microsoft, Apple, Alphabet) mengonfirmasi belanja modal pusat data AI meningkat 42% YoY. Arus dana institusional (inflow) ETF QQQ melonjak ke rekor tertinggi bulanan.",
    category: "MACRO",
    targetAsset: "US100",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Pertumbuhan laba riil dan ekspansi belanja modal kecerdasan buatan merupakan pilar struktural utama pergerakan indeks US100 NASDAQ, memicu dorongan reli institusional yang berkelanjutan.",
    sentiment: "BULLISH",
    sentimentScore: 94,
    assetImpactScore: 97,
    impactStrength: "KRITIKAL",
    marketDriverTags: ["Mega-Cap Tech", "AI CapEx Boom", "Inflow QQQ ETF", "Earnings Beat"],
    actionableAdvice: "Validasi posisi BUY pada retracement ke area OTE 0.618 / FVG Bullish di sesi New York Killzone.",
    institutionalCorrelation: "Korelasi positif sangat kuat dengan selera risiko (Risk-On) global dan momentum indeks S&P 500.",
    expectedPipsImpact: "+120 s/d +260 Points US100"
  },
  {
    id: "us100-mover-2",
    title: "Imbal Hasil US 10Y Treasury Turun Menuju 4.12%: Ruang Valuasi Saham Pertumbuhan Terbuka Lebar",
    source: "Bloomberg Rates & Equities",
    url: "https://www.bloomberg.com/markets",
    publishedAt: Date.now() - 28 * 60 * 1000,
    body: "Ekspektasi pelonggaran moneter The Fed menekan kurva imbal hasil obligasi AS. Penurunan diskonto suku bunga memicu ekspansi rasio Price-to-Earnings (P/E) saham-saham sektor teknologi Nasdaq 100.",
    category: "MACRO",
    targetAsset: "US100",
    classification: "PENGGERAK_PASAR",
    classificationRationale: "Valuasi saham teknologi berbasis arus kas masa depan sangat sensitif terhadap suku bunga bebas risiko (risk-free rate). Penurunan yield 10Y menurunkan biaya modal dan mendongkrak valuasi US100.",
    sentiment: "BULLISH",
    sentimentScore: 88,
    assetImpactScore: 92,
    impactStrength: "TINGGI",
    marketDriverTags: ["Treasury Yields Drop", "Valuation Expansion", "Tech Multiples", "Fed Rate Cuts"],
    actionableAdvice: "Tekanan jual mereda drastis; pertahankan target profit hingga zona Sell-Side Liquidity tertutup.",
    institutionalCorrelation: "Korelasi terbalik dengan yield obligasi AS dan indeks DXY.",
    expectedPipsImpact: "+80 s/d +180 Points US100"
  },
  {
    id: "us100-noise-1",
    title: "Komentar Spekulatif Forum Media Sosial Terkait Rotasi Sektor Harian Saham Siklikal",
    source: "Retail Trader Social Gossip",
    url: "https://twitter.com/search",
    publishedAt: Date.now() - 42 * 60 * 1000,
    body: "Klaim tanpa data bahwa investor ritel akan keluar dari saham teknologi menuju sektor defensif utilitas dalam kurun waktu 2 jam ke depan.",
    category: "MACRO",
    targetAsset: "US100",
    classification: "GANGGUAN",
    classificationRationale: "Opini akun anonim ritel tanpa didukung data transaksi order book institusional, volume exchange, atau pergeseran portofolio dana pensiun (noise).",
    sentiment: "NEUTRAL",
    sentimentScore: -4,
    assetImpactScore: 16,
    impactStrength: "RENDAH",
    marketDriverTags: ["Noise Ritel", "Spekulasi", "Tanpa Volume"],
    noiseReason: "Tidak memiliki bobot data empiris atau transaksi dark pool institusi. Abaikan!",
    actionableAdvice: "Fokus pada struktur market SMC M15/H1 dan order flow volume institusional asli.",
    institutionalCorrelation: "Nol korelasi dengan aliran dana likuiditas Wall Street.",
    expectedPipsImpact: "0 Pips (Fluktuasi Noise Normal)"
  }
];

/**
 * Filter news strictly for the target asset
 */
export function getAssetPersonalizedNews(symbolId: string, sourceArticles = MASTER_ASSET_NEWS_ARTICLES): PersonalizedNewsArticle[] {
  const isGold = symbolId.toUpperCase().includes("XAU") || symbolId.toUpperCase().includes("GOLD");
  const isBtc = symbolId.toUpperCase().includes("BTC") || symbolId.toUpperCase().includes("BITCOIN");
  const isUs100 = symbolId.toUpperCase().includes("US100") || symbolId.toUpperCase().includes("NAS100") || symbolId.toUpperCase().includes("NASDAQ");

  return sourceArticles.filter((art) => {
    if (art.targetAsset === "ALL") return true;
    if (isGold && art.targetAsset === "XAUUSD") return true;
    if (isBtc && art.targetAsset === "BTCUSD") return true;
    if (isUs100 && (art.targetAsset === "US100" || art.targetAsset === "NAS100")) return true;
    return art.targetAsset === symbolId;
  });
}

/**
 * Computes deep institutional sentiment and dynamic volatility parameters
 * for signal engine integration.
 */
export function computeAssetNewsIntelligence(
  symbolId: string,
  sourceArticles = MASTER_ASSET_NEWS_ARTICLES
): AssetNewsIntelligence {
  const articles = getAssetPersonalizedNews(symbolId, sourceArticles);
  const isGold = symbolId.toUpperCase().includes("XAU") || symbolId.toUpperCase().includes("GOLD");
  const isBtc = symbolId.toUpperCase().includes("BTC") || symbolId.toUpperCase().includes("BITCOIN");
  const isUs100 = symbolId.toUpperCase().includes("US100") || symbolId.toUpperCase().includes("NAS100") || symbolId.toUpperCase().includes("NASDAQ");

  const movers = articles.filter((a) => a.classification === "PENGGERAK_PASAR");
  const noise = articles.filter((a) => a.classification === "GANGGUAN");
  const total = articles.length;

  const moverCount = movers.length;
  const noiseCount = noise.length;
  const signalToNoiseRatio = total > 0 ? Math.round((moverCount / total) * 100) : 85;

  // Calculate weighted mover sentiment score
  const avgMoverSentimentScore = moverCount > 0
    ? Math.round(movers.reduce((acc, m) => acc + m.sentimentScore * (m.assetImpactScore / 100), 0) /
        movers.reduce((acc, m) => acc + (m.assetImpactScore / 100), 0))
    : 80;

  const dominantBias: "BULLISH" | "BEARISH" | "NEUTRAL" =
    avgMoverSentimentScore > 25 ? "BULLISH" : avgMoverSentimentScore < -25 ? "BEARISH" : "NEUTRAL";

  // Volatility shock detection: If critical movers are present
  const hasCriticalMover = movers.some((m) => m.impactStrength === "KRITIKAL" || m.assetImpactScore >= 95);
  const maxImpactScore = movers.length > 0 ? Math.max(...movers.map((m) => m.assetImpactScore)) : 50;

  let volatilityShockMultiplier = 1.0;
  let dynamicAtrBufferPips = 0;
  let volatilityRegime: AssetNewsIntelligence["volatilityRegime"] = "EKSPANSI MODERAT";
  let volatilityActionAdvice = "";

  if (hasCriticalMover || maxImpactScore >= 95) {
    volatilityShockMultiplier = 1.55;
    dynamicAtrBufferPips = isBtc ? 450 : isUs100 ? 45.0 : 25.0;
    volatilityRegime = "LONJAKAN EKSTRIM (SHOCK SPIKE)";
    volatilityActionAdvice = `KATALIS KRITIKAL TERDETEKSI: Volatilitas melebar. Buffer SL dilebarkan +${dynamicAtrBufferPips} pips/pts untuk mencegah false sweep!`;
  } else if (maxImpactScore >= 85) {
    volatilityShockMultiplier = 1.30;
    dynamicAtrBufferPips = isBtc ? 250 : isUs100 ? 25.0 : 15.0;
    volatilityRegime = "VOLATILITAS TINGGI (EXPANSION)";
    volatilityActionAdvice = "EKSPANSI TREN: Penggerak pasar institusional mengonfirmasi momentum berkelanjutan.";
  } else if (moverCount > 0) {
    volatilityShockMultiplier = 1.15;
    dynamicAtrBufferPips = isBtc ? 120 : isUs100 ? 12.0 : 8.0;
    volatilityRegime = "EKSPANSI MODERAT";
    volatilityActionAdvice = "ARUS NORMAL: Sinyal berjalan sesuai model matematis standar.";
  } else {
    volatilityShockMultiplier = 1.0;
    dynamicAtrBufferPips = 0;
    volatilityRegime = "KOMPRESI (SQUEEZE)";
    volatilityActionAdvice = "PASAR TENANG: Menunggu rilis data berdampak tinggi berikutnya.";
  }

  const confluenceConfidenceBoost = Math.min(6, Math.max(2, Math.round((signalToNoiseRatio / 100) * 5)));

  const latestMover = movers.length > 0 ? movers[0] : undefined;

  const topCatalysts = Array.from(new Set(movers.flatMap((m) => m.marketDriverTags))).slice(0, 5);

  let actionableSignalVerdict = "";
  if (dominantBias === "BULLISH") {
    actionableSignalVerdict = ` Umpan Berita ${symbolId}: Katalis Penggerak Pasar (${signalToNoiseRatio}% SNR) memvalidasi bias BULLISH. Inflow institusi & sentimen makro memperkuat sinyal BUY dengan buffer volatilitas +${dynamicAtrBufferPips} pips.`;
  } else if (dominantBias === "BEARISH") {
    actionableSignalVerdict = ` Umpan Berita ${symbolId}: Sentimen Pasar Bearish mendominasi. Tekanan supply institusional mengonfirmasi sinyal SELL dengan buffer proteksi risiko optimal.`;
  } else {
    actionableSignalVerdict = ` Umpan Berita ${symbolId}: Sentimen netral terkonsolidasi. Menjaga disiplin Risk-Reward 1:2.5+ pada area OTE.`;
  }

  const institutionalSynthesis = `${symbolId} didorong oleh ${moverCount} Katalis Penggerak Pasar (${topCatalysts.join(", ") || "Makro Dolar AS & Likuiditas Global"}). ${noiseCount} artikel gangguan ritel berhasil difilter untuk menjaga akurasi sinyal tetap murni.`;

  return {
    symbolId,
    dominantBias,
    sentimentScore: avgMoverSentimentScore,
    marketMoversCount: moverCount,
    noiseCount,
    totalArticles: total,
    signalToNoiseRatio,
    volatilityShockMultiplier,
    dynamicAtrBufferPips,
    volatilityRegime,
    volatilityActionAdvice,
    confluenceConfidenceBoost,
    isMoverAlignedWithSignal: (direction: "BUY" | "SELL") => {
      if (dominantBias === "BULLISH" && direction === "BUY") return true;
      if (dominantBias === "BEARISH" && direction === "SELL") return true;
      return false;
    },
    topCatalysts,
    actionableSignalVerdict,
    institutionalSynthesis,
    latestMover,
    articles
  };
}
