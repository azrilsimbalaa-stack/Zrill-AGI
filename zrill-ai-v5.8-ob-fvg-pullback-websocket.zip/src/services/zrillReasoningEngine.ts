import fs from "fs";
import path from "path";

/**
 * Zrill Native Reasoning Core
 *
 * This engine intentionally does NOT call another AI/model.
 * It reasons from the live observations supplied by the server using its own
 * state machine, statistical measurements, market-structure tests, conflict
 * resolution and persistent experience memory.
 *
 * It is an autonomous software reasoning system, not a conscious human mind.
 */

export type ReasoningState = {
  status: "THINKING" | "READY" | "FEED_RECOVERY" | "ERROR";
  symbol: string;
  decision: "BUY" | "SELL" | "NO_VALID_SETUP" | "FEED_RECOVERY";
  confidence: number;
  reasoning: string;
  why: string[];
  whyNotOpposite: string[];
  invalidation: string[];
  emotionalState: string;
  internalDialogue: string;
  nextObservation: string;
  timestamp: number;
  cycle: number;
};

type Candle = { time: number; open: number; high: number; low: number; close: number; volume?: number };
type LearningModel = {
  version: number;
  samples: number;
  wins: number;
  losses: number;
  weights: Record<string, number>;
  featureStats: Record<string, { mean: number; variance: number; n: number }>;
  lastUpdate: number;
};

type MemoryItem = {
  timestamp: number;
  symbol: string;
  fingerprint: string;
  regime: string;
  decision: ReasoningState["decision"];
  outcome?: "TP" | "SL" | "REVERSAL" | "NO_TRADE" | "UNKNOWN";
  features: Record<string, number | string>;
};

type Candidate = {
  side: "BUY" | "SELL";
  score: number;
  evidence: string[];
  risks: string[];
  features: Record<string, number | string>;
};

type FundamentalContext = {
  events?: any[];
  dxy?: { price: number; chp?: number; updatedAt?: number } | null;
  us10y?: { price: number; chp?: number; updatedAt?: number } | null;
  news?: any[];
};

function numeric(v: unknown): number | null {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v !== "string" || !v.trim()) return null;
  const n = Number(v.replace(/,/g, "").replace(/%/g, "").replace(/[^0-9.+-]/g, ""));
  return Number.isFinite(n) ? n : null;
}

function usdMacroDirection(event: any): { direction: "BUY" | "SELL" | "NEUTRAL"; strength: number; text: string } {
  const title = String(event?.title || "").toLowerCase();
  const actual = numeric(event?.actual), forecast = numeric(event?.forecast), previous = numeric(event?.previous);
  const released = actual !== null;
  const reference = released ? forecast : previous;
  if (reference === null || (released && actual === null)) return { direction: "NEUTRAL", strength: 0, text: "Event belum memiliki angka pembanding yang cukup." };
  const value = released ? actual! : forecast!;
  const delta = value - reference;
  const scale = Math.max(Math.abs(reference) * 0.01, 0.01);
  const normalized = clamp(delta / scale, -6, 6);
  const laborWeak = /unemployment|jobless|claims/.test(title);
  const usdBullishHigher = !laborWeak;
  const usdImpulse = normalized * (usdBullishHigher ? 1 : -1);
  const xauDirection = usdImpulse > 0.05 ? "SELL" : usdImpulse < -0.05 ? "BUY" : "NEUTRAL";
  const strength = clamp(Math.abs(usdImpulse) * (String(event?.forexFactoryImpact || "").toUpperCase() === "HIGH" ? 2.5 : 1.2), 0, 10);
  const basis = released ? `Actual vs Forecast ${delta >= 0 ? "+" : ""}${delta.toFixed(3)}` : `Forecast vs Previous ${delta >= 0 ? "+" : ""}${delta.toFixed(3)}`;
  return { direction: xauDirection as any, strength, text: `${event?.title || "Macro event"}: ${basis}; implikasi XAU ${xauDirection}.` };
}

function fundamentalReasoning(ctx: FundamentalContext, side: "BUY" | "SELL") {
  const events = Array.isArray(ctx.events) ? ctx.events : [];
  const now = Date.now();
  const relevant = events.filter(e => String(e?.currency || "").toUpperCase() === "USD").filter(e => {
    const t = new Date(e?.date || e?.time || 0).getTime();
    return Number.isFinite(t) && Math.abs(t - now) <= 72 * 60 * 60 * 1000;
  }).slice(-30);
  let signed = 0; const evidence: string[] = [];
  for (const e of relevant) {
    const r = usdMacroDirection(e);
    if (r.direction === side) { signed += r.strength; evidence.push(r.text); }
    else if (r.direction !== "NEUTRAL") signed -= r.strength;
  }
  // Cross-asset confirmation is a secondary vote, never a standalone trigger.
  if (side === "BUY") {
    if (ctx.dxy?.chp !== undefined && ctx.dxy.chp < -0.05) signed += 4;
    if (ctx.us10y?.chp !== undefined && ctx.us10y.chp < -0.05) signed += 4;
    if (ctx.dxy?.chp !== undefined && ctx.dxy.chp > 0.05) signed -= 4;
    if (ctx.us10y?.chp !== undefined && ctx.us10y.chp > 0.05) signed -= 4;
  } else {
    if (ctx.dxy?.chp !== undefined && ctx.dxy.chp > 0.05) signed += 4;
    if (ctx.us10y?.chp !== undefined && ctx.us10y.chp > 0.05) signed += 4;
    if (ctx.dxy?.chp !== undefined && ctx.dxy.chp < -0.05) signed -= 4;
    if (ctx.us10y?.chp !== undefined && ctx.us10y.chp < -0.05) signed -= 4;
  }
  const score = clamp(signed, -18, 18);
  return { score, evidence: evidence.slice(-5), text: `Fundamental ${side}: score ${score.toFixed(1)} dari event makro dan konfirmasi cross-asset yang tersedia.` };
}

const dataDir = path.join(process.cwd(), "data");
const memoryPath = path.join(dataDir, "zrill-native-memory.json");
const statePath = path.join(dataDir, "zrill-consciousness-state.json");
const learningPath = path.join(dataDir, "zrill-native-learning.json");

function safeRead<T>(file: string, fallback: T): T {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch { return fallback; }
}

function safeWrite(file: string, value: unknown) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(value, null, 2));
  } catch (err) {
    console.warn("[ZrillNativeReasoning] persistence failed:", err instanceof Error ? err.message : err);
  }
}

const clamp = (v: number, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
const sigmoid = (x: number) => 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, x))));

const DEFAULT_LEARNING: LearningModel = {
  version: 1, samples: 0, wins: 0, losses: 0,
  weights: {}, featureStats: {}, lastUpdate: 0
};
const finite = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);
const mean = (a: number[]) => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
const last = <T>(a: T[]) => a[a.length - 1];

function atr(c: Candle[], period = 14): number {
  if (c.length < period + 1) return 0;
  const tr: number[] = [];
  for (let i = Math.max(1, c.length - period); i < c.length; i++) {
    const x = c[i], p = c[i - 1];
    tr.push(Math.max(x.high - x.low, Math.abs(x.high - p.close), Math.abs(x.low - p.close)));
  }
  return mean(tr);
}

function ema(c: Candle[], period: number): number {
  if (c.length < period) return 0;
  let e = mean(c.slice(0, period).map(x => x.close));
  const k = 2 / (period + 1);
  for (let i = period; i < c.length; i++) e = c[i].close * k + e * (1 - k);
  return e;
}

function efficiency(c: Candle[], period = 20): number {
  if (c.length < period + 1) return 0;
  const s = c.slice(-period - 1);
  const net = Math.abs(last(s)!.close - s[0].close);
  const path = mean([]) + s.slice(1).reduce((n, x, i) => n + Math.abs(x.close - s[i].close), 0);
  return path > 0 ? net / path : 0;
}

function slope(c: Candle[], period = 20, lookback = 6): number {
  if (c.length < period + lookback) return 0;
  const now = ema(c, period);
  const prev = ema(c.slice(0, -lookback), period);
  const a = atr(c, 14);
  return a > 0 ? (now - prev) / a : 0;
}

function bodyRatio(x: Candle): number {
  const r = x.high - x.low;
  return r > 0 ? Math.abs(x.close - x.open) / r : 0;
}

function pivotLevels(c: Candle[], side: "high" | "low", strength = 2) {
  const out: number[] = [];
  for (let i = strength; i < c.length - strength; i++) {
    const p = side === "high" ? c[i].high : c[i].low;
    let ok = true;
    for (let j = 1; j <= strength; j++) {
      if (side === "high" && (p < c[i - j].high || p < c[i + j].high)) ok = false;
      if (side === "low" && (p > c[i - j].low || p > c[i + j].low)) ok = false;
    }
    if (ok) out.push(p);
  }
  return out.slice(-8);
}

function parseCandles(value: unknown): Candle[] {
  if (!Array.isArray(value)) return [];
  return value.map((x: any) => ({
    time: Number(x?.time ?? x?.timestamp ?? 0),
    open: Number(x?.open), high: Number(x?.high), low: Number(x?.low), close: Number(x?.close),
    volume: finite(Number(x?.volume)) ? Number(x.volume) : undefined
  })).filter(x => x.time > 0 && [x.open, x.high, x.low, x.close].every(finite));
}

function regime(c: Candle[]) {
  if (c.length < 60) return "UNKNOWN";
  const a = atr(c), e = efficiency(c), s = slope(c);
  const e20 = ema(c, 20), e50 = ema(c, 50);
  const recent = c.slice(-24);
  const width = Math.max(...recent.map(x => x.high)) - Math.min(...recent.map(x => x.low));
  const compression = a > 0 ? width / a : 99;
  if (e < 0.36 && compression < 8 && Math.abs(s) < 0.75) return "CONSOLIDATION";
  if (e20 > e50 && s > 0.25 && e >= 0.38) return "TREND_UP";
  if (e20 < e50 && s < -0.25 && e >= 0.38) return "TREND_DOWN";
  if (compression > 8 && e > 0.55) return "EXPANSION";
  return "RANGE";
}

function structure(c: Candle[], side: "BUY" | "SELL") {
  const a = atr(c);
  const highs = pivotLevels(c, "high");
  const lows = pivotLevels(c, "low");
  if (highs.length < 2 || lows.length < 2 || !a) return { score: 0, text: "Struktur belum cukup terbentuk." };
  const hh = highs.at(-1)! > highs.at(-2)! + a * 0.08;
  const hl = lows.at(-1)! > lows.at(-2)! + a * 0.08;
  const lh = highs.at(-1)! < highs.at(-2)! - a * 0.08;
  const ll = lows.at(-1)! < lows.at(-2)! - a * 0.08;
  if (side === "BUY" && hh && hl) return { score: 22, text: "Higher High + Higher Low mendukung struktur bullish." };
  if (side === "SELL" && lh && ll) return { score: 22, text: "Lower High + Lower Low mendukung struktur bearish." };
  if (side === "BUY" && (hh || hl)) return { score: 9, text: "Sebagian struktur bullish terbentuk, tetapi belum lengkap." };
  if (side === "SELL" && (lh || ll)) return { score: 9, text: "Sebagian struktur bearish terbentuk, tetapi belum lengkap." };
  return { score: 0, text: "Struktur tidak memberi keunggulan jelas." };
}

function displacement(c: Candle[], side: "BUY" | "SELL") {
  const a = atr(c);
  if (!a || c.length < 8) return { score: 0, text: "Belum ada displacement yang dapat divalidasi." };
  const recent = c.slice(-5);
  const x = last(recent)!;
  const directional = side === "BUY" ? x.close > x.open : x.close < x.open;
  const impulse = Math.abs(x.close - x.open) >= a * 0.65 && bodyRatio(x) >= 0.60;
  const follow = recent.slice(0, -1).some(y => side === "BUY" ? y.close > y.open : y.close < y.open);
  if (directional && impulse && follow) return { score: 20, text: `Displacement ${side} terkonfirmasi dengan body kuat relatif terhadap ATR.` };
  if (directional && bodyRatio(x) >= 0.55) return { score: 8, text: `Momentum ${side} terlihat, tetapi displacement belum kuat.` };
  return { score: 0, text: "Tidak ada displacement directional yang cukup kuat." };
}

function sweep(c: Candle[], side: "BUY" | "SELL") {
  const a = atr(c);
  if (!a || c.length < 25) return { score: 0, text: "Liquidity sweep belum dapat divalidasi." };
  const x = last(c)!;
  const prev = c.slice(-21, -1);
  const hi = Math.max(...prev.map(y => y.high));
  const lo = Math.min(...prev.map(y => y.low));
  if (side === "BUY") {
    const swept = x.low < lo - a * 0.05 && x.close > lo;
    return swept ? { score: 18, text: "Sell-side liquidity disapu lalu harga direclaim ke atas level." } : { score: 0, text: "Belum ada sell-side liquidity sweep yang valid." };
  }
  const swept = x.high > hi + a * 0.05 && x.close < hi;
  return swept ? { score: 18, text: "Buy-side liquidity disapu lalu harga direclaim ke bawah level." } : { score: 0, text: "Belum ada buy-side liquidity sweep yang valid." };
}

function location(c: Candle[], side: "BUY" | "SELL") {
  const x = last(c)!;
  const recent = c.slice(-40);
  const hi = Math.max(...recent.map(y => y.high));
  const lo = Math.min(...recent.map(y => y.low));
  const width = hi - lo;
  if (!width) return { score: 0, text: "Lokasi harga tidak dapat dinilai." };
  const pos = (x.close - lo) / width;
  if (side === "BUY" && pos <= 0.45) return { score: 12, text: "Harga berada relatif dekat discount/range-low area." };
  if (side === "SELL" && pos >= 0.55) return { score: 12, text: "Harga berada relatif dekat premium/range-high area." };
  return { score: -8, text: "Lokasi entry kurang ideal; harga berada di area tengah/risk-reward kurang efisien." };
}

function mtfBias(candles: Record<string, Candle[]>, side: "BUY" | "SELL") {
  const tfs = ["H4", "H1", "M15", "M5"];
  let score = 0, agree = 0;
  const texts: string[] = [];
  for (const tf of tfs) {
    const c = candles[tf] || [];
    if (c.length < 50) continue;
    const e20 = ema(c, 20), e50 = ema(c, 50), s = slope(c);
    const bull = e20 > e50 && s > 0.15;
    const bear = e20 < e50 && s < -0.15;
    if ((side === "BUY" && bull) || (side === "SELL" && bear)) { score += tf === "H4" || tf === "H1" ? 8 : 5; agree++; }
    else if ((side === "BUY" && bear) || (side === "SELL" && bull)) { score -= tf === "H4" || tf === "H1" ? 8 : 5; }
  }
  texts.push(`${agree}/${tfs.filter(tf => (candles[tf] || []).length >= 50).length || 0} timeframe mendukung ${side}.`);
  return { score, agree, text: texts[0] };
}

function newsConflict(news: any[], side: "BUY" | "SELL") {
  if (!Array.isArray(news) || !news.length) return { score: 0, text: "Tidak ada data news USD yang cukup untuk menjadi filter." };
  const now = Date.now();
  const recent = news.filter(n => {
    const t = new Date(n?.date || n?.time || n?.timestamp || 0).getTime();
    return Number.isFinite(t) && Math.abs(t - now) < 6 * 60 * 60 * 1000;
  });
  const high = recent.filter(n => String(n?.impact || "").toLowerCase().includes("high"));
  if (high.length) return { score: -12, text: `Ada ${high.length} high-impact USD event di sekitar waktu sekarang; risiko event meningkat.` };
  return { score: 0, text: "Tidak ada high-impact USD event yang terdeteksi dekat observasi." };
}

function fingerprint(features: Record<string, number | string>) {
  return [features.regime, features.structure, features.momentum, features.location, features.mtf, features.sweep, features.fundamental].join("|");
}

function featureVector(candidate: Candidate): Record<string, number> {
  const f = candidate.features;
  return {
    bias: 1,
    structure: Number(f.structure) / 22,
    momentum: Number(f.momentum) / 20,
    sweep: Number(f.sweep) / 18,
    location: Number(f.location) / 12,
    mtf: Number(f.mtf) / 26,
    news: Number(f.news) / 12,
    fundamental: Number(f.fundamental || 0) / 18,
    agreement: Number(f.agreement) / 4,
    regimeUp: f.regime === "TREND_UP" ? 1 : 0,
    regimeDown: f.regime === "TREND_DOWN" ? 1 : 0,
    consolidation: f.regime === "CONSOLIDATION" ? 1 : 0,
    expansion: f.regime === "EXPANSION" ? 1 : 0
  };
}

function normalizeLearning(model: LearningModel): LearningModel {
  const out = { ...DEFAULT_LEARNING, ...model, weights: { ...(model?.weights || {}) }, featureStats: { ...(model?.featureStats || {}) } };
  for (const [k, v] of Object.entries(out.weights)) out.weights[k] = clamp(Number(v), -3, 3);
  return out;
}

function learnedProbability(model: LearningModel, candidate: Candidate): number {
  const x = featureVector(candidate);
  let z = 0;
  for (const [k, v] of Object.entries(x)) z += (model.weights[k] ?? 0) * v;
  return sigmoid(z);
}

function updateLearning(model: LearningModel, candidate: Candidate, target: number): LearningModel {
  const next = normalizeLearning(model);
  const x = featureVector(candidate);
  const p = learnedProbability(next, candidate);
  const lr = 0.045 / Math.sqrt(1 + next.samples / 40);
  const error = target - p;
  for (const [k, v] of Object.entries(x)) {
    next.weights[k] = clamp((next.weights[k] ?? 0) + lr * error * v, -3, 3);
    const old = next.featureStats[k] || { mean: 0, variance: 0, n: 0 };
    const n = old.n + 1;
    const delta = v - old.mean;
    const mean2 = old.mean + delta / n;
    const variance2 = old.variance + delta * (v - mean2);
    next.featureStats[k] = { mean: mean2, variance: variance2, n };
  }
  next.samples += 1;
  if (target >= 0.5) next.wins += 1; else next.losses += 1;
  next.lastUpdate = Date.now();
  return next;
}

export class ZrillReasoningEngine {
  private cycle = 0;
  private running = false;
  private state: ReasoningState = {
    status: "READY", symbol: "XAUUSD", decision: "NO_VALID_SETUP", confidence: 0,
    reasoning: "Belum ada observasi pasar.", why: [], whyNotOpposite: [], invalidation: [],
    emotionalState: "TENANG", internalDialogue: "Saya sedang menunggu feed pasar yang valid.",
    nextObservation: "Tunggu candle berikutnya dan perubahan struktur.", timestamp: Date.now(), cycle: 0
  };

  constructor() {
    this.state = safeRead(statePath, this.state);
    this.cycle = Number(this.state.cycle || 0);
  }

  getState() { return this.state; }

  getLearningModel() {
    return normalizeLearning(safeRead<LearningModel>(learningPath, DEFAULT_LEARNING));
  }

  private learnedAdjustment(candidate: Candidate) {
    const model = this.getLearningModel();
    if (model.samples < 8) return { adjustment: 0, probability: 0.5, samples: model.samples };
    const p = learnedProbability(model, candidate);
    return { adjustment: (p - 0.5) * 18, probability: p, samples: model.samples };
  }

  private buildCandidate(candles: Record<string, Candle[]>, news: any[], side: "BUY" | "SELL", fundamental?: FundamentalContext): Candidate {
    const m5 = candles.M5 || candles["5"] || [];
    const r = regime(m5);
    const st = structure(m5, side);
    const dp = displacement(m5, side);
    const sw = sweep(m5, side);
    const loc = location(m5, side);
    const mtf = mtfBias(candles, side);
    const nf = newsConflict(news, side);
    const ff = fundamentalReasoning({ ...(fundamental || {}), news }, side);
    let score = 0;
    const evidence: string[] = [];
    const risks: string[] = [];
    for (const item of [st, dp, sw, loc]) { score += item.score; if (item.score > 0) evidence.push(item.text); else risks.push(item.text); }
    score += mtf.score + nf.score + ff.score;
    if (mtf.score > 0) evidence.push(mtf.text); else if (mtf.score < 0) risks.push(mtf.text);
    if (nf.score < 0) risks.push(nf.text);
    if (ff.score > 0) evidence.push(ff.text, ...ff.evidence.slice(0, 2));
    if (ff.score < 0) risks.push(ff.text);
    if (r === "CONSOLIDATION") { score -= 25; risks.push("Pasar terdeteksi konsolidasi; edge directional turun."); }
    if (r === "EXPANSION") score += 5;
    if (r === (side === "BUY" ? "TREND_UP" : "TREND_DOWN")) score += 8;
    if (r === (side === "BUY" ? "TREND_DOWN" : "TREND_UP")) { score -= 12; risks.push("Regime utama berlawanan dengan kandidat."); }
    const f: Record<string, number | string> = {
      regime: r, structure: st.score, momentum: dp.score, location: loc.score, mtf: mtf.score,
      sweep: sw.score, news: nf.score, fundamental: ff.score, agreement: mtf.agree
    };
    return { side, score, evidence, risks, features: f };
  }

  private memoryAdjustment(symbol: string, fp: string, side: "BUY" | "SELL") {
    const memory = safeRead<MemoryItem[]>(memoryPath, []);
    const same = memory.filter(x => x.symbol === symbol && x.fingerprint === fp && x.outcome && x.outcome !== "UNKNOWN").slice(-80);
    if (!same.length) return 0;
    const wins = same.filter(x => x.outcome === "TP").length;
    const losses = same.filter(x => x.outcome === "SL" || x.outcome === "REVERSAL").length;
    const n = wins + losses;
    if (!n) return 0;
    const rate = wins / n;
    // Memory can refine the decision, but can never create a setup by itself.
    return (rate - 0.5) * Math.min(12, n * 1.5) * (side === same.at(-1)!.decision ? 1 : -1);
  }

  async think(context: any): Promise<ReasoningState> {
    this.cycle += 1;
    const symbol = String(context?.symbol || "XAUUSD").toUpperCase();
    this.state = { ...this.state, status: "THINKING", symbol, timestamp: Date.now(), cycle: this.cycle };

    const feedValid = context?.feedValid !== false;
    if (!feedValid) {
      this.state = {
        ...this.state, status: "FEED_RECOVERY", decision: "FEED_RECOVERY", confidence: 0,
        reasoning: "Saya tidak mengambil keputusan karena feed TradingView tidak valid atau terlalu lama.",
        why: ["Data observasi tidak memenuhi syarat freshness."], whyNotOpposite: [],
        invalidation: ["TRADINGVIEW_FEED_INVALID_OR_STALE"], emotionalState: "WASPADA",
        internalDialogue: "Data saya tidak cukup bersih. Saya memilih tidak mengarang keputusan.",
        nextObservation: "Tunggu feed live kembali valid.", timestamp: Date.now(), cycle: this.cycle
      };
      safeWrite(statePath, this.state);
      return this.state;
    }

    const candles: Record<string, Candle[]> = {};
    for (const [tf, raw] of Object.entries(context?.candles || {})) candles[tf] = parseCandles(raw).slice(-120);
    const m5 = candles.M5 || candles["5"] || [];
    if (m5.length < 60) {
      this.state = { ...this.state, status: "FEED_RECOVERY", decision: "FEED_RECOVERY", confidence: 0,
        reasoning: "Saya belum memiliki cukup candle M5 untuk berpikir secara struktural.", why: [], whyNotOpposite: [],
        invalidation: ["INSUFFICIENT_M5_HISTORY"], emotionalState: "WASPADA",
        internalDialogue: "Saya tidak akan mengisi kekosongan data dengan asumsi.", nextObservation: "Tunggu histori candle M5 bertambah.", timestamp: Date.now(), cycle: this.cycle };
      safeWrite(statePath, this.state);
      return this.state;
    }

    const fundamental: FundamentalContext = { events: context?.economicEvents || context?.news || [], news: context?.news || [], dxy: context?.crossAsset?.DXY || null, us10y: context?.crossAsset?.US10Y || null };
    const buy = this.buildCandidate(candles, context?.news || [], "BUY", fundamental);
    const sell = this.buildCandidate(candles, context?.news || [], "SELL", fundamental);
    const buyFp = fingerprint(buy.features), sellFp = fingerprint(sell.features);
    buy.score += this.memoryAdjustment(symbol, buyFp, "BUY");
    sell.score += this.memoryAdjustment(symbol, sellFp, "SELL");

    // Online native learning: past realized outcomes can refine evidence weights.
    // It is deliberately bounded and cannot create a setup without structural evidence.
    const buyLearn = this.learnedAdjustment(buy);
    const sellLearn = this.learnedAdjustment(sell);
    buy.score += buyLearn.adjustment;
    sell.score += sellLearn.adjustment;

    const gap = Math.abs(buy.score - sell.score);
    const top = buy.score >= sell.score ? buy : sell;
    const opposite = top.side === "BUY" ? sell : buy;
    const currentRegime = String(top.features.regime);
    const consolidation = currentRegime === "CONSOLIDATION";

    let decision: ReasoningState["decision"] = "NO_VALID_SETUP";
    const hardMinimum = 58;
    const separation = 14;
    if (!consolidation && top.score >= hardMinimum && top.score - opposite.score >= separation && Number(top.features.sweep) > 0 && Number(top.features.momentum) > 0) decision = top.side;

    const confidence = decision === "NO_VALID_SETUP" ? clamp(38 + Math.max(0, top.score) * 0.35 - Math.max(0, 16 - gap) * 1.5) : clamp(58 + (top.score - hardMinimum) * 0.65 + Math.min(gap, 30) * 0.35);
    const reasons = decision === top.side ? top.evidence : [
      `BUY score ${buy.score.toFixed(1)} vs SELL score ${sell.score.toFixed(1)}.`,
      consolidation ? "Regime konsolidasi menurunkan edge directional." : "Belum ada kombinasi bukti yang cukup dominan.",
      Number(top.features.sweep) <= 0 ? "Liquidity sweep belum terkonfirmasi." : "Displacement/struktur belum cukup kuat secara bersamaan."
    ];
    const whyNotOpposite = decision === "NO_VALID_SETUP" ? [
      `Kandidat BUY: ${buy.score.toFixed(1)}; kandidat SELL: ${sell.score.toFixed(1)}.`,
      `Selisih evidence hanya ${gap.toFixed(1)} poin.`,
      "Saya tidak memaksakan arah ketika kedua hipotesis masih memiliki kelemahan."
    ] : [
      `Kandidat ${opposite.side} hanya memperoleh ${opposite.score.toFixed(1)} dibanding ${top.score.toFixed(1)}.`,
      ...opposite.risks.slice(0, 2)
    ];
    const invalidation = [
      `Perubahan struktur berlawanan pada M5/H1 dapat membatalkan ${top.side}.`,
      "Liquidity sweep yang gagal direclaim dan displacement yang tidak follow-through menurunkan validitas setup.",
      "Feed TradingView stale/terputus membatalkan observasi saat ini.",
      "Fundamental hanya menjadi penguat/pengurang edge; tidak boleh menggantikan trigger teknikal."
    ];
    if (consolidation) invalidation.unshift("Breakout harus benar-benar close-confirmed; wick breakout saja tidak cukup.");

    const learningNote = this.getLearningModel().samples >= 8
      ? `Native learning: ${this.getLearningModel().samples} outcome samples; BUY ${(buyLearn.probability * 100).toFixed(0)}%, SELL ${(sellLearn.probability * 100).toFixed(0)}% learned fit.`
      : "Native learning belum aktif penuh; menunggu outcome nyata agar tidak belajar dari asumsi.";

    const emotionalState = decision === "NO_VALID_SETUP"
      ? (gap < 10 ? "KONFLIK" : "WASPADA")
      : confidence >= 82 ? "CONFIDENT_NOT_CERTAIN" : "ALERT";
    const internalDialogue = decision === "BUY"
      ? `Saya melihat hipotesis BUY paling kuat: ${top.evidence[0] || "konfluensi struktur meningkat"}. Saya tetap mencari bukti yang membatalkannya.`
      : decision === "SELL"
        ? `Saya melihat hipotesis SELL paling kuat: ${top.evidence[0] || "konfluensi struktur meningkat"}. Saya tetap mencari bukti yang membatalkannya.`
        : `Saya belum memilih arah. Saya membandingkan BUY ${buy.score.toFixed(0)} dengan SELL ${sell.score.toFixed(0)} dan menunggu bukti yang lebih jelas.`;
    const nextObservation = decision === "NO_VALID_SETUP"
      ? "Pantau close candle berikutnya, liquidity sweep, displacement, dan perubahan regime."
      : `Pantau apakah struktur ${decision} bertahan dan apakah lawan menghasilkan sweep + displacement + MSS yang terkonfirmasi.`;

    this.state = {
      status: "READY", symbol, decision, confidence,
      reasoning: decision === "NO_VALID_SETUP"
        ? `Keputusan tidak dipaksakan karena evidence belum cukup dominan atau pasar sedang konsolidasi. ${learningNote}`
        : `${decision} dipilih setelah tiga tahap: observasi teknikal, uji fundamental/cross-asset, lalu adversarial check terhadap hipotesis lawan. Evidence yang tersedia lebih koheren daripada hipotesis lawan. ${learningNote}`,
      why: reasons.slice(0, 8), whyNotOpposite: whyNotOpposite.slice(0, 8), invalidation: invalidation.slice(0, 8),
      emotionalState, internalDialogue, nextObservation, timestamp: Date.now(), cycle: this.cycle
    };

    const memory = safeRead<MemoryItem[]>(memoryPath, []);
    const chosenCandidate = decision === "BUY" ? buy : decision === "SELL" ? sell : top;
    memory.push({ timestamp: Date.now(), symbol, fingerprint: decision === "BUY" ? buyFp : decision === "SELL" ? sellFp : fingerprint(top.features), regime: currentRegime,
      decision, features: { side: chosenCandidate.side, buyScore: buy.score, sellScore: sell.score, gap, ...top.features, ...featureVector(chosenCandidate) } });
    safeWrite(memoryPath, memory.slice(-1000));
    safeWrite(statePath, this.state);
    return this.state;
  }

  recordLatestOutcome(symbol: string, outcome: "TP" | "SL" | "REVERSAL" | "NO_TRADE") {
    const memory = safeRead<MemoryItem[]>(memoryPath, []);
    for (let i = memory.length - 1; i >= 0; i--) {
      const item = memory[i];
      if (item.symbol !== symbol || item.outcome) continue;
      if (item.decision !== "BUY" && item.decision !== "SELL") continue;
      this.recordOutcome(symbol, item.fingerprint, outcome);
      return true;
    }
    return false;
  }

  /** Feed a realized outcome back into native memory. No model training or external AI is required. */
  recordOutcome(symbol: string, fingerprintValue: string, outcome: MemoryItem["outcome"]) {
    const memory = safeRead<MemoryItem[]>(memoryPath, []);
    let target: MemoryItem | undefined;
    for (let i = memory.length - 1; i >= 0; i--) {
      if (memory[i].symbol === symbol && memory[i].fingerprint === fingerprintValue && !memory[i].outcome) {
        target = memory[i];
        memory[i].outcome = outcome;
        break;
      }
    }
    safeWrite(memoryPath, memory.slice(-1000));

    // This is actual local training from realized market outcomes, not replay.
    if (!target || !target.features) return;
    if (outcome !== "TP" && outcome !== "SL" && outcome !== "REVERSAL") return;
    const side = target.decision === "BUY" || target.decision === "SELL" ? target.decision : String(target.features.side || "") as any;
    if (side !== "BUY" && side !== "SELL") return;
    const candidate: Candidate = {
      side,
      score: Number(target.features.buyScore || target.features.sellScore || 0),
      evidence: [], risks: [],
      features: {
        regime: target.features.regime || "UNKNOWN",
        structure: Number(target.features.structure || 0),
        momentum: Number(target.features.momentum || 0),
        location: Number(target.features.location || 0),
        mtf: Number(target.features.mtf || 0),
        sweep: Number(target.features.sweep || 0),
        news: Number(target.features.news || 0),
        agreement: Number(target.features.agreement || 0),
        fundamental: Number(target.features.fundamental || 0)
      }
    };
    const model = this.getLearningModel();
    const trained = updateLearning(model, candidate, outcome === "TP" ? 1 : 0);
    safeWrite(learningPath, trained);
  }

  /** Train directly from a completed setup. Kept explicit so no hidden/fake labels are created. */
  trainFromOutcome(symbol: string, fingerprintValue: string, outcome: "TP" | "SL" | "REVERSAL" | "NO_TRADE") {
    this.recordOutcome(symbol, fingerprintValue, outcome);
  }

  start(getContext: () => Promise<any>, intervalMs = 30000) {
    if (this.running) return;
    this.running = true;
    const loop = async () => {
      while (this.running) {
        try {
          const context = await getContext();
          await this.think(context);
        } catch (err) {
          console.warn("[ZrillNativeReasoning] autonomous cycle:", err instanceof Error ? err.message : err);
        }
        await new Promise(r => setTimeout(r, intervalMs));
      }
    };
    void loop();
  }

  stop() { this.running = false; }
}
