import React from "react";
import { motion } from "motion/react";
import { AmdPhaseAnalysis } from "../services/precisionSignalEngine";
import {
  ShieldCheck,
  Activity,
  Target,
  Zap,
  Layers,
  TrendingUp,
  TrendingDown,
  Lock,
  ArrowRightLeft,
  Sparkles,
  BarChart3,
  Gauge,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from "recharts";

interface AmdPhaseAnalysisCardProps {
  amdAnalysis?: AmdPhaseAnalysis;
  symbol?: string;
  isBuy: boolean;
  currentPrice: number;
}

export const AmdPhaseAnalysisCard: React.FC<AmdPhaseAnalysisCardProps> = ({
  amdAnalysis,
  symbol = "XAUUSD",
  isBuy,
  currentPrice,
}) => {
  if (!amdAnalysis) return null;

  const safeSymbol = typeof symbol === "string" ? symbol : "XAUUSD";

  const {
    currentPhase,
    phaseBadge,
    accuracyBonusPercent,
    summaryExplanation,
    accumulationZone,
    manipulationZone,
    distributionZone,
    executionStrategy,
    institutionalTacticalAdvice,
  } = amdAnalysis;

  const isAccumulation = currentPhase === "AKUMULASI";
  const isManipulation = currentPhase === "MANIPULASI";
  const isDistribution = currentPhase === "DISTRIBUSI";

  // Timeline dataset representing the PO3 progression curve
  const timelineData = React.useMemo(() => {
    const base = currentPrice || 100;
    const isBtc = safeSymbol.includes("BTC");
    const delta = isBtc ? 250 : 3.5;

    return [
      {
        step: "T1",
        label: "Asian Range",
        phase: "AKUMULASI",
        price: Number(base.toFixed(2)),
        momentum: 40,
        accum: 80,
        manip: 0,
        dist: 0,
        isCurrent: isAccumulation,
      },
      {
        step: "T2",
        label: "Ranging High",
        phase: "AKUMULASI",
        price: Number((base + delta * 0.2).toFixed(2)),
        momentum: 45,
        accum: 85,
        manip: 0,
        dist: 0,
        isCurrent: isAccumulation,
      },
      {
        step: "T3",
        label: "Ranging Low",
        phase: "AKUMULASI",
        price: Number((base - delta * 0.2).toFixed(2)),
        momentum: 42,
        accum: 75,
        manip: 0,
        dist: 0,
        isCurrent: isAccumulation,
      },
      {
        step: "T4",
        label: "Liquidity Built",
        phase: "AKUMULASI",
        price: Number(base.toFixed(2)),
        momentum: 50,
        accum: 90,
        manip: 0,
        dist: 0,
        isCurrent: isAccumulation,
      },
      {
        step: "T5",
        label: "Judas Start",
        phase: "MANIPULASI",
        price: Number((isBuy ? base - delta * 0.5 : base + delta * 0.5).toFixed(2)),
        momentum: 80,
        accum: 0,
        manip: 90,
        dist: 0,
        isCurrent: isManipulation,
      },
      {
        step: "T6",
        label: "Liquidity Sweep",
        phase: "MANIPULASI",
        price: manipulationZone.sweepPrice,
        momentum: 100,
        accum: 0,
        manip: 100,
        dist: 0,
        isCurrent: isManipulation,
      },
      {
        step: "T7",
        label: "Smart Money Trap",
        phase: "MANIPULASI",
        price: Number((isBuy ? base - delta * 0.1 : base + delta * 0.1).toFixed(2)),
        momentum: 88,
        accum: 0,
        manip: 85,
        dist: 0,
        isCurrent: isManipulation,
      },
      {
        step: "T8",
        label: "BOS Expansion",
        phase: "DISTRIBUSI",
        price: Number((isBuy ? base + delta * 0.6 : base - delta * 0.6).toFixed(2)),
        momentum: 90,
        accum: 0,
        manip: 0,
        dist: 85,
        isCurrent: isDistribution,
      },
      {
        step: "T9",
        label: "True Move Run",
        phase: "DISTRIBUSI",
        price: Number((isBuy ? base + delta * 1.3 : base - delta * 1.3).toFixed(2)),
        momentum: 98,
        accum: 0,
        manip: 0,
        dist: 95,
        isCurrent: isDistribution,
      },
      {
        step: "T10",
        label: "TP1 Hit",
        phase: "DISTRIBUSI",
        price: Number((isBuy ? base + delta * 1.9 : base - delta * 1.9).toFixed(2)),
        momentum: 94,
        accum: 0,
        manip: 0,
        dist: 98,
        isCurrent: isDistribution,
      },
      {
        step: "T11",
        label: "TP2 Lock SL",
        phase: "DISTRIBUSI",
        price: Number((isBuy ? base + delta * 2.4 : base - delta * 2.4).toFixed(2)),
        momentum: 92,
        accum: 0,
        manip: 0,
        dist: 90,
        isCurrent: isDistribution,
      },
      {
        step: "T12",
        label: "Max Distribution Target",
        phase: "DISTRIBUSI",
        price: distributionZone.targetExpansionPrice,
        momentum: 85,
        accum: 0,
        manip: 0,
        dist: 85,
        isCurrent: isDistribution,
      },
    ];
  }, [currentPrice, isBuy, isAccumulation, isManipulation, isDistribution, manipulationZone, distributionZone, symbol]);

  return (
    <motion.div
      id={`amd_phase_card_${symbol}`}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="bg-slate-900/90 border border-slate-700/80 rounded-xl p-4 md:p-5 shadow-2xl text-white space-y-4 relative overflow-hidden backdrop-blur-md"
    >
      {/* Background Glow */}
      <div
        className={`absolute -top-16 -right-16 w-56 h-56 rounded-full blur-3xl pointer-events-none opacity-25 transition-all ${
          isManipulation
            ? "bg-rose-500"
            : isDistribution
            ? "bg-emerald-500"
            : "bg-amber-500"
        }`}
      />

      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500/20 to-purple-500/20 border border-indigo-500/30 text-indigo-400 shadow-md">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm md:text-base font-bold tracking-wide text-gray-100 uppercase">
                Fase Sinyal AMD (Power of 3 - PO3)
              </h3>
              <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-500/30 font-semibold shadow-sm">
                AKURASI +{accuracyBonusPercent}%
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Analisis Siklus Akumulasi, Manipulasi & Distribusi Institusional
            </p>
          </div>
        </div>

        {/* Current Phase Active Badge */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-bold text-xs uppercase tracking-wider shadow-lg ${
              isManipulation
                ? "bg-rose-500/10 border-rose-500/40 text-rose-300 animate-pulse"
                : isDistribution
                ? "bg-emerald-500/10 border-emerald-500/40 text-emerald-300"
                : "bg-amber-500/10 border-amber-500/40 text-amber-300"
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                isManipulation
                  ? "bg-rose-400 animate-ping"
                  : isDistribution
                  ? "bg-emerald-400 animate-pulse"
                  : "bg-amber-400 animate-pulse"
              }`}
            />
            <span>{phaseBadge}</span>
          </div>
        </div>
      </div>

      {/* Summary Explanation */}
      <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 text-xs text-slate-200 leading-relaxed flex items-start gap-2.5">
        <Activity className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-semibold text-indigo-300">Diagnosa Siklus SMC: </span>
          {summaryExplanation}
        </div>
      </div>

      {/* GRAPHICAL PHASE PROGRESS TIMELINE (RECHARTS AREA CHART) */}
      <div className="p-3.5 bg-slate-950/70 rounded-xl border border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs pb-1">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <span className="font-bold text-gray-200 uppercase tracking-wide">
              Grafik Timeline Transisi Fase AMD (PO3 Progress)
            </span>
          </div>
          <div className="flex items-center gap-3 text-[10px] font-mono">
            <span className="flex items-center gap-1 text-amber-400">
              <span className="w-2 h-2 rounded-full bg-amber-400" /> Akumulasi
            </span>
            <span className="flex items-center gap-1 text-rose-400">
              <span className="w-2 h-2 rounded-full bg-rose-400" /> Manipulasi
            </span>
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" /> Distribusi
            </span>
          </div>
        </div>

        <div className="h-40 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="accumGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="manipGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="distGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>

              <XAxis dataKey="step" tick={{ fill: "#94a3b8", fontSize: 10 }} stroke="#334155" />
              <YAxis domain={["auto", "auto"]} tick={{ fill: "#94a3b8", fontSize: 9 }} stroke="#334155" />

              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 border border-slate-700 p-2.5 rounded-lg shadow-xl text-xs space-y-1 font-mono">
                        <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-1">
                          <span className="font-bold text-indigo-300">{data.label}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${
                              data.phase === "AKUMULASI"
                                ? "bg-amber-500/20 text-amber-300"
                                : data.phase === "MANIPULASI"
                                ? "bg-rose-500/20 text-rose-300"
                                : "bg-emerald-500/20 text-emerald-300"
                            }`}
                          >
                            {data.phase}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-300 gap-4">
                          <span>Harga Proyeksi:</span>
                          <span className="font-bold text-white">${data.price}</span>
                        </div>
                        <div className="flex justify-between text-slate-400 text-[10px]">
                          <span>Intensitas Momentum:</span>
                          <span>{data.momentum}%</span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />

              <Area type="monotone" dataKey="accum" stroke="#f59e0b" fillOpacity={1} fill="url(#accumGradient)" strokeWidth={2} />
              <Area type="monotone" dataKey="manip" stroke="#f43f5e" fillOpacity={1} fill="url(#manipGradient)" strokeWidth={2.5} />
              <Area type="monotone" dataKey="dist" stroke="#10b981" fillOpacity={1} fill="url(#distGradient)" strokeWidth={2.5} />

              {/* Reference indicator for current phase */}
              <ReferenceLine x={isAccumulation ? "T3" : isManipulation ? "T6" : "T9"} stroke="#6366f1" strokeDasharray="3 3" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* NEW SECTION: AMD EXECUTION STRATEGY & DYNAMIC TP/SL ADJUSTMENT */}
      {executionStrategy && (
        <div className="p-3.5 bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 rounded-xl space-y-3 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-indigo-500/20">
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-cyan-400" />
              <h4 className="text-xs md:text-sm font-bold text-indigo-200 uppercase tracking-wide">
                Strategi Eksekusi AMD & Penyesuaian TP/SL Dinamis
              </h4>
            </div>

            {executionStrategy.tightStopsPrioritized ? (
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold tracking-wider uppercase animate-pulse shadow-md">
                <Lock className="w-3 h-3 text-emerald-400" />
                 PRIORITAS SL DIPERKETAT (DISTRIBUSI ACTIVE)
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-[10px] font-mono font-semibold">
                RR TERKALIBRASI {executionStrategy.riskRewardRatio}
              </span>
            )}
          </div>

          {/* Strategy Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs font-mono">
            {/* Dynamic SL Box */}
            <div className={`p-2.5 rounded-lg border ${executionStrategy.tightStopsPrioritized ? "bg-emerald-950/40 border-emerald-500/50" : "bg-slate-800/60 border-slate-700/60"}`}>
              <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between mb-1">
                <span>Stop Loss Dinamis (SL)</span>
                <span className="text-rose-400 font-bold">{executionStrategy.stopType}</span>
              </div>
              <div className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                <TrendingDown className="w-4 h-4 text-rose-400" />
                ${executionStrategy.adjustedSlPrice}
              </div>
              <p className="text-[10px] text-slate-300 mt-1.5 leading-snug font-sans">
                {executionStrategy.slAdjustmentReason}
              </p>
            </div>

            {/* Dynamic TP Box */}
            <div className="p-2.5 rounded-lg border bg-slate-800/60 border-slate-700/60">
              <div className="text-[10px] text-slate-400 uppercase flex items-center justify-between mb-1">
                <span>Take Profit Dinamis (TP)</span>
                <span className="text-emerald-400 font-bold">{executionStrategy.tpType}</span>
              </div>
              <div className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                ${executionStrategy.adjustedTpPrice}
              </div>
              <p className="text-[10px] text-slate-300 mt-1.5 leading-snug font-sans">
                {executionStrategy.tpAdjustmentReason}
              </p>
            </div>

            {/* Risk Reward & Strategy Name */}
            <div className="p-2.5 rounded-lg border bg-slate-800/60 border-slate-700/60 flex flex-col justify-between">
              <div>
                <div className="text-[10px] text-slate-400 uppercase mb-1">Nama Taktis Eksekusi</div>
                <div className="text-xs font-bold text-indigo-300 uppercase leading-snug">
                  {executionStrategy.strategyName}
                </div>
              </div>
              <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Rasio R:R:</span>
                <span className="font-bold text-amber-300">{executionStrategy.riskRewardRatio}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3-Phase Stepper Pipeline (AKUMULASI -> MANIPULASI -> DISTRIBUSI) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
        {/* FASE 1: AKUMULASI */}
        <div
          id={`amd_step_accum_${symbol}`}
          className={`p-3.5 rounded-lg border transition-all ${
            isAccumulation
              ? "bg-amber-500/10 border-amber-500/50 ring-1 ring-amber-500/30"
              : "bg-slate-800/40 border-slate-800 opacity-80"
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-[10px]">
                1
              </span>
              <span>AKUMULASI</span>
            </div>
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold ${
                isAccumulation
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                  : "bg-slate-700/50 text-slate-400"
              }`}
            >
              {accumulationZone.statusLabel}
            </span>
          </div>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Rentang Ranging:</span>
              <span className="font-mono text-slate-200">
                ${accumulationZone.rangeMin} - ${accumulationZone.rangeMax}
              </span>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Lebar Konsolidasi:</span>
              <span className="font-mono text-amber-300">
                ~{accumulationZone.rangePips} Pips
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-2 leading-tight">
              {accumulationZone.description}
            </p>
          </div>
        </div>

        {/* FASE 2: MANIPULASI (JUDAS SWEEP) */}
        <div
          id={`amd_step_manip_${symbol}`}
          className={`p-3.5 rounded-lg border transition-all ${
            isManipulation
              ? "bg-rose-500/10 border-rose-500/50 ring-1 ring-rose-500/30"
              : "bg-slate-800/40 border-slate-800 opacity-80"
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400">
              <span className="w-5 h-5 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-[10px]">
                2
              </span>
              <span>MANIPULASI (JUDAS)</span>
            </div>
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold ${
                isManipulation
                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                  : "bg-slate-700/50 text-slate-400"
              }`}
            >
              {manipulationZone.statusLabel}
            </span>
          </div>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Harga Sweep Likuiditas:</span>
              <span className="font-mono text-rose-300 font-bold">
                ${manipulationZone.sweepPrice}
              </span>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Tipe Trap:</span>
              <span className="font-mono text-xs text-rose-400">
                {manipulationZone.sweepDirection === "SSL_SWEEP_SELL_TRAP"
                  ? "SSL Sweep (Sell Stop Hunt)"
                  : "BSL Sweep (Buy Stop Hunt)"}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-2 leading-tight">
              {manipulationZone.description}
            </p>
          </div>
        </div>

        {/* FASE 3: DISTRIBUSI */}
        <div
          id={`amd_step_dist_${symbol}`}
          className={`p-3.5 rounded-lg border transition-all ${
            isDistribution
              ? "bg-emerald-500/10 border-emerald-500/50 ring-1 ring-emerald-500/30"
              : "bg-slate-800/40 border-slate-800 opacity-80"
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-[10px]">
                3
              </span>
              <span>DISTRIBUSI (TRUE MOVE)</span>
            </div>
            <span
              className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold ${
                isDistribution
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                  : "bg-slate-700/50 text-slate-400"
              }`}
            >
              {distributionZone.statusLabel}
            </span>
          </div>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Target Ekspansi TP:</span>
              <span className="font-mono text-emerald-300 font-bold">
                ${distributionZone.targetExpansionPrice}
              </span>
            </div>
            <div className="flex justify-between text-slate-400 text-[11px]">
              <span>Jarak Ekspansi:</span>
              <span className="font-mono text-emerald-400">
                +{distributionZone.expansionPips} Pips
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-2 leading-tight">
              {distributionZone.description}
            </p>
          </div>
        </div>
      </div>

      {/* Institutional Tactical Recommendation */}
      <div className="p-3 bg-gradient-to-r from-slate-800/90 to-indigo-950/50 rounded-lg border border-indigo-500/30 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <Zap className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-slate-200 font-medium">
            {institutionalTacticalAdvice}
          </span>
        </div>
        <div className="shrink-0 font-mono text-[11px] text-indigo-300 bg-indigo-500/10 px-2 py-1 rounded border border-indigo-500/30">
          AMD Confluence 98%
        </div>
      </div>
    </motion.div>
  );
};
