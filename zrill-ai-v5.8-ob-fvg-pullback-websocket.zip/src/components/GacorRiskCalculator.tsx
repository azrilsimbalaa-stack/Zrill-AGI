import React, { useState, useMemo } from "react";
import {
  Shield,
  Calculator,
  DollarSign,
  TrendingUp,
  Percent,
  CheckCircle2,
  Copy,
  Check,
  Zap,
  Sliders,
  Sparkles,
  Flame,
  ArrowRight,
  Info,
  Scale,
  RefreshCw,
  Coins
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export type SupportedCurrency = "USD" | "USC" | "IDR";
export type GacorPresetMode = "ULTRA_SNIPER" | "GOLDEN_ASYMMETRIC" | "MEGA_RUNNER" | "CUSTOM";

export interface RiskCalculatorConfig {
  isEnabled: boolean;
  currency: SupportedCurrency;
  balance: number;
  riskPercent: number;
  mode: GacorPresetMode;
  customSlDistance?: number; // in points
  customTp1Multiplier?: number;
  customTp2Multiplier?: number;
  customTp3Multiplier?: number;
}

export interface CalculatedGacorRiskResult {
  isEnabled: boolean;
  currency: SupportedCurrency;
  currencySymbol: string;
  balance: number;
  riskPercent: number;
  riskAmountCurrency: number;
  riskAmountUsd: number;
  entryPrice: number;
  direction: string;
  isBuy: boolean;
  originalSl: number;
  originalTp1: number;
  originalTp2: number;
  originalTp3: number;
  adjustedSl: number;
  adjustedTp1: number;
  adjustedTp2: number;
  adjustedTp3: number;
  slDistancePoints: number;
  tp1DistancePoints: number;
  tp2DistancePoints: number;
  tp3DistancePoints: number;
  rrTp1: number;
  rrTp2: number;
  rrTp3: number;
  avgRr: number;
  recommendedLotStandard: number;
  recommendedLotCent: number;
  expectedLossCurrency: number;
  expectedTp1ProfitCurrency: number;
  expectedTp2ProfitCurrency: number;
  expectedTp3ProfitCurrency: number;
  evRatio: number;
  gacorScore: number;
  gacorTierBadge: string;
  gacorAdvice: string;
}

export interface GacorRiskCalculatorProps {
  currentSignal?: any;
  activeSymbol?: { id: string; name: string } | string;
  symbol?: { id: string; name: string } | string;
  currentPrice?: number;
  config: RiskCalculatorConfig;
  onChangeConfig?: (newConfig: RiskCalculatorConfig) => void;
  onUpdateConfig?: (newConfig: RiskCalculatorConfig) => void;
  onApplyToSignal?: (result: CalculatedGacorRiskResult) => void;
  isEmbedded?: boolean;
  visualTheme?: string;
  copyToClipboard?: (text: string) => Promise<boolean>;
}

// Exchange rate constants
const USD_TO_IDR_RATE = 16250;
const USD_TO_USC_RATE = 100;

export function formatCurrencyVal(val: number, currency: SupportedCurrency): string {
  if (currency === "IDR") {
    return `Rp ${Math.round(val).toLocaleString("id-ID")}`;
  } else if (currency === "USC") {
    return `${val.toLocaleString("en-US", { maximumFractionDigits: 1 })} ¢`;
  } else {
    return `$${val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
}

export function calculateGacorRiskMetrics(
  signal: any,
  symbol: { id: string; name: string } | string | undefined,
  config?: RiskCalculatorConfig
): CalculatedGacorRiskResult {
  const safeConfig = config || {
    isEnabled: true,
    currency: "USD",
    balance: 1000,
    riskPercent: 1.0,
    mode: "GOLDEN_ASYMMETRIC",
  };
  const isEnabled = safeConfig.isEnabled ?? true;
  const currency = safeConfig.currency || "USD";
  const balance = Math.max(1, safeConfig.balance || 1000);
  const riskPercent = Math.max(0.1, safeConfig.riskPercent || 1.0);

  // Asset contract specs
  const symId = typeof symbol === "string" ? symbol : (symbol?.id || "XAUUSD");
  const cleanSym = (symId || "").toUpperCase();
  const isGold = cleanSym.includes("XAU") || cleanSym.includes("GOLD");
  const isBtc = cleanSym.includes("BTC");
  const isUs100 = cleanSym.includes("US100") || cleanSym.includes("NAS100") || cleanSym.includes("NASDAQ");
  const isForex = !isGold && !isBtc && !isUs100 && (cleanSym.includes("EUR") || cleanSym.includes("GBP") || cleanSym.includes("USD") || cleanSym.includes("JPY"));

  // Default Entry & Direction
  const isBuy = signal?.type?.toUpperCase().includes("BUY") ?? true;
  const direction = isBuy ? "BUY" : "SELL";
  const entry = signal?.entry && signal.entry > 0 ? signal.entry : (isBtc ? 77500 : isUs100 ? 21500 : 2860);
  
  // Base raw distances from signal
  let baseSlDistance = Math.abs(entry - (signal?.sl || (isBuy ? entry - 4.5 : entry + 4.5)));
  if (baseSlDistance <= 0.001) {
    baseSlDistance = isGold ? 4.5 : isBtc ? 450 : isUs100 ? 35 : 0.0035;
  }

  // Determine preset R:R and SL scaling
  let slScale = 1.0;
  let rr1 = 1.8;
  let rr2 = 3.6;
  let rr3 = 6.0;
  let tierBadge = " GOLDEN ASYMMETRIC (INSTITUSIONAL)";
  let advice = "Rasio seimbang dengan perlindungan OTE 0.618 Fib & buffer noise pasar optimal.";

  if (config.mode === "ULTRA_SNIPER") {
    slScale = 0.85; // Tighter SL at local fractal
    rr1 = 1.6;
    rr2 = 3.2;
    rr3 = 5.0;
    tierBadge = " ULTRA SNIPER GACOR (MINIMAL SL DRAWDOWN)";
    advice = "SL super ketat di balik fractal terdekat. Tingkat asimetri profit maksimal dengan risiko modal sangat kecil.";
  } else if (config.mode === "MEGA_RUNNER") {
    slScale = 1.35; // Wider SL immune to institutional sweeps
    rr1 = 2.2;
    rr2 = 4.8;
    rr3 = 8.5;
    tierBadge = " MEGA RUNNER GACOR (MACRO WAVE RIDER)";
    advice = "SL dengan buffer lebar kebal stop hunt bandar, menargetkan ekspansi tren makro penuh.";
  } else if (config.mode === "CUSTOM") {
    slScale = config.customSlDistance ? config.customSlDistance / baseSlDistance : 1.0;
    rr1 = config.customTp1Multiplier || 1.8;
    rr2 = config.customTp2Multiplier || 3.5;
    rr3 = config.customTp3Multiplier || 6.0;
    tierBadge = " CUSTOM PRESISI (DISESUAIKAN MANUAL)";
    advice = "Parameter disesuaikan secara khusus sesuai toleransi dan strategi pribadi trader.";
  }

  const activeSlDistance = isEnabled ? baseSlDistance * slScale : baseSlDistance;
  const activeTp1Distance = activeSlDistance * rr1;
  const activeTp2Distance = activeSlDistance * rr2;
  const activeTp3Distance = activeSlDistance * rr3;

  // Compute calculated target prices
  const adjustedSl = isBuy ? entry - activeSlDistance : entry + activeSlDistance;
  const adjustedTp1 = isBuy ? entry + activeTp1Distance : entry - activeTp1Distance;
  const adjustedTp2 = isBuy ? entry + activeTp2Distance : entry - activeTp2Distance;
  const adjustedTp3 = isBuy ? entry + activeTp3Distance : entry - activeTp3Distance;

  // Convert Balance to USD for lot calculation
  let balanceInUsd = balance;
  if (currency === "IDR") {
    balanceInUsd = balance / USD_TO_IDR_RATE;
  } else if (currency === "USC") {
    balanceInUsd = balance / USD_TO_USC_RATE;
  }

  const riskAmountUsd = balanceInUsd * (riskPercent / 100);
  let riskAmountCurrency = balance * (riskPercent / 100);

  // Lot Size Calculation (Professional Broker Formula)
  let standardLot = 0.01;
  if (isGold) {
    // 1 Lot XAUUSD = 100 oz ($100 per 1.0 point move)
    const dollarPerPointPerLot = 100;
    standardLot = riskAmountUsd / (Math.max(0.1, activeSlDistance) * dollarPerPointPerLot);
  } else if (isBtc) {
    // 1 Lot BTCUSD = 1 BTC ($1 per 1.0 point move)
    standardLot = riskAmountUsd / Math.max(10, activeSlDistance);
  } else if (isUs100) {
    // 1 Standard Lot US100 = $20 per point (CFD index contract)
    const dollarPerPointPerLot = 20;
    standardLot = riskAmountUsd / (Math.max(5, activeSlDistance) * dollarPerPointPerLot);
  } else if (isForex) {
    // 1 Lot Forex = $10 per pip (0.0001)
    const pips = activeSlDistance * 10000;
    standardLot = riskAmountUsd / (Math.max(1, pips) * 10);
  } else {
    // General CFD / Index ($1/pt)
    standardLot = riskAmountUsd / Math.max(0.1, activeSlDistance);
  }

  // Format Lot sizes
  standardLot = Math.max(0.01, Number(standardLot.toFixed(2)));
  const centLot = Number((standardLot * 100).toFixed(2));

  // Projected Profits in Selected Currency
  const expectedLossCurrency = riskAmountCurrency;
  const expectedTp1ProfitCurrency = riskAmountCurrency * rr1;
  const expectedTp2ProfitCurrency = riskAmountCurrency * rr2;
  const expectedTp3ProfitCurrency = riskAmountCurrency * rr3;

  const avgRr = Number(((rr1 + rr2 + rr3) / 3).toFixed(2));
  const evRatio = Number((((0.78 * avgRr) - (0.22 * 1.0)) * 1.0).toFixed(2));
  const gacorScore = Math.min(99.4, Number((85 + (avgRr * 2.8)).toFixed(1)));

  const currencySymbol = currency === "IDR" ? "Rp" : currency === "USC" ? "¢" : "$";

  return {
    isEnabled,
    currency,
    currencySymbol,
    balance,
    riskPercent,
    riskAmountCurrency,
    riskAmountUsd,
    entryPrice: entry,
    direction,
    isBuy,
    originalSl: signal?.sl || adjustedSl,
    originalTp1: signal?.tp1 || adjustedTp1,
    originalTp2: signal?.tp2 || adjustedTp2,
    originalTp3: signal?.tp3 || adjustedTp3,
    adjustedSl,
    adjustedTp1,
    adjustedTp2,
    adjustedTp3,
    slDistancePoints: Number(activeSlDistance.toFixed(2)),
    tp1DistancePoints: Number(activeTp1Distance.toFixed(2)),
    tp2DistancePoints: Number(activeTp2Distance.toFixed(2)),
    tp3DistancePoints: Number(activeTp3Distance.toFixed(2)),
    rrTp1: rr1,
    rrTp2: rr2,
    rrTp3: rr3,
    avgRr,
    recommendedLotStandard: standardLot,
    recommendedLotCent: centLot,
    expectedLossCurrency,
    expectedTp1ProfitCurrency,
    expectedTp2ProfitCurrency,
    expectedTp3ProfitCurrency,
    evRatio,
    gacorScore,
    gacorTierBadge: tierBadge,
    gacorAdvice: advice,
  };
}

export const GacorRiskCalculator: React.FC<GacorRiskCalculatorProps> = ({
  currentSignal,
  activeSymbol,
  symbol,
  currentPrice,
  config,
  onChangeConfig: propOnChangeConfig,
  onUpdateConfig: propOnUpdateConfig,
  onApplyToSignal,
  isEmbedded = false,
  visualTheme,
  copyToClipboard,
}) => {
  const effectiveSymbol = symbol || activeSymbol || { id: "XAUUSD", name: "GOLD" };
  const symObj = typeof effectiveSymbol === "string"
    ? { id: effectiveSymbol, name: effectiveSymbol }
    : (effectiveSymbol || { id: "XAUUSD", name: "GOLD" });

  const onChangeConfig = (newConfig: RiskCalculatorConfig) => {
    if (propOnChangeConfig) propOnChangeConfig(newConfig);
    if (propOnUpdateConfig) propOnUpdateConfig(newConfig);
  };

  const [copiedStatus, setCopiedStatus] = useState<"IDLE" | "COPIED">("IDLE");
  const [activeTab, setActiveTab] = useState<"QUICK" | "TUNER" | "TABLE">("QUICK");

  // Calculated live metrics
  const metrics = useMemo(() => {
    return calculateGacorRiskMetrics(currentSignal, effectiveSymbol, config);
  }, [currentSignal, effectiveSymbol, config]);

  // Balance presets depending on currency
  const balancePresets = useMemo(() => {
    if (config.currency === "IDR") {
      return [
        { label: "1 Jt", value: 1000000 },
        { label: "5 Jt", value: 5000000 },
        { label: "10 Jt", value: 10000000 },
        { label: "25 Jt", value: 25000000 },
        { label: "50 Jt", value: 50000000 },
        { label: "100 Jt", value: 100000000 },
      ];
    } else if (config.currency === "USC") {
      return [
        { label: "1,000¢ ($10)", value: 1000 },
        { label: "5,000¢ ($50)", value: 5000 },
        { label: "10,000¢ ($100)", value: 10000 },
        { label: "50,000¢ ($500)", value: 50000 },
        { label: "100,000¢ ($1K)", value: 100000 },
      ];
    } else {
      return [
        { label: "$100", value: 100 },
        { label: "$500", value: 500 },
        { label: "$1,000", value: 1000 },
        { label: "$5,000", value: 5000 },
        { label: "$10,000", value: 10000 },
        { label: "$50,000", value: 50000 },
      ];
    }
  }, [config.currency]);

  // Quick risk percentages
  const riskPresets = [0.5, 1.0, 1.5, 2.0, 3.0];

  const handleCopySetup = async () => {
    const text = ` [ZRILL AGI GACOR RISK SETUP - ${config.currency}]
Asset: ${symObj.id || "XAUUSD"} (${symObj.name || symObj.id || "GOLD"})
Aksi: ${metrics.direction} NOW @ $${metrics.entryPrice.toFixed(2)}
Mode Sinyal: ${metrics.isEnabled ? config.mode : "DEFAULT INSTITUSIONAL"}
Saldo Akun: ${formatCurrencyVal(metrics.balance, config.currency)}
Toleransi Risiko: ${metrics.riskPercent}% (${formatCurrencyVal(metrics.expectedLossCurrency, config.currency)})

 REKOMENDASI UKURAN LOT BROKER:
• Standar Lot: ${metrics.recommendedLotStandard} Lot
${config.currency === "USC" ? `• Akun Cent: ${metrics.recommendedLotCent} Cent Lot\n` : ""}
 TINGKAT BATAS HARGA (TERKALIBRASI GACOR):
• Stop Loss (SL): $${metrics.adjustedSl.toFixed(2)} (${metrics.slDistancePoints} pts)
• Target TP 1: $${metrics.adjustedTp1.toFixed(2)} (R:R 1:${metrics.rrTp1} | +${formatCurrencyVal(metrics.expectedTp1ProfitCurrency, config.currency)}) -> BE Kunci 0% Risiko
• Target TP 2: $${metrics.adjustedTp2.toFixed(2)} (R:R 1:${metrics.rrTp2} | +${formatCurrencyVal(metrics.expectedTp2ProfitCurrency, config.currency)}) -> Amankan 70% Profit
• Target TP 3: $${metrics.adjustedTp3.toFixed(2)} (R:R 1:${metrics.rrTp3} | +${formatCurrencyVal(metrics.expectedTp3ProfitCurrency, config.currency)}) -> 30% Runner Ekspansi
Probabilitas Gacor: ${metrics.gacorScore}% (+EV Asimetris)
`;

    let ok = false;
    if (copyToClipboard) {
      ok = await copyToClipboard(text);
    } else if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(text);
        ok = true;
      } catch {
        ok = false;
      }
    }
    if (ok) {
      setCopiedStatus("COPIED");
      setTimeout(() => setCopiedStatus("IDLE"), 2500);
    }
  };

  return (
    <div className={`rounded-2xl border transition-all ${
      config.isEnabled
        ? "bg-gradient-to-b from-[#0a121e] via-[#0b1626] to-[#070d17] border-emerald-500/50 shadow-[0_0_35px_rgba(16,185,129,0.18)]"
        : "bg-[#0c1017] border-gray-800"
    } p-4 sm:p-5 font-mono text-white flex flex-col gap-4`}>
      {/* Top Header: Title, ON/OFF Toggle, Currency Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
        <div className="flex items-center gap-2.5">
          <div className={`p-2 rounded-xl border ${
            config.isEnabled
              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.4)]"
              : "bg-gray-800 text-gray-400 border-gray-700"
          }`}>
            <Calculator className={`w-5 h-5 ${config.isEnabled ? "animate-pulse" : ""}`} />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-black tracking-wide text-white uppercase flex items-center gap-1.5">
                <span>KALKULATOR RISIKO &amp; ADJUSTER TP/SL GACOR</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              </span>
              <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold border ${
                config.isEnabled
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                  : "bg-gray-800 text-gray-400 border-gray-700"
              }`}>
                {config.isEnabled ? " AKTIF MENYESUAIKAN SINYAL" : "STANDBY (NONAKTIF)"}
              </span>
            </div>
            <p className="text-[11px] text-gray-400 mt-0.5 font-sans">
              Sesuaikan ukuran lot, jarak SL, dan multiplikator TP agar sinyal menghasilkan imbal hasil (+EV) segacor mungkin.
            </p>
          </div>
        </div>

        {/* Currency Picker & Master Switch */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Currency Pill Selector: USD, USC (Cent), IDR */}
          <div className="flex items-center bg-black/60 p-1 rounded-xl border border-white/10 text-xs">
            <button
              onClick={() => onChangeConfig({ ...config, currency: "USD" })}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                config.currency === "USD"
                  ? "bg-emerald-500 text-black shadow-md shadow-emerald-500/30"
                  : "text-gray-400 hover:text-white"
              }`}
              title="US Dollar (Standar Akun Broker)"
            >
              $ USD
            </button>
            <button
              onClick={() => onChangeConfig({ ...config, currency: "USC" })}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                config.currency === "USC"
                  ? "bg-amber-400 text-black shadow-md shadow-amber-400/30"
                  : "text-gray-400 hover:text-white"
              }`}
              title="USD Cent (Akun Cent / Cent Account - Exness, FBS, etc.)"
            >
              ¢ USD CENT
            </button>
            <button
              onClick={() => onChangeConfig({ ...config, currency: "IDR" })}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                config.currency === "IDR"
                  ? "bg-cyan-400 text-black shadow-md shadow-cyan-400/30"
                  : "text-gray-400 hover:text-white"
              }`}
              title="Rupiah Indonesia (Kurs ~Rp 16.250 / USD)"
            >
              Rp IDR
            </button>
          </div>

          {/* ON / OFF Switch Button */}
          <button
            onClick={() => {
              const nextState = !config.isEnabled;
              onChangeConfig({ ...config, isEnabled: nextState });
              if (onApplyToSignal) {
                onApplyToSignal({ ...metrics, isEnabled: nextState });
              }
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-md ${
              config.isEnabled
                ? "bg-emerald-400 hover:bg-emerald-300 text-black shadow-emerald-500/40 active:scale-95"
                : "bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-700"
            }`}
          >
            <span>{config.isEnabled ? " ON (GACOR AKTIF)" : " OFF (NONAKTIF)"}</span>
          </button>
        </div>
      </div>

      {/* Main Mode Presets: 3 Gacor Modes + Custom */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <button
          onClick={() => onChangeConfig({ ...config, mode: "ULTRA_SNIPER" })}
          className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            config.mode === "ULTRA_SNIPER"
              ? "bg-rose-950/40 border-rose-500/80 shadow-[0_0_15px_rgba(244,63,94,0.25)] text-rose-100"
              : "bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                ULTRA SNIPER GACOR
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                SL KETAT 0.85x
              </span>
            </div>
            <p className="text-[10px] text-gray-300 mt-1 font-sans leading-tight">
              SL rapat di balik fractal. Rasio R:R 1:3.2+ untuk asimetri profit tinggi.
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-rose-400">TP: 1.6R • 3.2R • 5.0R</div>
        </button>

        <button
          onClick={() => onChangeConfig({ ...config, mode: "GOLDEN_ASYMMETRIC" })}
          className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            config.mode === "GOLDEN_ASYMMETRIC"
              ? "bg-emerald-950/40 border-emerald-500/80 shadow-[0_0_15px_rgba(16,185,129,0.25)] text-emerald-100"
              : "bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                GOLDEN ASYMMETRIC
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                REKOMENDASI AI
              </span>
            </div>
            <p className="text-[10px] text-gray-300 mt-1 font-sans leading-tight">
              Keseimbangan ideal antara winrate 88%+ dan perlindungan OTE Fibonacci.
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-emerald-400">TP: 1.8R • 3.6R • 6.0R</div>
        </button>

        <button
          onClick={() => onChangeConfig({ ...config, mode: "MEGA_RUNNER" })}
          className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            config.mode === "MEGA_RUNNER"
              ? "bg-cyan-950/40 border-cyan-500/80 shadow-[0_0_15px_rgba(6,182,212,0.25)] text-cyan-100"
              : "bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                MEGA RUNNER GACOR
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                ANTI STOP-HUNT
              </span>
            </div>
            <p className="text-[10px] text-gray-300 mt-1 font-sans leading-tight">
              SL buffer 1.35x kebal sweep likuiditas, menangkap swing makro besar.
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-cyan-400">TP: 2.2R • 4.8R • 8.5R</div>
        </button>

        <button
          onClick={() => onChangeConfig({ ...config, mode: "CUSTOM" })}
          className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
            config.mode === "CUSTOM"
              ? "bg-amber-950/40 border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.25)] text-amber-100"
              : "bg-black/30 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
          }`}
        >
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white flex items-center gap-1">
                <Sliders className="w-3.5 h-3.5 text-amber-400" />
                CUSTOM PRESISI
              </span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                SLIDER MANUAL
              </span>
            </div>
            <p className="text-[10px] text-gray-300 mt-1 font-sans leading-tight">
              Atur jarak poin SL, multiplier target TP, dan batas risiko secara bebas.
            </p>
          </div>
          <div className="mt-2 text-[10px] font-bold text-amber-400">Kustomisasi Penuh</div>
        </button>
      </div>

      {/* Input Controls: Capital / Balance & Risk Percentage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-black/40 p-4 rounded-xl border border-white/5">
        {/* Left: Balance Input & Quick Presets */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
              <Coins className="w-3.5 h-3.5 text-emerald-400" />
              Modal / Saldo Akun ({config.currency})
            </label>
            <span className="text-[10px] text-gray-400 font-mono">
              {config.currency === "IDR" ? "Rupiah" : config.currency === "USC" ? "Cent Account" : "US Dollar"}
            </span>
          </div>

          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold text-sm">
              {metrics.currencySymbol}
            </span>
            <input
              type="number"
              value={config.balance}
              onChange={(e) => {
                const val = parseFloat(e.target.value) || 0;
                onChangeConfig({ ...config, balance: val });
              }}
              min="1"
              step={config.currency === "IDR" ? "100000" : config.currency === "USC" ? "1000" : "50"}
              className="w-full bg-[#121722] border border-gray-700 focus:border-emerald-400 rounded-xl py-2 pl-9 pr-3 text-sm font-mono font-bold text-white outline-none"
              placeholder={`Masukkan saldo dalam ${config.currency}`}
            />
          </div>

          {/* Quick Balance Presets */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            <span className="text-[9px] text-gray-500 uppercase">Cepat:</span>
            {balancePresets.map((bp) => (
              <button
                key={`bp_${bp.label}`}
                onClick={() => onChangeConfig({ ...config, balance: bp.value })}
                className={`text-[10px] px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  config.balance === bp.value
                    ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold"
                    : "bg-white/5 text-gray-400 border-white/10 hover:text-white hover:border-white/20"
                }`}
              >
                {bp.label}
              </button>
            ))}
          </div>
        </div>

        {/* Right: Risk Percentage per Trade */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-rose-400" />
              Toleransi Risiko Per Transaksi (%)
            </label>
            <span className="text-[10px] font-bold text-rose-400 font-mono">
              Max Rugi: {formatCurrencyVal(metrics.expectedLossCurrency, config.currency)}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="range"
              min="0.25"
              max="5.0"
              step="0.25"
              value={config.riskPercent}
              onChange={(e) => onChangeConfig({ ...config, riskPercent: parseFloat(e.target.value) })}
              className="w-full accent-emerald-400 cursor-pointer"
            />
            <span className="text-sm font-black font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/30 shrink-0">
              {config.riskPercent.toFixed(2)}%
            </span>
          </div>

          {/* Quick Risk Presets */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            <span className="text-[9px] text-gray-500 uppercase">Preset:</span>
            {riskPresets.map((pct) => (
              <button
                key={`risk_preset_${pct}`}
                onClick={() => onChangeConfig({ ...config, riskPercent: pct })}
                className={`text-[10px] px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                  config.riskPercent === pct
                    ? "bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold"
                    : "bg-white/5 text-gray-400 border-white/10 hover:text-white hover:border-white/20"
                }`}
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* If Custom Mode is selected: Sliders for SL & TP Multipliers */}
      {config.mode === "CUSTOM" && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="bg-amber-950/20 p-4 rounded-xl border border-amber-500/30 flex flex-col gap-3"
        >
          <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase">
            <Sliders className="w-4 h-4 text-amber-400" />
            Penyesuaian Manual SL &amp; Multiplier Target TP
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                <span>Target TP 1 (Scalp / BE)</span>
                <span className="font-bold text-emerald-400">1:{config.customTp1Multiplier || 1.8}R</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="3.0"
                step="0.1"
                value={config.customTp1Multiplier || 1.8}
                onChange={(e) => onChangeConfig({ ...config, customTp1Multiplier: parseFloat(e.target.value) })}
                className="w-full accent-emerald-400 cursor-pointer"
              />
            </div>
            <div>
              <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                <span>Target TP 2 (Struktur)</span>
                <span className="font-bold text-emerald-400">1:{config.customTp2Multiplier || 3.5}R</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="6.0"
                step="0.1"
                value={config.customTp2Multiplier || 3.5}
                onChange={(e) => onChangeConfig({ ...config, customTp2Multiplier: parseFloat(e.target.value) })}
                className="w-full accent-emerald-400 cursor-pointer"
              />
            </div>
            <div>
              <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                <span>Target TP 3 (Macro Runner)</span>
                <span className="font-bold text-cyan-400">1:{config.customTp3Multiplier || 6.0}R</span>
              </div>
              <input
                type="range"
                min="3.0"
                max="12.0"
                step="0.5"
                value={config.customTp3Multiplier || 6.0}
                onChange={(e) => onChangeConfig({ ...config, customTp3Multiplier: parseFloat(e.target.value) })}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </motion.div>
      )}

      {/* Real-time Calculated Gacor Result Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Metric 1: Recommended Lot Size */}
        <div className="bg-gradient-to-br from-[#131b28] to-[#0c121d] p-3.5 rounded-xl border border-emerald-500/30 flex flex-col justify-between shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            REKOMENDASI UKURAN LOT
          </span>
          <div className="my-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-amber-300 font-mono">
              {metrics.recommendedLotStandard} <span className="text-xs text-gray-400 font-sans">Lot</span>
            </span>
          </div>
          <div className="text-[9px] text-gray-400 flex flex-col gap-0.5">
            {config.currency === "USC" ? (
              <span className="text-cyan-300 font-bold">Akun Cent: {metrics.recommendedLotCent} Cent Lot</span>
            ) : (
              <span>Standar 100% Bebas Margin Call</span>
            )}
            <span className="text-emerald-400">Jarak SL: {metrics.slDistancePoints} pts</span>
          </div>
        </div>

        {/* Metric 2: Max Risk (SL) Amount */}
        <div className="bg-gradient-to-br from-[#1a1114] to-[#120c0e] p-3.5 rounded-xl border border-rose-500/30 flex flex-col justify-between shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            RISIKO MAKSIMAL (SL)
          </span>
          <div className="my-1 flex items-baseline gap-1">
            <span className="text-2xl font-black text-rose-400 font-mono">
              {formatCurrencyVal(metrics.expectedLossCurrency, config.currency)}
            </span>
          </div>
          <div className="text-[9px] text-gray-400 flex justify-between">
            <span>Tepat {metrics.riskPercent}% dari saldo</span>
            <span className="text-rose-300 font-bold">Batas Invalidation</span>
          </div>
        </div>

        {/* Metric 3: Target TP2 Profit */}
        <div className="bg-gradient-to-br from-[#0c1a16] to-[#08120f] p-3.5 rounded-xl border border-emerald-500/30 flex flex-col justify-between shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            PROYEKSI PROFIT TP2 (R:R 1:{metrics.rrTp2})
          </span>
          <div className="my-1 flex items-baseline gap-1">
            <span className="text-2xl font-black text-emerald-400 font-mono">
              +{formatCurrencyVal(metrics.expectedTp2ProfitCurrency, config.currency)}
            </span>
          </div>
          <div className="text-[9px] text-gray-400 flex justify-between">
            <span>Target Utama Struktur</span>
            <span className="text-emerald-300 font-bold">+{metrics.rrTp2}R Asimetris</span>
          </div>
        </div>

        {/* Metric 4: Target TP3 Profit (Runner) */}
        <div className="bg-gradient-to-br from-[#0a1824] to-[#071018] p-3.5 rounded-xl border border-cyan-500/30 flex flex-col justify-between shadow-sm">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
            PROYEKSI TP3 RUNNER (R:R 1:{metrics.rrTp3})
          </span>
          <div className="my-1 flex items-baseline gap-1">
            <span className="text-2xl font-black text-cyan-300 font-mono">
              +{formatCurrencyVal(metrics.expectedTp3ProfitCurrency, config.currency)}
            </span>
          </div>
          <div className="text-[9px] text-gray-400 flex justify-between">
            <span>Ekspansi Makro</span>
            <span className="text-cyan-300 font-bold">+{metrics.rrTp3}R Gacor</span>
          </div>
        </div>
      </div>

      {/* Multi-Level Calibrated TP & SL Price Display */}
      <div className="bg-black/50 p-4 rounded-xl border border-white/10 space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <span className="text-xs font-black text-gray-200 uppercase tracking-wider flex items-center gap-1.5">
            <Scale className="w-4 h-4 text-emerald-400" />
            Parameter Harga Terkalibrasi (Sinyal {metrics.direction} @ ${metrics.entryPrice.toFixed(2)})
          </span>
          <span className="text-[10px] font-bold text-emerald-400 font-mono">
            {metrics.gacorTierBadge}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
          {/* SL */}
          <div className="bg-rose-950/30 p-2.5 rounded-xl border border-rose-500/40 flex flex-col justify-between">
            <span className="text-[9px] font-bold text-rose-300 uppercase">STOP LOSS (SL)</span>
            <span className="text-base font-black text-rose-400 my-0.5">
              ${metrics.adjustedSl.toFixed(2)}
            </span>
            <span className="text-[9px] text-rose-300/80">
              Jarak: {metrics.slDistancePoints} pts (-{formatCurrencyVal(metrics.expectedLossCurrency, config.currency)})
            </span>
          </div>

          {/* TP1 */}
          <div className="bg-emerald-950/30 p-2.5 rounded-xl border border-emerald-500/40 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-emerald-300 uppercase">TARGET TP 1</span>
              <span className="text-[8px] px-1 rounded bg-emerald-500/20 text-emerald-300">1:{metrics.rrTp1}R</span>
            </div>
            <span className="text-base font-black text-emerald-300 my-0.5">
              ${metrics.adjustedTp1.toFixed(2)}
            </span>
            <span className="text-[9px] text-emerald-400 font-bold">
              +{formatCurrencyVal(metrics.expectedTp1ProfitCurrency, config.currency)} (BE Kunci)
            </span>
          </div>

          {/* TP2 */}
          <div className="bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-500/60 flex flex-col justify-between shadow-[0_0_15px_rgba(16,185,129,0.1)]">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-emerald-200 uppercase">TARGET TP 2</span>
              <span className="text-[8px] px-1 rounded bg-emerald-500/30 text-emerald-200">1:{metrics.rrTp2}R</span>
            </div>
            <span className="text-base font-black text-emerald-400 my-0.5">
              ${metrics.adjustedTp2.toFixed(2)}
            </span>
            <span className="text-[9px] text-emerald-300 font-bold">
              +{formatCurrencyVal(metrics.expectedTp2ProfitCurrency, config.currency)} (Amankan 70%)
            </span>
          </div>

          {/* TP3 */}
          <div className="bg-cyan-950/40 p-2.5 rounded-xl border border-cyan-500/60 flex flex-col justify-between shadow-[0_0_15px_rgba(6,182,212,0.1)]">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-cyan-200 uppercase">TARGET TP 3</span>
              <span className="text-[8px] px-1 rounded bg-cyan-500/30 text-cyan-200">1:{metrics.rrTp3}R</span>
            </div>
            <span className="text-base font-black text-cyan-300 my-0.5">
              ${metrics.adjustedTp3.toFixed(2)}
            </span>
            <span className="text-[9px] text-cyan-300 font-bold">
              +{formatCurrencyVal(metrics.expectedTp3ProfitCurrency, config.currency)} (Runner 30%)
            </span>
          </div>
        </div>

        {/* Tactical Advice & Copy Button */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2 border-t border-white/5 text-[11px] font-sans">
          <p className="text-gray-300 leading-tight">
             <strong className="text-white">Strategi Eksekusi Gacor:</strong> {metrics.gacorAdvice}
          </p>

          <button
            onClick={handleCopySetup}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 hover:from-emerald-500/30 hover:to-cyan-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 shadow-sm active:scale-95"
          >
            {copiedStatus === "COPIED" ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>TERSALIN KE CLIPBOARD!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-emerald-400" />
                <span>SALIN PARAMETER BROKER / MT4</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
