import React from "react";
import { motion } from "motion/react";
import {
  Clock,
  Globe,
  Radio,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Zap,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Calendar,
} from "lucide-react";
import { WitaCalendarSync } from "../services/precisionSignalEngine";

interface WitaSessionSyncCardProps {
  data?: WitaCalendarSync;
  liveWitaTimeStr?: string;
  onNavigateToCalendar?: () => void;
  visualTheme?: "SLATE" | "IPHONE_GLASS";
}

export const WitaSessionSyncCard: React.FC<WitaSessionSyncCardProps> = ({
  data,
  liveWitaTimeStr,
  onNavigateToCalendar,
  visualTheme = "IPHONE_GLASS",
}) => {
  const currentWitaTime = liveWitaTimeStr || data?.currentWitaTime || new Date().toLocaleTimeString("id-ID", {
    timeZone: "Asia/Makassar",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }) + " WITA";

  const activeSession = data?.activeSession || "SESI LONDON (Eropa)";
  const isKillzone = data?.isKillzone ?? true;
  const killzoneBadge = data?.killzoneBadge || "LONDON KILLZONE AKTIF";
  const progressPct = data?.sessionProgressPct ?? 65;
  const nextSession = data?.nextSessionName || "Sesi New York (AS)";
  const timeToNext = data?.timeToNextSession || "1j 45m";

  const nearestEvent = data?.nearestHighImpactEvent;
  const safetyStatus = data?.newsSafetyStatus || " SAFE TRADING WINDOW (No High Impact News in next 2 hours)";
  const isSafe = safetyStatus.startsWith("");
  const isImminent = safetyStatus.startsWith("");

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className={`rounded-2xl border transition-all relative overflow-hidden font-mono shadow-xl ${
        visualTheme === "IPHONE_GLASS"
          ? "bg-gradient-to-br from-[#0a1120]/95 via-[#08151f]/90 to-[#0c0d18]/95 border-cyan-500/30 shadow-[0_10px_35px_rgba(6,182,212,0.15)]"
          : "bg-[#0f172a] border-cyan-500/30"
      }`}
    >
      {/* Top ambient highlight */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-500 via-emerald-400 to-indigo-500 shadow-[0_0_12px_rgba(6,182,212,0.8)]" />

      <div className="p-4 sm:p-5 flex flex-col gap-4">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
              <Globe className="w-5 h-5 animate-spin" style={{ animationDuration: "20s" }} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                  WITA REALTIME CALENDAR &amp; SESSION SYNCHRONIZER
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[8px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  UTC+8 MAKASSAR / BALI
                </span>
              </div>
              <p className="text-[10px] text-gray-400 mt-0.5">
                Sinkronisasi Terpadu Jam WITA (UTC+8) &amp; Dampak Berita Ekonomi Makro
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-black/60 border border-cyan-500/30 text-cyan-300">
              <Clock className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span className="text-sm font-black tracking-wider">{currentWitaTime}</span>
            </div>
          </div>
        </div>

        {/* 3 Interactive Synchronizer Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Pillar 1: Sesi Bursa Aktif & Killzone */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                <Radio className="w-3 h-3 text-cyan-400" /> Sesi Bursa Global
              </span>
              <span
                className={`text-[8px] font-black px-1.5 py-0.5 rounded border uppercase ${
                  isKillzone
                    ? "bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse"
                    : "bg-cyan-500/20 text-cyan-300 border-cyan-500/40"
                }`}
              >
                {killzoneBadge}
              </span>
            </div>

            <div>
              <div className="text-sm font-black text-white tracking-wide flex items-center gap-1.5">
                {activeSession}
              </div>
              <div className="text-[9px] text-gray-400 mt-0.5">
                Menuju {nextSession} dlm <strong className="text-cyan-300">{timeToNext}</strong>
              </div>
            </div>

            {/* Session Progress Bar */}
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between text-[8px] text-gray-400">
                <span>Progres Sesi</span>
                <span className="text-cyan-300 font-bold">{progressPct}%</span>
              </div>
              <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden border border-white/5">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-teal-400 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.max(5, progressPct))}%` }}
                />
              </div>
            </div>
          </div>

          {/* Pillar 2: Status Keselamatan Berita Makro (Macro Guard) */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" /> Filter Keselamatan Berita
              </span>
              <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-white/5 text-gray-300 border border-white/10">
                VOLATILITAS: {data?.volatilityMultiplier || "1.0x"}
              </span>
            </div>

            <div>
              <div
                className={`text-xs font-black tracking-wide flex items-center gap-1.5 ${
                  isSafe ? "text-emerald-400" : isImminent ? "text-amber-400" : "text-rose-400"
                }`}
              >
                {isSafe ? <ShieldCheck className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
                <span className="line-clamp-1">{safetyStatus.split("(")[0]}</span>
              </div>
              <p className="text-[9px] text-gray-400 mt-1 leading-relaxed">
                {isSafe
                  ? "Jendela waktu trading aman: Tidak ada berita berdampak tinggi merah dalam 2 jam ke depan."
                  : "Peringatan volatilitas makro: Harap batasi risiko dan gunakan trailing SL protektif."}
              </p>
            </div>

            <div className="flex items-center gap-1.5 text-[8px] text-gray-400 bg-white/[0.02] p-1.5 rounded-lg border border-white/5">
              <Flame className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Proteksi Slippage &amp; Spike Spreading Otomatis Terkunci</span>
            </div>
          </div>

          {/* Pillar 3: Peristiwa Berdampak Tinggi Terdekat */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 flex flex-col justify-between gap-2.5">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest flex items-center gap-1">
                <Calendar className="w-3 h-3 text-cyan-400" /> Berita Terdekat
              </span>
              {nearestEvent && (
                <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  {nearestEvent.currency}
                </span>
              )}
            </div>

            {nearestEvent ? (
              <div>
                <div className="text-xs font-black text-white tracking-wide line-clamp-1">
                  {nearestEvent.title}
                </div>
                <div className="flex items-center gap-2 mt-1 text-[9px]">
                  <span className="text-cyan-300 font-bold flex items-center gap-1">
                    <Clock className="w-3 h-3 text-cyan-400" /> {nearestEvent.witaReleaseTime}
                  </span>
                  <span className="text-gray-400">|</span>
                  <span className="text-amber-300 font-bold">
                    {nearestEvent.countdownStr}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-[8px] text-gray-300">
                  <span>Estimasi: <strong>{nearestEvent.forecast}</strong></span>
                  <span>Prev: <strong>{nearestEvent.previous}</strong></span>
                  <span
                    className={`font-bold ml-auto flex items-center gap-0.5 ${
                      nearestEvent.impactDirection === "BUY" ? "text-emerald-400" : "text-rose-400"
                    }`}
                  >
                    {nearestEvent.impactDirection === "BUY" ? (
                      <TrendingUp className="w-2.5 h-2.5" />
                    ) : (
                      <TrendingDown className="w-2.5 h-2.5" />
                    )}
                    {nearestEvent.impactDirection} ({nearestEvent.confidence}%)
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-[10px] text-gray-400 py-1">
                Sedang memindai kalender ekonomi makro langsung...
              </div>
            )}

            {onNavigateToCalendar && (
              <button
                onClick={onNavigateToCalendar}
                className="mt-1 w-full py-1.5 px-2 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-[9px] font-bold uppercase tracking-wider flex items-center justify-center gap-1 transition-all"
              >
                <span>Lihat Seluruh Jadwal di Kalender Live</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
