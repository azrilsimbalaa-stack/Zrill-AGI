import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Sparkles,
  Target,
  Clock,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
  Zap,
  ArrowRight,
  Copy,
  Check,
  X,
  Scale,
  Layers,
  Compass,
} from "lucide-react";
import { OptimalRetestAdvisory, GoldenZone0618Quality, AmdPhaseAnalysis, ZrillV5CoreAnalysis } from "../services/precisionSignalEngine";

export interface FibonacciMatrixData {
  fib0_EquilibriumHigh?: number;
  fib382?: number;
  fib500_Equilibrium?: number;
  fib618_GoldenPocket?: number;
  fib705_OptimalEntry?: number;
  fib786_DeepExtreme?: number;
  fib100_SwingAnchor?: number;
  fib1272_LiquidityTarget?: number;
  fib1618_GoldenExpansion?: number;
  fib2618_MacroExpansion?: number;
}

interface RetestAdvisoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  advisory?: OptimalRetestAdvisory;
  goldenZoneQuality?: GoldenZone0618Quality;
  amdAnalysis?: AmdPhaseAnalysis;
  zrillCore?: ZrillV5CoreAnalysis;
  symbol: string;
  currentPrice: number;
  isOrderBuy: boolean;
  fibMatrix?: FibonacciMatrixData;
  onApplyLimitOrder?: (limitPrice: number) => void;
  copyToClipboard?: (text: string) => Promise<boolean>;
}

export const RetestAdvisoryModal: React.FC<RetestAdvisoryModalProps> = ({
  isOpen,
  onClose,
  advisory,
  goldenZoneQuality,
  amdAnalysis,
  zrillCore,
  symbol,
  currentPrice,
  isOrderBuy,
  fibMatrix,
  onApplyLimitOrder,
  copyToClipboard,
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedLevel, setCopiedLevel] = useState<string | null>(null);

  const isMomentum = advisory?.status === "MOMENTUM_BREAKOUT_NO_RETEST";
  const isRetestActive = advisory?.status === "RETEST_ZONE_ACTIVE";
  const isWaitRetest = advisory?.status === "WAIT_RETEST_RECOMMENDED";

  // Derive Golden Ratio levels
  const fib618 = fibMatrix?.fib618_GoldenPocket ?? advisory?.optimalRetestPrice ?? (isOrderBuy ? currentPrice * 0.994 : currentPrice * 1.006);
  const fib705 = fibMatrix?.fib705_OptimalEntry ?? (isOrderBuy ? fib618 * 0.997 : fib618 * 1.003);
  const fib500 = fibMatrix?.fib500_Equilibrium ?? (isOrderBuy ? fib618 * 1.003 : fib618 * 0.997);
  const fib786 = fibMatrix?.fib786_DeepExtreme ?? (isOrderBuy ? fib705 * 0.997 : fib705 * 1.003);

  // Check if live price is inside the 0.618 - 0.705 Golden Pocket
  const isInsideGoldenPocket = isOrderBuy
    ? currentPrice <= Math.max(fib618, fib705) && currentPrice >= Math.min(fib618, fib705)
    : currentPrice >= Math.min(fib618, fib705) && currentPrice <= Math.max(fib618, fib705);

  const handleCopySetup = async () => {
    const textToCopy = zrillCore?.formattedOutputSignalText || goldenZoneQuality?.formattedOutputSignalText || (advisory ? ` [ZR TRADING AI - STRATEGI HARGA TERBAIK & RETEST GOLDEN RATIO]
 Simbol: ${symbol}
 Harga Live Sekarang: $${currentPrice.toFixed(2)}
 Status Retest: ${advisory.advisoryTitle}
 Arahan: ${advisory.advisoryMessage}

 MATRIX RETEST GOLDEN RATIO (FIBONACCI):
- 0.500 Equilibrium: $${fib500.toFixed(2)}
- 0.618 Golden Pocket (Phi): $${fib618.toFixed(2)} (REKOMENDASI UTAMA)
- 0.705 OTE Sniper: $${fib705.toFixed(2)} (Optimal Trade Entry)
- 0.786 Deep Discount/Premium: $${fib786.toFixed(2)}

 Potensi Hemat Drawdown: ${(advisory as any).drawdownSavingPips || advisory.distanceToRetestPips || 0} pips (${(advisory as any).drawdownSavingDollarEstimate || ""})
 Proyeksi R:R Optimal: ${advisory.improvedRiskReward}

 Rekomendasi Eksekusi:
- Opsi 1 (Market Now): ${advisory.traderTacticalChoice.instantMarketAction.actionLabel} @ $${currentPrice.toFixed(2)}
- Opsi 2 (Pending Limit Golden Ratio): ${advisory.traderTacticalChoice.limitRetestAction.actionLabel} @ $${fib618.toFixed(2)}` : "");

    if (!textToCopy) return;

    if (copyToClipboard) {
      const res = await copyToClipboard(textToCopy);
      if (res) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } else {
      try {
        await navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (e) {}
    }
  };

  const handleCopySinglePrice = async (levelName: string, price: number) => {
    const text = price.toFixed(2);
    if (copyToClipboard) {
      await copyToClipboard(text);
    } else {
      try {
        await navigator.clipboard.writeText(text);
      } catch (e) {}
    }
    setCopiedLevel(levelName);
    setTimeout(() => setCopiedLevel(null), 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && advisory && (
        <motion.div
          key="retest-modal-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          onClick={onClose}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xl fps-120"
        >
          <motion.div 
            key="retest-modal-card"
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0.04, bottom: 0.65 }}
            onDragEnd={(_e, info) => {
              if (info.offset.y > 50 || info.velocity.y > 260) {
                onClose();
              }
            }}
            initial={{ y: 60, opacity: 0, scale: 0.94 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 70, opacity: 0, scale: 0.92 }}
            transition={{
              type: "spring",
              stiffness: 480,
              damping: 34,
              mass: 0.6,
            }}
            className="bg-black/65 backdrop-blur-3xl backdrop-saturate-200 border border-white/20 rounded-[28px] w-full max-w-md max-h-[85vh] overflow-y-auto font-mono shadow-[0_25px_60px_-10px_rgba(0,0,0,0.85),inset_0_1px_1.5px_rgba(255,255,255,0.25)] relative text-gray-200 flex flex-col gap-3 p-3.5 sm:p-4.5 transform-gpu fps-120 select-none"
            onClick={(e) => e.stopPropagation()}
          >
            {/* iOS Gesture Pill Handle (Geser kebawah / Drag Down to Dismiss) */}
            <div className="w-10 h-1 bg-white/30 hover:bg-white/45 active:bg-white/60 rounded-full mx-auto -mt-0.5 cursor-grab active:cursor-grabbing transition-colors" />

            {/* Top Subtle Apple Glass Sheen */}
            <div className="absolute top-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-white/30 to-transparent" />

        {/* Modal Header */}
        <div className="flex items-start justify-between gap-2.5 border-b border-white/10 pb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.25)] shrink-0">
              <Sparkles className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-xs sm:text-sm font-black text-white tracking-wide uppercase">
                  AI RETEST &amp; BEST PRICE
                </h3>
                <span className={`px-2 py-0.5 rounded-full text-[8.5px] font-black uppercase tracking-wider border shadow-sm ${
                  isOrderBuy
                    ? isRetestActive
                      ? "bg-emerald-500/25 text-emerald-300 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.3)] animate-pulse"
                      : isMomentum
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                      : "bg-cyan-500/20 text-cyan-300 border-cyan-500/40"
                    : isRetestActive
                    ? "bg-rose-500/25 text-rose-300 border-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.3)] animate-pulse"
                    : isMomentum
                    ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                    : "bg-amber-500/20 text-amber-300 border-amber-500/40"
                }`}>
                  {isOrderBuy
                    ? isRetestActive
                      ? " RETEST BUY"
                      : isMomentum
                      ? " MOMENTUM BUY"
                      : " WAIT RETEST BUY"
                    : isRetestActive
                    ? " RETEST SELL"
                    : isMomentum
                    ? " MOMENTUM SELL"
                    : " WAIT RETEST SELL"}
                </span>

                {amdAnalysis && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[8.5px] font-black uppercase tracking-wider border shadow-sm flex items-center gap-1 ${
                      amdAnalysis.currentPhase === "MANIPULASI"
                        ? "bg-rose-500/30 text-rose-300 border-rose-500/50 shadow-rose-900/30 animate-pulse"
                        : amdAnalysis.currentPhase === "DISTRIBUSI"
                        ? "bg-emerald-500/30 text-emerald-300 border-emerald-500/50 shadow-emerald-900/30"
                        : "bg-amber-500/30 text-amber-300 border-amber-500/50 shadow-amber-900/30"
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                    {amdAnalysis.currentPhase === "AKUMULASI"
                      ? "FASE: AKUMULASI"
                      : amdAnalysis.currentPhase === "MANIPULASI"
                      ? "FASE: MANIPULASI"
                      : "FASE: DISTRIBUSI"}
                  </span>
                )}
                {zrillCore && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[8.5px] font-black uppercase tracking-wider border shadow-sm flex items-center gap-1 ${
                      zrillCore.confluenceScore >= 9
                        ? "bg-emerald-500/30 text-emerald-300 border-emerald-500/50 shadow-emerald-900/30"
                        : zrillCore.confluenceScore >= 7
                        ? "bg-amber-500/30 text-amber-300 border-amber-500/50 shadow-amber-900/30"
                        : "bg-rose-500/30 text-rose-300 border-rose-500/50 shadow-rose-900/30"
                    }`}
                  >
                    <Zap className="w-2.5 h-2.5 text-amber-400" />
                    <span>ZRILL v5: {zrillCore.confluenceScore}/10</span>
                  </span>
                )}
              </div>
              <p className="text-[10px] text-gray-400 mt-0.5">
                {symbol} • Live: <strong className="text-white">${currentPrice.toFixed(2)}</strong> • Aksi: <strong className={isOrderBuy ? "text-emerald-400" : "text-rose-400"}>{isOrderBuy ? "BUY" : "SELL"}</strong>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 active:scale-90 text-gray-300 hover:text-white transition-all cursor-pointer shrink-0 border border-white/15"
            title="Tutup (atau Geser Kebawah)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Main Status & Advisory Banner */}
        <div className={`p-3 rounded-2xl border flex flex-col gap-1.5 backdrop-blur-xl ${
          isRetestActive
            ? isOrderBuy
              ? "bg-emerald-950/40 border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
              : "bg-rose-950/40 border-rose-500/50 shadow-[0_0_20px_rgba(244,63,94,0.2)]"
            : isMomentum
            ? "bg-amber-950/30 border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.1)]"
            : "bg-cyan-950/30 border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.1)]"
        }`}>
          <div className="flex items-center gap-1.5">
            {isRetestActive ? (
              <Zap className={`w-4 h-4 shrink-0 animate-bounce ${isOrderBuy ? "text-emerald-400" : "text-rose-400"}`} />
            ) : isMomentum ? (
              <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            ) : (
              <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            )}
            <span className="text-xs font-black text-white uppercase tracking-wide">
              {advisory.advisoryTitle}
            </span>
          </div>
          <p className="text-[10px] text-gray-300 leading-relaxed">
            {advisory.advisoryMessage}
          </p>
        </div>

        {/* AMD Phase Status Banner */}
        {amdAnalysis && (
          <div
            className={`p-3 rounded-2xl border flex items-center justify-between text-xs font-mono font-bold shadow-md ${
              amdAnalysis.currentPhase === "MANIPULASI"
                ? "bg-rose-500/15 border-rose-500/40 text-rose-200"
                : amdAnalysis.currentPhase === "DISTRIBUSI"
                ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-200"
                : "bg-amber-500/15 border-amber-500/40 text-amber-200"
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-current animate-ping" />
              <div>
                <div className="text-[9px] uppercase text-slate-400 tracking-wider">STATUS FASE SIKLUS AMD:</div>
                <div className="font-extrabold uppercase text-xs">{amdAnalysis.phaseBadge}</div>
              </div>
            </div>
            <div className="text-right shrink-0">
              <span className="px-2 py-1 rounded bg-black/40 border border-white/10 text-[10px]">
                {amdAnalysis.currentPhase === "AKUMULASI"
                  ? "AKUMULASI"
                  : amdAnalysis.currentPhase === "MANIPULASI"
                  ? "MANIPULASI"
                  : "DISTRIBUSI"}
              </span>
            </div>
          </div>
        )}

        {/* ZRILL v5.0 Precision Core Confluence Banner */}
        {zrillCore && (
          <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900/60 to-slate-950/60 border border-amber-500/30 flex items-center justify-between text-xs font-mono shadow-md">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40">
                <Zap className="w-3.5 h-3.5 animate-pulse" />
              </div>
              <div>
                <div className="text-[9px] uppercase text-amber-300 font-bold tracking-wider">
                  ZRILL AGI v5.0 ({zrillCore.confluenceScore}/10 KONFLUENSI):
                </div>
                <div className="font-extrabold text-white text-[11px] flex items-center gap-1.5">
                  <span>{zrillCore.ratingLabel}</span>
                  <span className="text-[10px] text-emerald-400 font-semibold">(~{zrillCore.winRateEstimatePct}% Win Rate)</span>
                </div>
              </div>
            </div>
            <div className="text-right shrink-0">
              <span className={`px-2 py-0.5 rounded text-[9.5px] font-bold border ${
                zrillCore.signalType === "WAITING"
                  ? "bg-slate-800 text-slate-300 border-slate-700"
                  : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
              }`}>
                {zrillCore.signalType}
              </span>
            </div>
          </div>
        )}

        {/*  PRINSIP INTI — KUALITAS ZONA GOLDEN RATIO 0.618 */}
        {goldenZoneQuality && (
          <div className="p-3 rounded-2xl bg-gradient-to-br from-[#0a1220] via-[#08152b] to-[#0d101a] border-2 border-amber-400/50 shadow-[0_0_25px_rgba(245,158,11,0.2)] flex flex-col gap-2.5">
            <div className="flex items-center justify-between border-b border-amber-400/20 pb-2">
              <span className="text-[10px] font-black text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                PRINSIP INTI — KUALITAS ZONA 0.618
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase border shadow-sm ${
                goldenZoneQuality.badgeColor === "emerald"
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/50"
                  : goldenZoneQuality.badgeColor === "amber"
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/50"
                  : "bg-rose-500/20 text-rose-300 border-rose-500/50"
              }`}>
                {goldenZoneQuality.statusSignalText}
              </span>
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="p-2 rounded-xl bg-black/40 border border-white/10 flex flex-col gap-1">
                <span className="text-[9px] font-black text-white flex items-center gap-1">
                  STATUS ZONA: <span className={
                    goldenZoneQuality.badgeColor === "emerald" ? "text-emerald-300" :
                    goldenZoneQuality.badgeColor === "amber" ? "text-amber-300" : "text-rose-300"
                  }>{goldenZoneQuality.badgeLabel}</span>
                </span>
                <p className="text-[8.5px] text-gray-300 leading-tight">
                  {goldenZoneQuality.touchHistoryDescription}
                </p>
              </div>

              <div className="p-2 rounded-xl bg-black/40 border border-white/10 flex flex-col gap-1">
                <span className="text-[9px] font-black text-cyan-300 flex items-center gap-1">
                  EVALUASI KELANCARAN TREND:
                </span>
                <p className="text-[8.5px] text-gray-300 leading-tight">
                  {goldenZoneQuality.trendSmoothness.reasoning}
                </p>
              </div>

              <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/30 flex flex-col gap-1">
                <span className="text-[9px] font-black text-amber-300 flex items-center gap-1">
                   ARAHAN EKSEKUSI:
                </span>
                <p className="text-[8.5px] text-amber-100 leading-snug font-semibold">
                  "{goldenZoneQuality.executionInstruction}"
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Key Retest Metrics Grid */}
        <div className="grid grid-cols-3 gap-2">
          <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10 flex flex-col gap-0.5">
            <span className="text-[8px] font-bold text-gray-400 uppercase flex items-center gap-1">
              <Target className="w-3 h-3 text-cyan-400" />
              Area Retest
            </span>
            <span className="text-xs sm:text-sm font-black text-cyan-300">
              ${fib618.toFixed(2)}
            </span>
            <span className="text-[8px] text-amber-300/90 font-bold truncate">
              0.618 Golden Ratio
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10 flex flex-col gap-0.5">
            <span className="text-[8px] font-bold text-gray-400 uppercase flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              Drawdown
            </span>
            <span className="text-xs sm:text-sm font-black text-emerald-300">
              {advisory.drawdownSavingPips} Pips
            </span>
            <span className="text-[8px] text-emerald-400/90 truncate font-semibold">
              Hemat SL (0.618)
            </span>
          </div>

          <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/10 flex flex-col gap-0.5">
            <span className="text-[8px] font-bold text-gray-400 uppercase flex items-center gap-1">
              <Scale className="w-3 h-3 text-purple-400" />
              R:R Rasio
            </span>
            <span className="text-xs sm:text-sm font-black text-purple-300">
              1:4.82
            </span>
            <span className="text-[8px] text-purple-300/90 truncate">
              Optimal Golden Pocket
            </span>
          </div>
        </div>

        {/*  DEDICATED FIBONACCI GOLDEN RATIO & OTE RETEST MATRIX */}
        <div className="p-3 rounded-2xl bg-gradient-to-br from-[#0c1527]/90 via-[#070e1c]/80 to-black/90 border border-cyan-500/40 shadow-[0_4px_20px_rgba(6,182,212,0.15)] flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              ZONA RETEST GOLDEN RATIO (FIBONACCI &amp; OTE)
            </span>
            {isInsideGoldenPocket ? (
              <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 text-[7px] font-black uppercase animate-pulse">
                ● HARGA DI GOLDEN POCKET
              </span>
            ) : (
              <span className="px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[7px] font-black uppercase">
                {Math.abs(Math.round((currentPrice - fib618) * 10))} PIPS KE 0.618
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {/* Level 1: 0.500 EQ */}
            <div className="p-2 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between gap-1 group hover:border-cyan-400/40 transition-colors">
              <div>
                <span className="text-[7px] text-gray-400 font-bold uppercase block">0.500 EQUILIBRIUM</span>
                <span className="text-xs font-black text-white font-mono">${fib500.toFixed(2)}</span>
              </div>
              <button
                onClick={() => handleCopySinglePrice("0.500", fib500)}
                className="w-full py-0.5 rounded bg-white/5 hover:bg-white/15 text-gray-300 text-[8px] font-bold transition-all cursor-pointer text-center"
              >
                {copiedLevel === "0.500" ? "Tersalin!" : "Salin"}
              </button>
            </div>

            {/* Level 2: 0.618 Golden Pocket (Featured) */}
            <div className="p-2 rounded-xl bg-amber-950/30 border-2 border-amber-400/60 shadow-[0_0_12px_rgba(245,158,11,0.2)] flex flex-col justify-between gap-1 relative overflow-hidden">
              <div className="absolute top-0 right-0 px-1 rounded-bl bg-amber-500 text-black text-[6px] font-black uppercase">
                UTAMA
              </div>
              <div>
                <span className="text-[7px] text-amber-300 font-bold uppercase block">0.618 GOLDEN POCKET</span>
                <span className="text-xs font-black text-amber-200 font-mono">${fib618.toFixed(2)}</span>
              </div>
              <div className="flex gap-1">
                {onApplyLimitOrder && (
                  <button
                    onClick={() => {
                      onApplyLimitOrder(fib618);
                      onClose();
                    }}
                    className="flex-1 py-0.5 rounded bg-amber-500 hover:bg-amber-400 text-black text-[8px] font-black transition-all cursor-pointer text-center active:scale-95"
                    title="Pasang Limit Order di 0.618"
                  >
                    Set 0.618
                  </button>
                )}
                <button
                  onClick={() => handleCopySinglePrice("0.618", fib618)}
                  className="px-1.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white text-[8px] font-bold transition-all cursor-pointer text-center"
                >
                  {copiedLevel === "0.618" ? "" : "Salin"}
                </button>
              </div>
            </div>

            {/* Level 3: 0.705 OTE Sniper */}
            <div className="p-2 rounded-xl bg-cyan-950/30 border border-cyan-400/50 flex flex-col justify-between gap-1 group hover:border-cyan-300 transition-colors">
              <div>
                <span className="text-[7px] text-cyan-300 font-bold uppercase block">0.705 OTE SNIPER</span>
                <span className="text-xs font-black text-cyan-200 font-mono">${fib705.toFixed(2)}</span>
              </div>
              <div className="flex gap-1">
                {onApplyLimitOrder && (
                  <button
                    onClick={() => {
                      onApplyLimitOrder(fib705);
                      onClose();
                    }}
                    className="flex-1 py-0.5 rounded bg-cyan-500/30 hover:bg-cyan-500/50 text-cyan-200 border border-cyan-500/40 text-[8px] font-black transition-all cursor-pointer text-center active:scale-95"
                    title="Pasang Limit Order di 0.705"
                  >
                    Set 0.705
                  </button>
                )}
                <button
                  onClick={() => handleCopySinglePrice("0.705", fib705)}
                  className="px-1.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white text-[8px] font-bold transition-all cursor-pointer text-center"
                >
                  {copiedLevel === "0.705" ? "" : "Salin"}
                </button>
              </div>
            </div>

            {/* Level 4: 0.786 Deep */}
            <div className="p-2 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between gap-1 group hover:border-cyan-400/40 transition-colors">
              <div>
                <span className="text-[7px] text-gray-400 font-bold uppercase block">0.786 DEEP RETEST</span>
                <span className="text-xs font-black text-white font-mono">${fib786.toFixed(2)}</span>
              </div>
              <button
                onClick={() => handleCopySinglePrice("0.786", fib786)}
                className="w-full py-0.5 rounded bg-white/5 hover:bg-white/15 text-gray-300 text-[8px] font-bold transition-all cursor-pointer text-center"
              >
                {copiedLevel === "0.786" ? "Tersalin!" : "Salin"}
              </button>
            </div>
          </div>
        </div>

        {/* Dual Tactical Choices: Opsi 1 (Market Now) vs Opsi 2 (Limit Retest) */}
        <div className="flex flex-col gap-1.5">
          <span className="text-[9px] font-black text-gray-300 uppercase tracking-wider flex items-center gap-1">
            <Layers className="w-3 h-3 text-cyan-400" />
            PILIHAN EKSEKUSI TRADER
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {/* Option 1: Instant Market Order */}
            <div className={`p-2.5 rounded-2xl border flex flex-col justify-between gap-1.5 transition-all ${
              isMomentum || isRetestActive
                ? "bg-emerald-950/20 border-emerald-500/40 shadow-sm"
                : "bg-white/[0.03] border-white/10 opacity-90"
            }`}>
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-[8px] font-bold text-gray-400 uppercase">OPSI 1: INSTAN</span>
                  {(isMomentum || isRetestActive) && (
                    <span className="px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[7px] font-black">
                      DISARANKAN
                    </span>
                  )}
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className={`text-xs font-black ${isOrderBuy ? "text-emerald-400" : "text-rose-400"}`}>
                    {advisory.traderTacticalChoice.instantMarketAction.actionLabel}
                  </span>
                  <span className="text-[10px] font-bold text-white">
                    @ ${currentPrice.toFixed(2)}
                  </span>
                </div>
                <p className="text-[9px] text-gray-300 leading-snug">
                  {advisory.traderTacticalChoice.instantMarketAction.pros}
                </p>
              </div>
            </div>

            {/* Option 2: Pending Limit Order */}
            <div className={`p-2.5 rounded-2xl border flex flex-col justify-between gap-1.5 transition-all ${
              isWaitRetest
                ? "bg-cyan-950/20 border-cyan-500/40 shadow-sm"
                : "bg-white/[0.03] border-white/10 opacity-90"
            }`}>
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-[8px] font-bold text-gray-400 uppercase">OPSI 2: PENDING LIMIT</span>
                  {isWaitRetest && (
                    <span className="px-1 py-0.2 rounded bg-cyan-500/20 text-cyan-300 text-[7px] font-black">
                      DISARANKAN
                    </span>
                  )}
                </div>
                <div className="flex items-baseline gap-1.5">
                  <span className={`text-xs font-black ${isOrderBuy ? "text-emerald-300" : "text-rose-300"}`}>
                    {isOrderBuy ? "BUY LIMIT (0.618)" : "SELL LIMIT (0.618)"}
                  </span>
                  <span className="text-[10px] font-bold text-white">
                    @ ${advisory.optimalRetestPrice.toFixed(2)}
                  </span>
                </div>
                <p className="text-[9px] text-gray-300 leading-snug">
                  {advisory.traderTacticalChoice.limitRetestAction.pros}
                </p>
              </div>

              {onApplyLimitOrder && (
                <button
                  onClick={() => {
                    onApplyLimitOrder(advisory.optimalRetestPrice);
                    onClose();
                  }}
                  className={`w-full mt-1 py-1 rounded-xl text-[9px] font-bold transition-all cursor-pointer flex items-center justify-center gap-1 active:scale-95 border ${
                    isOrderBuy
                      ? "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border-emerald-500/30"
                      : "bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border-rose-500/30"
                  }`}
                >
                  <span>Pakai {isOrderBuy ? "BUY LIMIT" : "SELL LIMIT"} ${advisory.optimalRetestPrice.toFixed(2)}</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* MULTI-TIMEFRAME ANTI-NOISE PIPELINE (D1 -> H4/H1 -> M15 -> M5 -> M1) */}
        <div className="p-3 rounded-2xl bg-gradient-to-br from-[#0a1626]/90 via-[#07111e]/90 to-black border border-cyan-500/40 shadow-md flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2">
            <span className="text-[10px] font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              HIERARKI MULTI-TIMEFRAME ANTI-NOISE (D1 → H4/H1 → M15 → M5 → M1)
            </span>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[8px] font-black uppercase">
              FILTER NOISE AKTIF
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-1.5 text-[9px] font-mono">
            {/* D1 */}
            <div className="p-2 rounded-xl bg-black/50 border border-white/10 flex flex-col gap-0.5">
              <span className="text-[8px] font-bold text-amber-400 uppercase">1. DAILY (D1)</span>
              <span className="text-white font-black">MACRO ANCHOR</span>
              <span className="text-[7.5px] text-gray-400 leading-tight">Penentu arah tren utama, menyaring noise dan false trend.</span>
            </div>

            {/* H4 - H1 */}
            <div className="p-2 rounded-xl bg-black/50 border border-white/10 flex flex-col gap-0.5">
              <span className="text-[8px] font-bold text-blue-400 uppercase">2. H4 - H1</span>
              <span className="text-white font-black">STRUKTUR UTAMA</span>
              <span className="text-[7.5px] text-gray-400 leading-tight">Identifikasi zona supply/demand & swing OTE institusional.</span>
            </div>

            {/* M15 */}
            <div className="p-2 rounded-xl bg-black/50 border border-cyan-500/30 flex flex-col gap-0.5 bg-cyan-950/20">
              <span className="text-[8px] font-bold text-cyan-300 uppercase">3. M15 (KEPASTIAN)</span>
              <span className="text-cyan-200 font-black">MSS & DISPLACEMENT</span>
              <span className="text-[7.5px] text-gray-300 leading-tight">Konfirmasi penembusan struktur via candle body close.</span>
            </div>

            {/* M5 */}
            <div className="p-2 rounded-xl bg-black/50 border border-emerald-500/30 flex flex-col gap-0.5 bg-emerald-950/20">
              <span className="text-[8px] font-bold text-emerald-300 uppercase">4. M5 (EVALUASI)</span>
              <span className="text-emerald-200 font-black">ZONA REAKSI</span>
              <span className="text-[7.5px] text-gray-300 leading-tight">Evaluasi wick rejection & penyerapan volume di area 0.618.</span>
            </div>

            {/* M1 */}
            <div className="p-2 rounded-xl bg-black/50 border border-purple-500/30 flex flex-col gap-0.5 bg-purple-950/20">
              <span className="text-[8px] font-bold text-purple-300 uppercase">5. M1 (ENTRY)</span>
              <span className="text-purple-200 font-black">SNIPER TRIGGER</span>
              <span className="text-[7.5px] text-gray-300 leading-tight">Eksekusi presisi harga live dengan drawdown minimal.</span>
            </div>
          </div>
        </div>

        {/* ANTI-SL HUNTER CUSHION PROTOCOL */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-rose-950/30 via-slate-900/80 to-slate-950/80 border border-rose-500/40 shadow-md flex flex-col gap-2">
          <div className="flex items-center justify-between border-b border-rose-500/20 pb-1.5">
            <span className="text-[10px] font-black text-rose-300 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
              ANTI-SL HUNTER PROTOCOL (PROTEKSI DARI MANIPULASI BROKER)
            </span>
            <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[8px] font-black uppercase">
              CUSHION SHIELD AKTIF
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[9px] font-mono">
            <div className="p-2 rounded-xl bg-black/40 border border-white/10 flex flex-col gap-1">
              <span className="text-[8.5px] font-black text-rose-200 uppercase">Penempatan SL di Luar Stop Hunt:</span>
              <p className="text-[8.5px] text-gray-300 leading-snug">
                Stop Loss tidak diletakkan tepat di ujung swing/wick ritel yang rentan disapu. SL diletakkan di luar Order Block institusional ditambah buffer volatilitas dinamis ATR (1.35x - 1.5x) untuk menahan pelebaran spread.
              </p>
            </div>
            <div className="p-2 rounded-xl bg-black/40 border border-white/10 flex flex-col gap-1">
              <span className="text-[8.5px] font-black text-emerald-200 uppercase">Validasi Penutupan Candle Close:</span>
              <p className="text-[8.5px] text-gray-300 leading-snug">
                Invalidasi posisi hanya terpicu jika candle M15/H1 ditutup (body close) menembus level proteksi, sehingga posisi tetap aman dari manipulasi spike/Judas swing sesaat.
              </p>
            </div>
          </div>
        </div>

        {/* 3-Step Confirmation Checklist */}
        <div className="p-2.5 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col gap-1.5">
          <span className="text-[8px] font-black text-gray-400 uppercase tracking-wider flex items-center gap-1">
            <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
            CHECKLIST RETEST SNIPER (3 LANGKAH)
          </span>

          <div className="flex flex-col gap-1">
            {advisory.retestConfirmationChecklist.map((chk, idx) => (
              <div key={`retest_adv_chk_${idx}`} className="flex items-start gap-1.5 text-[9px] p-1 rounded-xl bg-white/[0.02]">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 mt-0.5 shrink-0" />
                <div className="flex flex-col">
                  <span className="font-bold text-white leading-tight">{idx + 1}. {chk.checkName}</span>
                  <span className="text-[8px] text-gray-400 leading-tight">{chk.instruction}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="flex items-center justify-between gap-2 border-t border-white/10 pt-2.5">
          <button
            onClick={handleCopySetup}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 text-[10px] font-bold transition-all cursor-pointer shadow-sm active:scale-95"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
            <span>{copied ? "Tersalin!" : "Salin Setup"}</span>
          </button>

          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 border border-white/20 text-[10px] font-bold transition-all cursor-pointer active:scale-95"
          >
            Tutup
          </button>
        </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
