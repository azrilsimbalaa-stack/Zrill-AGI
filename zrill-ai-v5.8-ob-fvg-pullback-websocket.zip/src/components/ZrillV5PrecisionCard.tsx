import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ZrillV5CoreAnalysis,
  ZrillV5ConfluencePillar,
} from "../services/precisionSignalEngine";
import {
  ShieldCheck,
  Zap,
  TrendingUp,
  TrendingDown,
  Activity,
  Target,
  Layers,
  Copy,
  Check,
  AlertTriangle,
  Clock,
  Flame,
  Award,
  Radio,
  Sliders,
  Sparkles,
  CheckCircle2,
  BarChart2,
  Compass,
} from "lucide-react";

interface ZrillV5PrecisionCardProps {
  zrillCore?: ZrillV5CoreAnalysis;
  symbol: string;
  isBuy: boolean;
  currentPrice: number;
  timeframe: string;
  copyToClipboard?: (text: string) => Promise<boolean>;
}

// Ultra-safe numeric formatting helper preventing any .toFixed runtime errors
const safeNum = (val: any, fallback = 0): number => {
  if (typeof val === "number" && !isNaN(val)) return val;
  if (typeof val === "object" && val !== null) {
    if (typeof val.adx === "number" && !isNaN(val.adx)) return val.adx;
    if (typeof val.value === "number" && !isNaN(val.value)) return val.value;
  }
  const parsed = Number(val);
  return !isNaN(parsed) ? parsed : fallback;
};

export const ZrillV5PrecisionCard: React.FC<ZrillV5PrecisionCardProps> = ({
  zrillCore,
  symbol,
  isBuy,
  currentPrice,
  timeframe,
  copyToClipboard,
}) => {
  const [copied, setCopied] = useState(false);
  const [showPillarDetails, setShowPillarDetails] = useState(true);

  if (!zrillCore) return null;

  const {
    confluenceScore,
    confluenceRating,
    ratingBadgeColor,
    ratingLabel,
    winRateEstimatePct,
    signalType,
    trendDirection,
    trendLabel,
    newsLabel,
    fibonacci,
    emaFilter,
    marketStructure,
    momentum,
    volatilityRisk,
    usdNewsFilter,
    multiTimeframe,
    pillars,
    formattedOutputSignalText,
    reasonSummary,
  } = zrillCore;

  const handleCopy = async () => {
    const text = formattedOutputSignalText;
    if (copyToClipboard) {
      const ok = await copyToClipboard(text);
      if (ok) {
        setCopied(true);
        setTimeout(() => setCopied(false), 2200);
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2200);
      } catch (e) {}
    }
  };

  const isSuperStrong = confluenceScore >= 9;
  const isStrong = confluenceScore >= 7 && confluenceScore < 9;
  const isWaiting = confluenceScore < 7 || signalType === "WAITING";

  return (
    <motion.div
      id="zrill-v5-precision-card"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="bg-slate-900/95 border border-amber-500/30 rounded-xl p-5 shadow-2xl backdrop-blur-md text-slate-100 relative overflow-hidden my-4"
    >
      {/* Background Subtle Glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/40 text-amber-400 shadow-inner">
            <Zap className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 uppercase tracking-wide">
                ZRILL AGI v5.0
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                 HIGH WINRATE CORE (≥70% - 85%+)
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold text-white tracking-tight mt-1 flex items-center gap-1.5">
              Precision Trading System
              <span className="text-xs font-normal text-slate-400">({symbol} • {timeframe})</span>
            </h3>
          </div>
        </div>

        {/* Win Rate & Confluence Badge */}
        <div className="flex items-center gap-2">
          <div className="text-right">
            <div className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
              Win Rate Est.
            </div>
            <div className="text-lg font-black text-emerald-400">
              ~{winRateEstimatePct}%
            </div>
          </div>
          <div
            className={`px-3 py-1.5 rounded-lg border font-bold text-xs flex items-center gap-1.5 shadow-sm ${
              ratingBadgeColor === "emerald"
                ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300"
                : ratingBadgeColor === "amber"
                ? "bg-amber-500/20 border-amber-500/40 text-amber-300"
                : "bg-rose-500/20 border-rose-500/40 text-rose-300"
            }`}
          >
            <Award className="w-4 h-4" />
            <span>{ratingLabel}</span>
          </div>
        </div>
      </div>

      {/* Signal Verdict Banner */}
      <div
        className={`p-3.5 rounded-xl border mb-5 flex flex-wrap items-center justify-between gap-3 relative z-10 ${
          signalType === "BUY" || signalType === "BUY"
            ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-100"
            : signalType === "SELL" || signalType === "SELL"
            ? "bg-rose-950/40 border-rose-500/50 text-rose-100"
            : signalType === "BUY LIMIT"
            ? "bg-cyan-950/40 border-cyan-500/50 text-cyan-100"
            : signalType === "SELL LIMIT"
            ? "bg-amber-950/40 border-amber-500/50 text-amber-100"
            : "bg-slate-800/60 border-slate-700 text-slate-300"
        }`}
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-black/30 border border-white/10 font-black text-sm">
            {(signalType === "BUY" || signalType === "BUY") && <TrendingUp className="w-5 h-5 text-emerald-400" />}
            {(signalType === "SELL" || signalType === "SELL") && <TrendingDown className="w-5 h-5 text-rose-400" />}
            {signalType === "BUY LIMIT" && <Target className="w-5 h-5 text-cyan-400" />}
            {signalType === "SELL LIMIT" && <Target className="w-5 h-5 text-amber-400" />}
            {signalType === "WAITING" && <Clock className="w-5 h-5 text-slate-400" />}
          </div>
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider opacity-75">
              Rekomendasi Eksekusi Zrill AGI:
            </div>
            <div className="text-base font-extrabold flex items-center gap-2">
              <span>{signalType === "BUY" ? "BUY" : signalType === "SELL" ? "SELL" : signalType}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-black/40 border border-white/10 font-medium">
                {trendLabel}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-black/40 border border-white/10 font-medium">
                USD: {newsLabel}
              </span>
              {zrillCore?.candleVolLabel && (
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold flex items-center gap-1 border ${
                  zrillCore.candleVolSignal === "VOLUME_CONTINUATION"
                    ? "bg-emerald-500/25 text-emerald-300 border-emerald-400/40 animate-pulse"
                    : zrillCore.candleVolSignal === "VOLUME_REVERSAL"
                    ? "bg-purple-500/25 text-purple-200 border-purple-400/40 animate-pulse"
                    : "bg-slate-700/50 text-slate-300 border-slate-600/40"
                }`}>
                  {zrillCore.candleVolLabel}
                </span>
              )}
            </div>
          </div>
        </div>

        <button
          id="copy-zrill-v5-signal-btn"
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold transition-all active:scale-95"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-300">Tersalin!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Salin Sinyal</span>
            </>
          )}
        </button>
      </div>

      {/* Institutional Candle Confirmation Intelligence */}
      {zrillCore.candleConfirmation && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className={`p-3.5 rounded-xl border mb-5 relative overflow-hidden transition-all shadow-md ${
            zrillCore.candleConfirmation.isConfirmed
              ? "bg-gradient-to-r from-emerald-950/50 via-slate-900/90 to-teal-950/40 border-emerald-500/50 text-emerald-100 shadow-[0_0_20px_rgba(16,185,129,0.12)]"
              : "bg-gradient-to-r from-amber-950/30 via-slate-900/90 to-slate-900/90 border-amber-500/40 text-amber-100"
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-lg border shrink-0 ${
                  zrillCore.candleConfirmation.isConfirmed
                    ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400 animate-pulse"
                    : "bg-amber-500/20 border-amber-500/40 text-amber-400"
                }`}
              >
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-300">
                    KONFIRMASI LILIN INSTITUSIONAL
                  </span>
                  <span
                    className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
                      zrillCore.candleConfirmation.isConfirmed
                        ? "bg-emerald-500/20 text-emerald-300 border-emerald-400/50"
                        : "bg-amber-500/20 text-amber-300 border-amber-400/50"
                    }`}
                  >
                    {zrillCore.candleConfirmation.badgeLabel}
                  </span>
                  {zrillCore.candleConfirmation.isConfirmed && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/50">
                      +{zrillCore.candleConfirmation.accuracyBoostPct}% Akurasi
                    </span>
                  )}
                </div>
                <div className="text-sm font-black text-white mt-1 flex items-center gap-2">
                  <span>Pola Lilin: {zrillCore.candleConfirmation.patternName}</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded bg-black/40 border border-white/10 text-slate-300">
                    Skor: {zrillCore.candleConfirmation.candleScore}/100
                  </span>
                </div>
              </div>
            </div>

            {/* Metrics Chips */}
            <div className="flex items-center gap-2 text-xs">
              <div className="p-2 rounded-lg bg-black/40 border border-white/10 text-center">
                <div className="text-[9px] text-slate-400 uppercase">Rejection Wick</div>
                <div className="font-bold text-white">
                  {(zrillCore.candleConfirmation.rejectionWickRatio * 100).toFixed(0)}%
                </div>
              </div>
              <div className="p-2 rounded-lg bg-black/40 border border-white/10 text-center">
                <div className="text-[9px] text-slate-400 uppercase">Volume Delta</div>
                <div className={`font-bold ${zrillCore.candleConfirmation.isVolumeConfirmed ? "text-emerald-400" : "text-slate-300"}`}>
                  {zrillCore.candleConfirmation.isVolumeConfirmed ? "Tervalidasi" : "Normal"}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-2.5 pt-2.5 border-t border-white/10 text-[11px] text-slate-300 leading-relaxed flex items-center gap-2">
            <CheckCircle2 className={`w-4 h-4 shrink-0 ${zrillCore.candleConfirmation.isConfirmed ? "text-emerald-400" : "text-amber-400"}`} />
            <span>{zrillCore.candleConfirmation.confirmationDetail}</span>
          </div>
        </motion.div>
      )}

      {/* Trading Parameter Cockpit: Ditentukan Sepenuhnya oleh ZRILL AGI */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-amber-500/40 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
        {signalType.includes("NO ENTRY") || zrillCore.entryPrice === 0 ? (
          <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/50 text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-400 animate-pulse" />
              <span className="text-base font-black text-amber-300 uppercase tracking-wide">
                {signalType}
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-xl mx-auto leading-relaxed">
              {signalType.includes("HIGH-RISK")
                ? "Kondisi pasar saat ini memiliki risiko volatilitas berita sangat tinggi (High-Impact Event). Engine menahan eksekusi posisi dan tidak merilis angka Entry, SL, atau TP untuk melindungi ekuitas modal."
                : "Pasar sedang berada dalam fase konsolidasi / Sideways tanpa struktur pergerakan yang jelas. Sesuai aturan presisi Zrill AGI, angka Entry, SL, dan TP tidak ditampilkan (NO ENTRY) hingga konfluensi institusional terpenuhi 100%."}
            </p>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2.5 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-black uppercase text-amber-300 tracking-wider">
                  LEVEL EKSEKUSI PRESISI ZRILL AGI
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold">
                  R:R {zrillCore.volatilityRisk?.riskRewardRatio || "1:2.0"}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
                  Lot Rec: {safeNum(zrillCore.recommendedLot, 0.1).toFixed(2)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Entry */}
              <div className="p-3 rounded-xl bg-slate-900/90 border border-amber-500/30">
                <div className="text-[10px] uppercase font-bold text-amber-400">ENTRY LEVEL</div>
                <div className="text-base sm:text-lg font-black text-white font-mono mt-0.5">
                  ${safeNum(zrillCore.entryPrice || currentPrice).toFixed(2)}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">{zrillCore.signalType}</div>
              </div>

              {/* Stop Loss */}
              <div className="p-3 rounded-xl bg-slate-900/90 border border-rose-500/30">
                <div className="text-[10px] uppercase font-bold text-rose-400">STOP LOSS</div>
                <div className="text-base sm:text-lg font-black text-rose-300 font-mono mt-0.5">
                  ${safeNum(zrillCore.slPrice).toFixed(2)}
                </div>
                <div className="text-[9px] text-rose-400/80 mt-0.5">
                  {safeNum(zrillCore.slPipsDistance, 25)} pips risiko
                </div>
              </div>

              {/* Take Profit Mutlak */}
              <div className="p-3 rounded-xl bg-slate-900/90 border border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.15)]">
                <div className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1.5">
                  <span>TAKE PROFIT MUTLAK</span>
                  <span className="text-[8px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold uppercase">
                    R:R 1:{(zrillCore?.confluenceScore || 7) >= 8 ? "3" : "2"}
                  </span>
                </div>
                <div className="text-base sm:text-lg font-black text-emerald-300 font-mono mt-0.5">
                  ${safeNum(zrillCore.tpPrice || zrillCore.tp1Price).toFixed(2)}
                </div>
                <div className="text-[9px] text-emerald-400/90 mt-0.5 font-semibold">
                  {(zrillCore?.confluenceScore || 7) >= 8 ? "Ekspansi Maksimum (Sifat Tren)" : "Target Aman Presisi"}
                </div>
              </div>
            </div>

            {/* SNR Key Level & Institutional Supply/Demand Reaction Zone */}
            <div className="mt-3 pt-3 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {/* Key Support/Resistance */}
              <div className="p-2.5 rounded-lg bg-slate-900/90 border border-cyan-500/30 flex items-start justify-between gap-2">
                <div>
                  <div className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span>SNR KEY LEVEL (ACUAN VALID)</span>
                  </div>
                  <div className="text-sm font-black text-white font-mono mt-1">
                    ${safeNum(zrillCore.snrKeyLevel?.levelPrice || zrillCore.entryPrice).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-300 mt-0.5 font-medium">
                    {zrillCore.snrKeyLevel?.levelName || (isBuy ? "Key Support (RBS Floor)" : "Key Resistance (SBR Ceiling)")}
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-[9px] font-bold border border-cyan-500/40 shrink-0">
                  {zrillCore.snrKeyLevel?.strength || "TERUJI 2-3x"}
                </span>
              </div>

              {/* Supply & Demand Zone */}
              <div className="p-2.5 rounded-lg bg-slate-900/90 border border-emerald-500/30 flex items-start justify-between gap-2">
                <div>
                  <div className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{isBuy ? "INSTITUTIONAL DEMAND ZONE" : "INSTITUTIONAL SUPPLY ZONE"}</span>
                  </div>
                  <div className="text-sm font-black text-emerald-300 font-mono mt-1">
                    ${safeNum(zrillCore.supplyDemandZone?.bottom || zrillCore.slPrice).toFixed(2)} — ${safeNum(zrillCore.supplyDemandZone?.top || zrillCore.entryPrice).toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-300 mt-0.5 font-medium">
                    {zrillCore.supplyDemandZone?.zoneName || (isBuy ? "Zona Beli Institusi (Demand)" : "Zona Jual Institusi (Supply)")}
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/40 shrink-0">
                  {zrillCore.supplyDemandZone?.isFresh ? "FRESH AREA" : "RETESTED ZONE"}
                </span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ANTI-NOISE PROTOCOL AUDIT PANEL */}
      {zrillCore.antiNoiseAudit && (
        <div className="bg-gradient-to-r from-slate-950 to-slate-900 border border-teal-500/30 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-400" />
              <span className="text-xs font-extrabold uppercase text-teal-300 tracking-wider">
                ANTI-NOISE PROTOCOL AUDIT (FILTER VOLATILITAS)
              </span>
            </div>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
              zrillCore.antiNoiseAudit.passed
                ? "bg-teal-500/20 text-teal-300 border-teal-400/40"
                : "bg-amber-500/20 text-amber-300 border-amber-400/40"
            }`}>
              {zrillCore.antiNoiseAudit.passed ? "AUDIT: BERSIH / PASSED" : "AUDIT: WARNING / NOISE"}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mb-3">
            {/* Noise Unit */}
            <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-medium">Noise Unit (LTF Average)</div>
              <div className="font-extrabold text-white mt-0.5 font-mono">
                {zrillCore.antiNoiseAudit.calculatedNoiseUnit.toFixed(4)}
              </div>
            </div>

            {/* Sweep Type */}
            <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-medium">Karakter Sweep</div>
              <div className={`font-extrabold mt-0.5 ${
                zrillCore.antiNoiseAudit.sweepType === "Single Candle Spike" ? "text-emerald-400" : "text-amber-400"
              }`}>
                {zrillCore.antiNoiseAudit.sweepType}
              </div>
            </div>

            {/* Volume Confirmation */}
            <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-medium">Validasi Volume</div>
              <div className={`font-extrabold mt-0.5 ${
                zrillCore.antiNoiseAudit.volumeStatus.includes("High") ? "text-emerald-400" : "text-amber-400"
              }`}>
                {zrillCore.antiNoiseAudit.volumeStatus.includes("High") ? "Tervalidasi (Tinggi)" : "Rendah / Noise"}
              </div>
            </div>

            {/* Session Context */}
            <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-medium">Sesi Transaksi</div>
              <div className={`font-extrabold mt-0.5 ${
                zrillCore.antiNoiseAudit.sessionContext === "Liquid Session" ? "text-emerald-400" : "text-rose-400"
              }`}>
                {zrillCore.antiNoiseAudit.sessionContext === "Liquid Session" ? "Sesi Aktif (Likuid)" : "Pasar Sepi (Dead Zone)"}
              </div>
            </div>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/90 border border-slate-800 text-[11px] leading-relaxed flex items-start gap-2">
            <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${
              zrillCore.antiNoiseAudit.isSafeFromNoiseStopOut ? "text-teal-400" : "text-amber-400"
            }`} />
            <div>
              <span className="font-bold text-white block">Audit Getaran Pasar (Market Noise):</span>
              <p className="text-slate-300 mt-0.5">{zrillCore.antiNoiseAudit.explanation}</p>
            </div>
          </div>
        </div>
      )}

      {/* MULTI-TIMEFRAME ANTI-NOISE EXECUTION PIPELINE (DAILY -> H4/H1 -> M15 -> M5 -> M1) */}
      <div className="bg-gradient-to-br from-[#091524]/90 via-slate-950 to-[#07101c]/95 border border-cyan-500/40 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-black uppercase text-cyan-300 tracking-wider">
              HIERARKI MULTI-TIMEFRAME ANTI-NOISE (D1 → H4/H1 → M15 → M5 → M1)
            </span>
          </div>
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-400/40">
            FILTER NOISE AKTIF
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-xs mb-3">
          {/* DAILY */}
          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 flex flex-col">
            <span className="text-[9px] text-amber-400 font-bold uppercase">1. DAILY (D1)</span>
            <span className="font-black text-white text-[11px] mt-0.5">MACRO ANCHOR</span>
            <span className="text-[9px] text-slate-400 mt-1 leading-snug">Menentukan arah tren utama & bias institusi untuk menyaring noise.</span>
          </div>

          {/* H4 - H1 */}
          <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 flex flex-col">
            <span className="text-[9px] text-blue-400 font-bold uppercase">2. H4 - H1</span>
            <span className="font-black text-white text-[11px] mt-0.5">STRUKTUR UTAMA</span>
            <span className="text-[9px] text-slate-400 mt-1 leading-snug">Memetakan zona Supply/Demand & Order Block institusional.</span>
          </div>

          {/* M15 */}
          <div className="p-2.5 rounded-lg bg-cyan-950/30 border border-cyan-500/40 flex flex-col">
            <span className="text-[9px] text-cyan-300 font-bold uppercase">3. M15 (KEPASTIAN)</span>
            <span className="font-black text-cyan-200 text-[11px] mt-0.5">MSS & DISPLACEMENT</span>
            <span className="text-[9px] text-slate-300 mt-1 leading-snug">Validasi candle close dan dorongan volume institusional.</span>
          </div>

          {/* M5 */}
          <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/40 flex flex-col">
            <span className="text-[9px] text-emerald-300 font-bold uppercase">4. M5 (EVALUASI)</span>
            <span className="font-black text-emerald-200 text-[11px] mt-0.5">ZONA REAKSI</span>
            <span className="text-[9px] text-slate-300 mt-1 leading-snug">Evaluasi wick rejection & penyerapan likuiditas di area 0.618.</span>
          </div>

          {/* M1 */}
          <div className="p-2.5 rounded-lg bg-purple-950/30 border border-purple-500/40 flex flex-col">
            <span className="text-[9px] text-purple-300 font-bold uppercase">5. M1 (ENTRY)</span>
            <span className="font-black text-purple-200 text-[11px] mt-0.5">SNIPER TRIGGER</span>
            <span className="text-[9px] text-slate-300 mt-1 leading-snug">Eksekusi presisi harga live untuk meminimalisir floating.</span>
          </div>
        </div>
      </div>

      {/* ANTI-SL HUNTER PROTOCOL & CUSHION SHIELD */}
      <div className="bg-gradient-to-r from-rose-950/40 via-slate-950 to-slate-900 border border-rose-500/40 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-rose-400" />
            <span className="text-xs font-black uppercase text-rose-300 tracking-wider">
              ANTI-SL HUNTER PROTOCOL (PROTEKSI MANIPULASI BROKER)
            </span>
          </div>
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-400/40">
            CUSHION SHIELD AKTIF
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 flex flex-col gap-1">
            <span className="text-[10px] font-black text-rose-200 uppercase">Posisi Stop Loss Terproteksi:</span>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              {zrillCore.slHunterProtection?.slPlacementNote || "Stop Loss diletakkan di luar Institutional Order Block + buffer volatilitas dinamis ATR (1.35x - 1.5x) untuk mengantisipasi spike pelebaran spread broker saat likuiditas tinggi."}
            </p>
          </div>
          <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 flex flex-col gap-1">
            <span className="text-[10px] font-black text-emerald-200 uppercase">Filter Pembatalan Candle Close:</span>
            <p className="text-[10px] text-slate-300 leading-relaxed">
              Posisi tidak dibatalkan oleh shadow spike sesaat (Judas Swing). Invalidasi hanya terkonfirmasi jika body candle M15/H1 ditutup penuh menembus struktur.
            </p>
          </div>
        </div>
      </div>

      {/* LONDON & NEW YORK KILLZONE ZERO-FLOATING STRATEGY & AREA PANEL */}
      {zrillCore.londonNyKillzoneStrategy && (
        <div className="bg-gradient-to-br from-amber-950/30 via-slate-950 to-orange-950/30 border border-amber-500/40 rounded-xl p-4 mb-5 relative z-10 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-amber-500/30">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-black uppercase text-amber-300 tracking-wider">
                SESI LONDON & NEW YORK KILLZONE — APLIKASI ZERO FLOATING
              </span>
            </div>
            <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/50">
              {zrillCore.londonNyKillzoneStrategy.killzoneBadge}
            </span>
          </div>

          <div className="mb-3">
            <div className="text-xs font-bold text-white mb-1">
              {zrillCore.londonNyKillzoneStrategy.strategyTitle}
            </div>
            <div className="p-3 rounded-lg bg-slate-900/90 border border-amber-500/30 text-xs text-amber-100/90 leading-relaxed font-medium">
              {zrillCore.londonNyKillzoneStrategy.zeroFloatingRule}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mb-3 text-xs">
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-semibold">Rentang Area Zero-Floating</div>
              <div className="text-sm font-black text-amber-300 font-mono mt-0.5">
                ${zrillCore.londonNyKillzoneStrategy.zeroFloatingAreaMin.toFixed(2)} - ${zrillCore.londonNyKillzoneStrategy.zeroFloatingAreaMax.toFixed(2)}
              </div>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-semibold">Sweet Spot OTE 0.618</div>
              <div className="text-sm font-black text-emerald-400 font-mono mt-0.5">
                ${zrillCore.londonNyKillzoneStrategy.sweetSpotPrice.toFixed(2)}
              </div>
            </div>
            <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <div className="text-[9px] text-slate-400 uppercase font-semibold">Target Drawdown</div>
              <div className="text-sm font-black text-cyan-300 mt-0.5">
                Minimal / Zero Floating
              </div>
            </div>
          </div>

          {/* Locked Strategy Rules List */}
          <div className="mt-3 pt-2.5 border-t border-slate-800">
            <div className="text-[10px] font-black uppercase text-slate-400 tracking-wider mb-2">
              ATURAN STRATEGI INSTITUSIONAL TERKUNCI (TIDAK BOLEH DIUBAH):
            </div>
            <div className="space-y-1.5">
              {zrillCore.londonNyKillzoneStrategy.lockedStrategyRules.map((rule) => (
                <div key={rule.ruleNumber} className="flex items-start gap-2 p-2 rounded bg-slate-900/60 border border-slate-800/80 text-[11px]">
                  <span className="font-extrabold text-amber-400 shrink-0">Rule #{rule.ruleNumber}:</span>
                  <div className="flex-1">
                    <span className="font-bold text-white">{rule.ruleName}</span>
                    <span className="text-slate-300 ml-1.5">— {rule.description}</span>
                  </div>
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                    {rule.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 10/10 Confluence Scorecard Meter */}
      <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 mb-5 relative z-10">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">
              Sistem Skor Konfluensi (Syarat Minimum: 7/10)
            </span>
          </div>
          <div className="text-sm font-black text-amber-400">
            {confluenceScore} <span className="text-xs font-normal text-slate-400">/ 10 Pilar Terpenuhi</span>
          </div>
        </div>

        {/* Visual Progress Bar */}
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-2 relative">
          {/* Minimum 7/10 Marker Indicator */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10"
            style={{ left: "70%" }}
            title="Ambang Batas Minimum (7/10)"
          />
          <div
            className={`h-full transition-all duration-700 rounded-full ${
              confluenceScore >= 9
                ? "bg-gradient-to-r from-emerald-500 to-teal-400"
                : confluenceScore >= 7
                ? "bg-gradient-to-r from-amber-500 to-emerald-500"
                : "bg-gradient-to-r from-rose-500 to-amber-500"
            }`}
            style={{ width: `${(confluenceScore / 10) * 100}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-400">
          <span>0 (Ditolak)</span>
          <span className="text-amber-400 font-semibold">Min. 7/10 (Sinyal Keluar)</span>
          <span className="text-emerald-400 font-semibold">≥9/10 (Super Kuat)</span>
        </div>

        {/* Toggle Pillars Detail */}
        <div className="mt-3 flex justify-end">
          <button
            onClick={() => setShowPillarDetails(!showPillarDetails)}
            className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 transition-colors"
          >
            <Sliders className="w-3 h-3" />
            <span>{showPillarDetails ? "Sembunyikan Rincian Pilar" : "Tampilkan 10 Rincian Pilar"}</span>
          </button>
        </div>

        {/* Detailed 10 Pillars Grid */}
        {showPillarDetails && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800/80">
            {Array.isArray(pillars) && pillars.map((pillar, pIdx) => {
              if (!pillar) return null;
              const pillarKey = pillar.id ?? pIdx;
              return (
                <div
                  key={pillarKey}
                  className={`p-2.5 rounded-lg border text-xs flex items-start gap-2.5 transition-all ${
                    pillar.passed
                      ? "bg-emerald-950/20 border-emerald-500/30 text-slate-200"
                      : "bg-slate-900/40 border-slate-800 text-slate-400"
                  }`}
                >
                  <div
                    className={`p-1 rounded font-bold text-[10px] shrink-0 mt-0.5 ${
                      pillar.passed
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                        : "bg-slate-800 text-slate-500 border border-slate-700"
                    }`}
                  >
                    {pillar.passed ? <Check className="w-3 h-3" /> : <span className="px-0.5"></span>}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className={`font-bold ${pillar.passed ? "text-emerald-300" : "text-slate-300"}`}>
                        #{pillar.id ?? pIdx + 1}. {pillar.title}
                      </span>
                      <span className="text-[9px] font-medium px-1.5 py-0.2 rounded bg-white/5 text-amber-400 shrink-0">
                        {pillar.weightBonus}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                      {pillar.valueDescription}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 4 Core Pillars Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5 relative z-10">
        {/* Card 1: Fibonacci Golden Ratio */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>1. FIBONACCI GOLDEN RATIO (90%+)</span>
            </div>
            {fibonacci.isUntouchedArea && (
              <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                 UNTOUCHED (WIN RATE 2×)
              </span>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">2.618 Sniper Ekstensi</span>
              <span className="font-bold text-amber-300">${fibonacci.zone2618_Sniper}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">0.618 Retest Utama</span>
              <span className="font-bold text-emerald-300">${fibonacci.zone0618_Retest}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">0.786 Retest Dalam</span>
              <span className="font-bold text-slate-200">${fibonacci.zone0786_Deep}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 block text-[9px]">1.618 TP Ekstensi</span>
              <span className="font-bold text-cyan-300">${fibonacci.zone1618_Extension}</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>{fibonacci.statusDescription}</span>
          </div>
        </div>

        {/* Card 2: EMA 50 + EMA 200 Filter */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-blue-400">
              <Activity className="w-3.5 h-3.5" />
              <span>2. EMA 50 (Biru) & EMA 200 (Merah)</span>
            </div>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40">
              +35% Win Rate Filter
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-blue-900/40">
              <span className="text-blue-300 block text-[9px] flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500" /> EMA 50 (Biru)
              </span>
              <span className="font-bold text-blue-200">${safeNum(emaFilter.ema50).toFixed(2)}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-rose-900/40">
              <span className="text-rose-300 block text-[9px] flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-500" /> EMA 200 (Merah)
              </span>
              <span className="font-bold text-rose-200">${safeNum(emaFilter.ema200).toFixed(2)}</span>
            </div>
          </div>
          <div className="text-[10px] text-slate-300 mt-2 flex items-center justify-between">
            <span className="font-medium">
              Status Tren:{" "}
              <strong className={emaFilter.trendState === "UPTREND_KUAT" ? "text-emerald-400" : emaFilter.trendState === "DOWNTREND_KUAT" ? "text-rose-400" : "text-amber-400"}>
                {emaFilter.trendState}
              </strong>
            </span>
            <span className="text-[9px] text-slate-400">
              {emaFilter.crossStatus !== "NEUTRAL" ? emaFilter.crossStatus : "Trend Aligned"}
            </span>
          </div>
        </div>

        {/* Card 3: Momentum (RSI + MACD + ADX) */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
              <Flame className="w-3.5 h-3.5" />
              <span>3. MOMENTUM (RSI + MACD + ADX)</span>
            </div>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              Konfirmasi Presisi
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 text-[11px] mt-1">
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">ADX(14)</span>
              <span className="font-bold text-amber-300">{safeNum(momentum.adxValue, 25).toFixed(1)}</span>
              <span className="text-[8px] block text-slate-400">{momentum.adxRegime}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">RSI(14)</span>
              <span className="font-bold text-emerald-300">{safeNum(momentum.rsi14, 50).toFixed(1)}</span>
              <span className="text-[8px] block text-slate-400">{momentum.rsiStatus}</span>
            </div>
            <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-slate-400 block text-[9px]">MACD Hist</span>
              <span className={`font-bold ${safeNum(momentum.macdHistogram) >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                {safeNum(momentum.macdHistogram) >= 0 ? "+" : ""}{safeNum(momentum.macdHistogram).toFixed(2)}
              </span>
              <span className="text-[8px] block text-slate-400">
                {momentum.macdDirectionAligned ? "Mendukung" : "Konflik"}
              </span>
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2">
            Panduan ADX: <strong className="text-slate-200">{momentum.adxActionGuidance}</strong>
          </div>
        </div>

        {/* Card 4: Forex Factory USD News Filter */}
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
              <Radio className="w-3.5 h-3.5" />
              <span>4. FILTER NEWS USD (FOREX FACTORY)</span>
            </div>
            <span
              className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                usdNewsFilter.newsStatusBadge === "Aman"
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40"
                  : usdNewsFilter.newsStatusBadge === "Menunggu"
                  ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                  : "bg-rose-500/20 text-rose-300 border-rose-500/40"
              }`}
            >
              {usdNewsFilter.newsStatusBadge === "Aman" ? " Aman" : usdNewsFilter.newsStatusBadge === "Menunggu" ? " Menunggu" : " Hindari"}
            </span>
          </div>
          <div className="p-2 rounded bg-slate-900/80 border border-slate-800 text-[11px]">
            <div className="flex justify-between items-center mb-1">
              <span className="text-slate-400 text-[10px]">Rilis Terdekat:</span>
              <span className="font-semibold text-slate-200">{usdNewsFilter.nearestUsdEventTitle}</span>
            </div>
            <div className="text-[10px] text-slate-400 leading-tight">
              {usdNewsFilter.actionRule}
            </div>
          </div>
          <div className="text-[10px] text-slate-400 mt-2 flex justify-between items-center">
            <span>Filter USD Khusus: Non-USD diabaikan</span>
            <span className="text-amber-300 font-semibold">Anti 90% False Signals</span>
          </div>
        </div>
      </div>

      {/* Signal Text Box (Matches Requested Format) */}
      <div className="bg-black/80 border border-slate-800 rounded-xl p-3.5 relative z-10 font-mono text-xs text-slate-300">
        <div className="flex items-center justify-between mb-2 pb-2 border-b border-slate-800 font-sans">
          <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wide">
            Format Output Sinyal Lengkap (ZRILL AGI)
          </span>
          <button
            onClick={handleCopy}
            className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 font-mono"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
        </div>
        <pre className="whitespace-pre-wrap leading-relaxed text-[11px] text-slate-200">
          {formattedOutputSignalText}
        </pre>
      </div>
    </motion.div>
  );
};
