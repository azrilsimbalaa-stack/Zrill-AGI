import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Landmark,
  Zap,
  Activity,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  Layers,
  ArrowRight,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Flame,
  Crosshair,
  BarChart3,
  RefreshCw,
} from "lucide-react";
import {
  RealtimeMacroSMCFusion,
  computeRealtimeMacroSMCFusion,
} from "../services/realtimeFundamentalStreamEngine";

interface RealtimeFundamentalSMCFusionCardProps {
  fusionData?: RealtimeMacroSMCFusion;
  symbol?: { id?: string; name?: string; basePrice?: number } | string | null;
  currentPrice: number;
  direction?: "BUY" | "SELL" | string;
  timeframe?: string;
  onRefresh?: () => void;
}

export const RealtimeFundamentalSMCFusionCard: React.FC<RealtimeFundamentalSMCFusionCardProps> = ({
  fusionData: initialFusionData,
  symbol,
  currentPrice,
  direction = "BUY",
  timeframe = "M15",
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<"TRIPLE_SYNERGY" | "MACRO_STREAM" | "OB_FVG_MATRIX">("TRIPLE_SYNERGY");
  const [liveElapsedSeconds, setLiveElapsedSeconds] = useState(4);
  const [livePulseTick, setLivePulseTick] = useState(0);

  const safeSymbolObj = typeof symbol === "object" && symbol !== null
    ? symbol
    : { id: typeof symbol === "string" ? symbol : "XAUUSD", name: typeof symbol === "string" ? symbol : "GOLD" };

  // Compute live fusion data if not provided or fallback
  const fusion = initialFusionData || computeRealtimeMacroSMCFusion({
    symbol: safeSymbolObj,
    currentPrice,
    direction,
    timeframe,
  });

  const isUp = fusion.direction === "BUY";
  const { macroPulse, orderBlock, fairValueGap, goldenPocket, sniperBlueprint } = fusion;

  // Real-time live ticker pulse effect every second (Simulating sub-second continuous live macro data stream)
  useEffect(() => {
    const timer = setInterval(() => {
      setLiveElapsedSeconds((prev) => (prev > 58 ? 2 : prev + 1));
      setLivePulseTick((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="p-4 rounded-2xl bg-gradient-to-r from-[#0a1220] via-[#0f1d32] to-[#0a1220] border border-blue-500/50 shadow-[0_0_40px_rgba(59,130,246,0.25)] flex flex-col gap-3 font-mono text-white relative overflow-hidden"
    >
      {/* Top Ambient Glow */}
      <div className="absolute top-0 right-0 w-96 h-32 bg-blue-500/10 blur-3xl pointer-events-none"></div>
      <div className="absolute top-0 left-0 w-80 h-28 bg-emerald-500/10 blur-3xl pointer-events-none"></div>

      {/* Header Banner: Realtime Zero-Delay Macro Fundamental & Triple SMC Confluence */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-blue-500/25 pb-3 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500/30 to-emerald-500/20 text-blue-300 border border-blue-400/40 shadow-inner">
            <Radio className="w-5 h-5 text-blue-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                 REAL-TIME FUNDAMENTAL STREAM &amp; SMC TRIPLE CONFLUENCE (OB + FVG)
              </span>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                ZERO DELAY • FRESH EVERY SECOND
              </span>
            </div>
            <span className="text-[10px] text-blue-300 font-medium">
              Sinergi Sempurna: Katalis Makro Fresh Realtime + Unmitigated Order Block (OB) + Fair Value Gap (50% CE)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="text-right hidden sm:block">
            <div className="text-[9px] text-gray-400 font-bold">LATENCY STREAM:</div>
            <div className="text-xs font-black text-emerald-400 font-mono flex items-center gap-1 justify-end">
              <Activity className="w-3 h-3 text-emerald-400 animate-pulse" />
              {macroPulse.latencyMs || 14}ms • FRESH TICK #{livePulseTick}
            </div>
          </div>
          <span className="px-3 py-1 rounded-xl text-[10px] font-black bg-gradient-to-r from-blue-600/30 via-emerald-600/30 to-cyan-600/30 text-cyan-200 border border-cyan-400/40 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            CONFLUENCE: {fusion.tripleSynergyScore}% (AAA+)
          </span>
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="p-1.5 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-300 transition-all cursor-pointer active:scale-95"
              title="Sinkronisasi Ulang Data Fundamental & SMC"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/50 border border-white/10 w-fit text-[10px] font-bold">
        <button
          onClick={() => setActiveTab("TRIPLE_SYNERGY")}
          className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "TRIPLE_SYNERGY"
              ? "bg-blue-600 text-white shadow-md font-black"
              : "text-gray-400 hover:text-white"
          }`}
        >
          <Sparkles className="w-3 h-3 text-amber-300" />
          <span>TRIPLE CONFLUENCE COCKPIT</span>
        </button>
        <button
          onClick={() => setActiveTab("MACRO_STREAM")}
          className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "MACRO_STREAM"
              ? "bg-blue-600 text-white shadow-md font-black"
              : "text-gray-400 hover:text-white"
          }`}
        >
          <Landmark className="w-3 h-3 text-blue-300" />
          <span>ZERO-DELAY MACRO STREAM (DXY, YIELDS, FOMC)</span>
        </button>
        <button
          onClick={() => setActiveTab("OB_FVG_MATRIX")}
          className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
            activeTab === "OB_FVG_MATRIX"
              ? "bg-blue-600 text-white shadow-md font-black"
              : "text-gray-400 hover:text-white"
          }`}
        >
          <Layers className="w-3 h-3 text-emerald-300" />
          <span>ORDER BLOCK &amp; FVG MATRIX ({timeframe})</span>
        </button>
      </div>

      {/* TAB 1: TRIPLE SYNERGY COCKPIT (Main View) */}
      {activeTab === "TRIPLE_SYNERGY" && (
        <div className="flex flex-col gap-3">
          {/* Real-time Headline Flash Strip */}
          <div className="p-2.5 rounded-xl bg-gradient-to-r from-blue-950/70 via-indigo-950/50 to-blue-950/70 border border-blue-500/30 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[9px] font-black border border-blue-500/40 flex items-center gap-1">
                <Flame className="w-3 h-3 text-amber-400 animate-pulse" />
                FLASH MACRO MOVER
              </span>
              <span className="text-white font-bold text-[11px] flex items-center gap-1">
                {macroPulse.breakingMacroCatalyst.headline}
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[9px] text-blue-300">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400" />
                {liveElapsedSeconds}s yang lalu • {macroPulse.breakingMacroCatalyst.source}
              </span>
              <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                SENTIMEN: +{macroPulse.breakingMacroCatalyst.sentimentScore} (BULLISH ACCUMULATION)
              </span>
            </div>
          </div>

          {/* 3 Pillars Triple Synergy Cards: 1. Fundamental Catalyst, 2. Unmitigated OB, 3. FVG Imbalance */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
            {/* Pillar 1: Fresh Macro Real-Time Engine */}
            <div className="p-3 rounded-xl bg-black/60 border border-blue-500/40 flex flex-col justify-between gap-2 relative overflow-hidden group hover:border-blue-400 transition-all">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-blue-300 uppercase tracking-wider flex items-center gap-1">
                  <Landmark className="w-3.5 h-3.5 text-blue-400" />
                  1. REALTIME FUNDAMENTAL
                </span>
                <span className="text-[8px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  SEARAH BIAS ({macroPulse.fundamentalBiasScore}%)
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">DXY Live Ticker:</span>
                  <span className="text-sm font-black text-cyan-300 font-mono">
                    {macroPulse.dxyPulse.liveValue} ({macroPulse.dxyPulse.tickDelta < 0 ? "▼" : "▲"} {macroPulse.dxyPulse.tickDelta})
                  </span>
                </div>
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">US 10Y Yields:</span>
                  <span className="text-sm font-black text-emerald-400 font-mono">
                    {macroPulse.us10YYieldPulse.liveYieldPct}% (▼ {Math.abs(macroPulse.us10YYieldPulse.tickDeltaBps)} bps)
                  </span>
                </div>
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">FOMC Dovish Probability:</span>
                  <span className="text-xs font-bold text-purple-300 font-mono">
                    {macroPulse.fedPolicyPulse.rateCutProbabilityPct}% Cut Implied
                  </span>
                </div>
              </div>

              <p className="text-[9px] text-gray-300 leading-tight border-t border-white/5 pt-1.5 font-sans">
                {macroPulse.dxyPulse.liveImpactVerdict}
              </p>
            </div>

            {/* Pillar 2: Unmitigated Order Block (OB) */}
            <div className="p-3 rounded-xl bg-black/60 border border-emerald-500/40 flex flex-col justify-between gap-2 relative overflow-hidden group hover:border-emerald-400 transition-all">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-emerald-300 uppercase tracking-wider flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-emerald-400" />
                  2. UNMITIGATED ORDER BLOCK
                </span>
                <span className="text-[8px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  {orderBlock.mitigationStatus.replace(/_/g, " ")}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">OB Span ({timeframe}):</span>
                  <span className="text-xs font-black text-white font-mono">
                    ${orderBlock.lowPrice.toFixed(2)} - ${orderBlock.highPrice.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-baseline p-1 rounded bg-emerald-500/10 border border-emerald-500/20">
                  <span className="text-[10px] text-emerald-300 font-bold">Mean Threshold (50% OB):</span>
                  <span className="text-sm font-black text-emerald-400 font-mono">
                    ${orderBlock.meanThresholdPrice.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">Whale Delta Wall:</span>
                  <span className="text-[10px] font-bold text-cyan-300 font-mono">
                    {orderBlock.institutionalVolumeDelta}
                  </span>
                </div>
              </div>

              <p className="text-[9px] text-gray-300 leading-tight border-t border-white/5 pt-1.5 font-sans">
                {orderBlock.tacticalAdvantage}
              </p>
            </div>

            {/* Pillar 3: Fair Value Gap (FVG Imbalance) */}
            <div className="p-3 rounded-xl bg-black/60 border border-cyan-500/40 flex flex-col justify-between gap-2 relative overflow-hidden group hover:border-cyan-400 transition-all">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-cyan-400" />
                  3. FAIR VALUE GAP (FVG)
                </span>
                <span className="text-[8px] px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                  MAGNETISME: {fairValueGap.magneticPullScore}%
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">FVG Imbalance Span:</span>
                  <span className="text-xs font-black text-white font-mono">
                    ${fairValueGap.bottomPrice.toFixed(2)} - ${fairValueGap.topPrice.toFixed(2)} ({fairValueGap.gapWidthPips} Pips)
                  </span>
                </div>
                <div className="flex justify-between items-baseline p-1 rounded bg-cyan-500/10 border border-cyan-500/20">
                  <span className="text-[10px] text-cyan-300 font-bold">Consequent Encroachment (50% CE):</span>
                  <span className="text-sm font-black text-cyan-400 font-mono">
                    ${fairValueGap.consequentEncroachmentPrice.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] text-gray-400">Imbalance State:</span>
                  <span className="text-[10px] font-bold text-amber-300 font-mono">
                    {fairValueGap.fillStatus.replace(/_/g, " ")}
                  </span>
                </div>
              </div>

              <p className="text-[9px] text-gray-300 leading-tight border-t border-white/5 pt-1.5 font-sans">
                {fairValueGap.tacticalAdvantage}
              </p>
            </div>
          </div>

          {/* Sniper Execution Cockpit Blueprint */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#0d1e38] via-[#10294c] to-[#0d1e38] border border-cyan-400/40 shadow-inner flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: "12s" }} />
                <span className="text-xs font-black text-white uppercase tracking-wider">
                   CETAK BIRU EKSEKUSI SNIPER (TRIPLE CONFLUENCE BLUEPRINT)
                </span>
              </div>
              <span className="text-[9px] px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-400/40 font-bold">
                REKOMENDASI: {sniperBlueprint.primaryEntryMethod.replace(/_/g, " ")}
              </span>
            </div>

            {/* Quick Pricing Grid: Limit Entry (CE/OB), Hard Floor SL, and Targets */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-black/60 border border-emerald-500/30 flex flex-col">
                <span className="text-[8px] text-emerald-300 font-bold uppercase">TITIK ENTRY SNIPER (FVG CE / OB)</span>
                <span className="text-base font-black text-emerald-400 font-mono">
                  ${sniperBlueprint.sniperEntryPrice.toFixed(2)}
                </span>
                <span className="text-[8px] text-gray-400 font-mono mt-0.5">
                  Zona: {sniperBlueprint.optimalEntryRange}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-black/60 border border-rose-500/30 flex flex-col">
                <span className="text-[8px] text-rose-300 font-bold uppercase">HARD FLOOR SL (OB SHIELD)</span>
                <span className="text-base font-black text-rose-400 font-mono">
                  ${sniperBlueprint.stopLossHardFloor.toFixed(2)}
                </span>
                <span className="text-[8px] text-rose-300/80 font-mono mt-0.5">
                  Risiko: {sniperBlueprint.slPipRisk} Pips
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-black/60 border border-cyan-500/30 flex flex-col">
                <span className="text-[8px] text-cyan-300 font-bold uppercase">TP 2 (SMC EXPANSION)</span>
                <span className="text-base font-black text-cyan-400 font-mono">
                  ${sniperBlueprint.tp2Price.toFixed(2)}
                </span>
                <span className="text-[8px] text-cyan-300 font-mono mt-0.5">
                  Reward: +{sniperBlueprint.tp2SMCExpansionPips} Pips
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-black/60 border border-purple-500/30 flex flex-col">
                <span className="text-[8px] text-purple-300 font-bold uppercase">EXPECTED ALPHA (+EV)</span>
                <span className="text-base font-black text-purple-300 font-mono">
                  {sniperBlueprint.riskRewardRatio}
                </span>
                <span className="text-[8px] text-emerald-400 font-mono mt-0.5 font-bold">
                  {sniperBlueprint.expectedAlphaValue}
                </span>
              </div>
            </div>

            {/* Actionable Reasoning Box */}
            <div className="p-2.5 rounded-lg bg-black/40 border border-white/10 text-[10px] text-gray-200 font-sans leading-relaxed">
              <span className="font-bold text-cyan-300 font-mono mr-1"> VONIS TRIPLE CONFLUENCE:</span>
              {sniperBlueprint.actionableReasoning}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ZERO-DELAY MACRO STREAM (Deep Fundamental Vectors) */}
      {activeTab === "MACRO_STREAM" && (
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
            {/* Live DXY Vector */}
            <div className="p-3 rounded-xl bg-black/50 border border-blue-500/30 flex flex-col justify-between gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[8px] font-bold text-gray-400 uppercase">INDEKS DOLAR AS (DXY)</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                  {macroPulse.dxyPulse.trend}
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-base font-black text-cyan-300 font-mono">
                  {macroPulse.dxyPulse.liveValue}
                </span>
                <span className="text-[9px] text-gray-400 font-mono">Korelasi: {macroPulse.dxyPulse.correlationScore}</span>
              </div>
              <p className="text-[9px] text-gray-300 leading-tight">
                {macroPulse.dxyPulse.dollarSmileRegime}
              </p>
            </div>

            {/* Live US 10Y Yields */}
            <div className="p-3 rounded-xl bg-black/50 border border-emerald-500/30 flex flex-col justify-between gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[8px] font-bold text-gray-400 uppercase">IMBAL HASIL US 10Y</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  {macroPulse.us10YYieldPulse.realRateTrajectory}
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-base font-black text-emerald-400 font-mono">
                  {macroPulse.us10YYieldPulse.liveYieldPct}%
                </span>
                <span className="text-[9px] text-gray-400 font-mono">TIPS: {macroPulse.us10YYieldPulse.tipsRealYield}%</span>
              </div>
              <p className="text-[9px] text-gray-300 leading-tight">
                {macroPulse.us10YYieldPulse.liveImpactVerdict}
              </p>
            </div>

            {/* Live FedWatch Policy Rate */}
            <div className="p-3 rounded-xl bg-black/50 border border-purple-500/30 flex flex-col justify-between gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[8px] font-bold text-gray-400 uppercase">FOMC FED POLICY RATE</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30">
                  {macroPulse.fedPolicyPulse.policyStance}
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-base font-black text-purple-300 font-mono">
                  {macroPulse.fedPolicyPulse.rateCutProbabilityPct}% Probability
                </span>
                <span className="text-[9px] text-purple-300 font-mono">{macroPulse.fedPolicyPulse.terminalRateProjection}</span>
              </div>
              <p className="text-[9px] text-gray-300 leading-tight">
                {macroPulse.fedPolicyPulse.qtLiquidityImpact}
              </p>
            </div>

            {/* Global Hoarding & Liquidity Stream */}
            <div className="p-3 rounded-xl bg-black/50 border border-amber-500/30 flex flex-col justify-between gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[8px] font-bold text-gray-400 uppercase">GLOBAL LIQUIDITY FLOW</span>
                <span className="text-[8px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  INSTITUTIONAL INFLOW
                </span>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-black text-amber-300 font-mono">
                  {macroPulse.globalLiquidityPulse.etfInstitutionalFlowNet}
                </span>
              </div>
              <p className="text-[9px] text-gray-300 leading-tight">
                {macroPulse.globalLiquidityPulse.centralBankNetHoarding}
              </p>
            </div>
          </div>

          {/* Flash News Catalyst Detail Banner */}
          <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-col gap-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-blue-300 uppercase flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-blue-400" />
                KATALIS PASAR LIVE FRESH TANPA DELAY (REAL-TIME IMPACT FEED)
              </span>
              <span className="text-[9px] text-emerald-400 font-bold">
                SNR (Signal-to-Noise Ratio): 98.6%
              </span>
            </div>
            <p className="text-gray-200 font-sans leading-relaxed text-[11px]">
              {macroPulse.breakingMacroCatalyst.verdictAction}
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: ORDER BLOCK & FVG MATRIX (Deep Technical SMC Levels) */}
      {activeTab === "OB_FVG_MATRIX" && (
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Order Block Deep Architecture */}
            <div className="p-3.5 rounded-xl bg-black/60 border border-emerald-500/40 flex flex-col gap-2">
              <span className="text-[10px] font-black text-emerald-300 uppercase flex items-center gap-1.5 border-b border-emerald-500/20 pb-1.5">
                <Layers className="w-4 h-4 text-emerald-400" />
                STRUKTUR ORDER BLOCK INSTITUSI ({timeframe})
              </span>
              <div className="flex flex-col gap-1.5 text-[11px] font-mono">
                <div className="flex justify-between">
                  <span className="text-gray-400">Tipe OB:</span>
                  <span className="text-emerald-400 font-bold">{orderBlock.type.replace(/_/g, " ")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Batas Atas OB:</span>
                  <span className="text-white font-bold">${orderBlock.highPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Batas Bawah OB:</span>
                  <span className="text-white font-bold">${orderBlock.lowPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between p-1 rounded bg-emerald-500/15 border border-emerald-500/30">
                  <span className="text-emerald-300 font-bold">Mean Threshold (50% OB):</span>
                  <span className="text-emerald-400 font-black">${orderBlock.meanThresholdPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Level Invalidasi Struktur:</span>
                  <span className="text-rose-400 font-bold">${orderBlock.invalidationLevel.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Fair Value Gap Deep Architecture */}
            <div className="p-3.5 rounded-xl bg-black/60 border border-cyan-500/40 flex flex-col gap-2">
              <span className="text-[10px] font-black text-cyan-300 uppercase flex items-center gap-1.5 border-b border-cyan-500/20 pb-1.5">
                <Zap className="w-4 h-4 text-cyan-400" />
                STRUKTUR FAIR VALUE GAP / IMBALANCE ({timeframe})
              </span>
              <div className="flex flex-col gap-1.5 text-[11px] font-mono">
                <div className="flex justify-between">
                  <span className="text-gray-400">Tipe FVG:</span>
                  <span className="text-cyan-400 font-bold">{fairValueGap.type.replace(/_/g, " ")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Batas Atas Imbalance:</span>
                  <span className="text-white font-bold">${fairValueGap.topPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Batas Bawah Imbalance:</span>
                  <span className="text-white font-bold">${fairValueGap.bottomPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between p-1 rounded bg-cyan-500/15 border border-cyan-500/30">
                  <span className="text-cyan-300 font-bold">Consequent Encroachment (50% CE):</span>
                  <span className="text-cyan-400 font-black">${fairValueGap.consequentEncroachmentPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Lebar Imbalance:</span>
                  <span className="text-cyan-300 font-bold">{fairValueGap.gapWidthPips} Pips</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
