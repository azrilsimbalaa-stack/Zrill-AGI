import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";

// Safely detect if firebase-applet-config.json exists without breaking Vite build if deleted
interface ViteImportMeta {
  glob?: (pattern: string, options?: { eager?: boolean }) => Record<string, { default?: any }>;
}

const importMetaWithGlob = import.meta as unknown as ViteImportMeta;
const configModules = (typeof importMetaWithGlob.glob === "function"
  ? importMetaWithGlob.glob("../firebase-applet-config.json", { eager: true })
  : {}) as Record<string, { default?: any }>;
const configEntry = Object.values(configModules)[0];
const firebaseConfig = configEntry ? (configEntry.default || configEntry) : null;

let firestoreDb: any = null;

if (firebaseConfig && (firebaseConfig.apiKey || firebaseConfig.projectId)) {
  try {
    const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
    const customDbId = firebaseConfig.firestoreDatabaseId;
    if (customDbId && customDbId !== "(default)") {
      try {
        firestoreDb = initializeFirestore(app, {}, customDbId);
      } catch {
        firestoreDb = getFirestore(app, customDbId);
      }
    } else {
      firestoreDb = getFirestore(app);
    }
  } catch (e1) {
    console.warn("[Firebase] Failed initializing custom database ID, falling back to default instance:", e1);
    try {
      const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
      firestoreDb = getFirestore(app);
    } catch (e2) {
      console.error("[Firebase] Firestore service unavailable:", e2);
    }
  }
} else {
  console.info("[Firebase] No firebase-applet-config.json found. App is using offline / local storage state safely.");
}

export const db = firestoreDb;

