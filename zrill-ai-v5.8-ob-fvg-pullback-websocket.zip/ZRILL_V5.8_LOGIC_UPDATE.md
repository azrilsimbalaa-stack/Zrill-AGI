# Zrill v5.8 Logic Update

UI files were not modified.

Signal engine:
1. Determine market direction.
2. Find a strong same-direction Order Block.
3. If available, place BUY LIMIT / SELL LIMIT at the OB equilibrium.
4. Otherwise check for a strong same-direction FVG and place the corresponding limit at FVG equilibrium.
5. If neither exists, output NO SIGNAL.
6. BOS, CHOCH, liquidity sweep, and candle confirmation are not required as an additional gate.
7. No Fibonacci/SNR/SD fallback can create a limit signal.
