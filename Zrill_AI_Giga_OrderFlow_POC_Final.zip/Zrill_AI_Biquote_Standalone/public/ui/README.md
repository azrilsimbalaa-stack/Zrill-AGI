# Zrill AI UI

These pages preserve the supplied Zrill AI reference UI structure and styling:
- market.html: Market UI, with TradingView replaced by standalone Biquote + Lightweight Charts.
- dashboard.html: supplied dashboard/news/calendar UI.
- admin.html: supplied admin UI.

No TradingView widget is loaded by market.html.
