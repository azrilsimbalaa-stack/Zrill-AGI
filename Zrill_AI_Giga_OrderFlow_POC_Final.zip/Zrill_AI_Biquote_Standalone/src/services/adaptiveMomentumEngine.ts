/**
 * ZRILL AI Adaptive Momentum Engine
 *
 * No SMC / ICT / Order Block / FVG dependency.
 * Uses a quantitative blend of:
 * - EMA trend alignment
 * - ADX directional strength
 * - RSI momentum regime
 * - Bollinger expansion / breakout
 * - ATR volatility for dynamic SL/TP
 * - Donchian breakout structure
 * - VWAP location
 * - Order-flow proxy from candle direction + volume/tickVolume
 * - POC approximation from recent volume-at-price buckets
 * - higher/lower timeframe direction supplied by the app
 *
 * The engine is designed to find more intraday opportunities while filtering
 * low-volatility chop. It does not claim a guaranteed win rate or profitability.
 */

export type AdaptiveDirection = "BUY" | "SELL";

interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

interface Input {
  symbol: any;
  timeframe: any;
  tradingStyle?: any;
  currentPrice: { bid: number; ask: number };
  indicators?: any;
  htfData?: any;
  ltfData?: any;
  economicEvents?: any[];
  assetNewsIntelligence?: any;
  isAutonomous?: boolean;
}

const n = (v: any, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

function atr(c: Candle[], p = 14) {
  if (c.length < p + 1) return 0;
  const tr = c.slice(1).map((x, i) => {
    const prev = c[i].close;
    return Math.max(x.high - x.low, Math.abs(x.high - prev), Math.abs(x.low - prev));
  });
  const s = tr.slice(-p);
  return s.reduce((a, b) => a + b, 0) / s.length;
}

function ema(values: number[], period: number) {
  if (!values.length) return 0;
  const k = 2 / (period + 1);
  let e = values[0];
  for (let i = 1; i < values.length; i++) e += (values[i] - e) * k;
  return e;
}

function rsi(values: number[], period = 14) {
  if (values.length <= period) return 50;
  let gain = 0, loss = 0;
  for (let i = values.length - period; i < values.length; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0) gain += d; else loss -= d;
  }
  if (loss === 0) return 100;
  return 100 - 100 / (1 + (gain / period) / (loss / period));
}

function adx(c: Candle[], period = 14) {
  if (c.length < period * 2 + 2) return { adx: 20, pdi: 50, mdi: 50 };
  const tr: number[] = [], plus: number[] = [], minus: number[] = [];
  for (let i = 1; i < c.length; i++) {
    const up = c[i].high - c[i - 1].high;
    const down = c[i - 1].low - c[i].low;
    plus.push(up > down && up > 0 ? up : 0);
    minus.push(down > up && down > 0 ? down : 0);
    tr.push(Math.max(c[i].high - c[i].low, Math.abs(c[i].high - c[i - 1].close), Math.abs(c[i].low - c[i - 1].close)));
  }
  let ts = tr.slice(0, period).reduce((a,b)=>a+b,0);
  let ps = plus.slice(0, period).reduce((a,b)=>a+b,0);
  let ms = minus.slice(0, period).reduce((a,b)=>a+b,0);
  const dx: number[] = [];
  let pdi = 50, mdi = 50;
  for (let i = period; i < tr.length; i++) {
    ts = ts - ts / period + tr[i];
    ps = ps - ps / period + plus[i];
    ms = ms - ms / period + minus[i];
    pdi = ts ? ps / ts * 100 : 0;
    mdi = ts ? ms / ts * 100 : 0;
    dx.push((pdi + mdi) ? Math.abs(pdi - mdi) / (pdi + mdi) * 100 : 0);
  }
  return { adx: dx.slice(-period).reduce((a,b)=>a+b,0) / Math.max(1, Math.min(period, dx.length)), pdi, mdi };
}

function bollinger(values: number[], period = 20, mult = 2) {
  const s = values.slice(-period);
  if (s.length < period) return { upper: 0, lower: 0, middle: 0 };
  const m = s.reduce((a,b)=>a+b,0) / period;
  const sd = Math.sqrt(s.reduce((a,b)=>a + Math.pow(b-m,2),0) / period);
  return { upper: m + mult*sd, lower: m - mult*sd, middle: m };
}

function vwap(c: Candle[], period = 60) {
  const s = c.slice(-period);
  if (!s.length) return 0;
  let pv = 0, vol = 0;
  for (const x of s) {
    const typical = (x.high + x.low + x.close) / 3;
    const weight = Math.max(1, x.volume || 1);
    pv += typical * weight;
    vol += weight;
  }
  return vol ? pv / vol : 0;
}

function orderFlowProxy(c: Candle[], period = 30) {
  const s = c.slice(-period);
  if (!s.length) return { delta: 0, imbalance: 0, buyPressure: 0, sellPressure: 0, absorption: false };
  let buy = 0, sell = 0;
  for (const x of s) {
    const vol = Math.max(1, n((x as any).volume, n((x as any).tickVolume, 1)));
    const range = Math.max(x.high - x.low, 1e-12);
    const body = x.close - x.open;
    // Proxy only: candle direction/body/range weights available quote volume.
    const pressure = clamp(body / range, -1, 1);
    const buyVol = vol * (0.5 + 0.5 * pressure);
    const sellVol = vol - buyVol;
    buy += buyVol;
    sell += sellVol;
  }
  const total = Math.max(1, buy + sell);
  const delta = (buy - sell) / total;
  return {
    delta,
    imbalance: Math.abs(delta),
    buyPressure: buy / total,
    sellPressure: sell / total,
    absorption: Math.abs(delta) < 0.08 && s.length >= 10 &&
      Math.abs(s[s.length-1].close - s[s.length-1].open) / Math.max(s[s.length-1].high-s[s.length-1].low,1e-12) < 0.35
  };
}

function volumePoc(c: Candle[], period = 60, bins = 24) {
  const s = c.slice(-period);
  if (!s.length) return 0;
  let lo = Infinity, hi = -Infinity;
  for (const x of s) { lo = Math.min(lo, x.low); hi = Math.max(hi, x.high); }
  if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi <= lo) return s[s.length-1].close;
  const step = (hi - lo) / bins;
  const bucketVol = Array(bins).fill(0);
  for (const x of s) {
    const typical = (x.high + x.low + x.close) / 3;
    const idx = Math.max(0, Math.min(bins - 1, Math.floor((typical - lo) / step)));
    bucketVol[idx] += Math.max(1, n((x as any).volume, n((x as any).tickVolume, 1)));
  }
  let best = 0;
  for (let i=1;i<bucketVol.length;i++) if (bucketVol[i] > bucketVol[best]) best=i;
  return lo + (best + 0.5) * step;
}

function buildSignal(input: Input, direction: AdaptiveDirection, score: number, reason: string[], candles: Candle[]) {
  const price = n(input.currentPrice.bid || input.currentPrice.ask);
  const a = Math.max(atr(candles), n(input.indicators?.atr, price * 0.001));
  const tf = String(input.timeframe?.id || "M15");
  const multiplier = ["M1","M5"].includes(tf) ? 1.15 : ["H4","D1"].includes(tf) ? 1.8 : 1.45;
  const risk = Math.max(a * multiplier, price * (tf === "D1" ? 0.006 : 0.002));
  const entry = price;
  const sl = direction === "BUY" ? entry - risk : entry + risk;
  const tp = direction === "BUY" ? entry + risk * 2.2 : entry - risk * 2.2;
  const rr = 2.2;
  const confidence = clamp(Math.round(58 + score * 4.5), 58, 91);
  return {
    status: "ACTIVE",
    type: direction,
    orderExecutionType: direction,
    symbol: input.symbol?.id || "UNKNOWN",
    timeframe: input.timeframe?.id || "M15",
    entry: Number(entry.toFixed(5)),
    sl: Number(sl.toFixed(5)),
    tp: Number(tp.toFixed(5)),
    tp1: Number(tp.toFixed(5)),
    tp2: Number((direction === "BUY" ? entry + risk*3 : entry - risk*3).toFixed(5)),
    tp3: Number((direction === "BUY" ? entry + risk*3.5 : entry - risk*3.5).toFixed(5)),
    rr,
    confidence,
    confluenceScore: Math.round(score),
    confluencePassed: score >= 6,
    qualityGrade: score >= 7.5 ? "A+ MOMENTUM" : "A MOMENTUM",
    method: "Adaptive Multi-Factor + Order Flow + POC (EMA + ADX + RSI + VWAP + Donchian + ATR)",
    orderFlow: { delta: Number((orderFlowProxy(candles, 30).delta * 100).toFixed(1)), buyPressure: Number((orderFlowProxy(candles, 30).buyPressure * 100).toFixed(1)), sellPressure: Number((orderFlowProxy(candles, 30).sellPressure * 100).toFixed(1)), proxy: true },
    poc: Number(volumePoc(candles, 60, 24).toFixed(5)),
    marketFilters: { orderFlow: "PROXY", poc: "VOLUME-AT-PRICE", newsBias: String(input.assetNewsIntelligence?.dominantBias || "NEUTRAL") },
    analysis: reason.join(" • "),
    actionStatusText: `MOMENTUM ${direction} TERKONFIRMASI`,
    timestamp: Date.now(),
    setupId: `AM-${input.symbol?.id}-${Date.now()}`,
  };
}

export function generateAdaptiveSignalSuite(input: Input): Record<string, any> {
  const bars: Candle[] = Array.isArray(input.indicators?.bars) ? input.indicators.bars : [];
  const closes = bars.map(b=>n(b.close)).filter(v=>v>0);
  const result: Record<string, any> = {};
  const key = `${input.symbol?.id || "UNKNOWN"}-${input.timeframe?.id || "M15"}`;

  if (closes.length < 40 || !(input.currentPrice?.bid > 0 || input.currentPrice?.ask > 0)) {
    result[key] = { status:"WAITING", type:"WAITING", orderExecutionType:"WAITING", symbol:input.symbol?.id, timeframe:input.timeframe?.id, confidence:0, analysis:"Data historis belum cukup untuk menghitung momentum." };
    return result;
  }

  const price = n(input.currentPrice.bid || input.currentPrice.ask);
  const e9 = ema(closes.slice(-80), 9);
  const e21 = ema(closes.slice(-100), 21);
  const e50 = ema(closes.slice(-150), 50);
  const r = rsi(closes, 14);
  const d = adx(bars);
  const bb = bollinger(closes, 20, 2);
  const vw = vwap(bars, 60);
  const a = Math.max(atr(bars), n(input.indicators?.atr));
  const flow = orderFlowProxy(bars, 30);
  const poc = volumePoc(bars, 60, 24);
  const pocDistance = a > 0 ? Math.abs(price - poc) / a : 999;
  const lookback = bars.slice(-21, -1);
  const priorHigh = Math.max(...lookback.map(x=>x.high));
  const priorLow = Math.min(...lookback.map(x=>x.low));
  const last = bars[bars.length-1];
  const prev = bars[bars.length-2];
  const body = Math.abs(last.close-last.open);
  const range = Math.max(last.high-last.low, 1e-12);
  const impulse = body / range >= 0.55;

  const htf = String(input.htfData?.overall || "").toUpperCase();
  const ltf = String(input.ltfData?.overall || "").toUpperCase();
  const bullishHTF = htf.includes("BULL");
  const bearishHTF = htf.includes("BEAR");
  const bullishLTF = ltf.includes("BULL");
  const bearishLTF = ltf.includes("BEAR");

  let buy = 0, sell = 0;
  const buyReasons: string[] = [], sellReasons: string[] = [];
  if (e9 > e21) { buy += 2; buyReasons.push("EMA9 > EMA21"); } else { sell += 2; sellReasons.push("EMA9 < EMA21"); }
  if (e21 > e50) { buy += 1.5; buyReasons.push("trend EMA21/50 bullish"); } else { sell += 1.5; sellReasons.push("trend EMA21/50 bearish"); }
  if (d.adx >= 18 && d.pdi > d.mdi) { buy += 1.5; buyReasons.push(`ADX ${d.adx.toFixed(0)} +DI dominan`); }
  if (d.adx >= 18 && d.mdi > d.pdi) { sell += 1.5; sellReasons.push(`ADX ${d.adx.toFixed(0)} -DI dominan`); }
  if (r >= 52 && r <= 72) { buy += 1; buyReasons.push(`RSI ${r.toFixed(0)} momentum sehat`); }
  if (r <= 48 && r >= 28) { sell += 1; sellReasons.push(`RSI ${r.toFixed(0)} momentum sehat`); }
  if (vw > 0 && price > vw) { buy += 1; buyReasons.push("VWAP bullish"); }
  if (vw > 0 && price < vw) { sell += 1; sellReasons.push("VWAP bearish"); }
  const nearEma21 = a > 0 && Math.abs(price - e21) <= a * 0.55;
  if (nearEma21 && e9 > e21 && r >= 48) { buy += 1.2; buyReasons.push("EMA21 momentum pullback"); }
  if (nearEma21 && e9 < e21 && r <= 52) { sell += 1.2; sellReasons.push("EMA21 momentum pullback"); }
  if (price > priorHigh) { buy += 2; buyReasons.push("breakout high 20 candle"); }
  if (price < priorLow) { sell += 2; sellReasons.push("breakdown low 20 candle"); }
  if (last.close > bb.upper) { buy += 1.5; buyReasons.push("Bollinger expansion breakout"); }
  if (last.close < bb.lower) { sell += 1.5; sellReasons.push("Bollinger expansion breakdown"); }
  if (impulse && last.close > last.open) { buy += 0.8; buyReasons.push("bullish impulse candle"); }
  if (impulse && last.close < last.open) { sell += 0.8; sellReasons.push("bearish impulse candle"); }
  if (bullishHTF) { buy += 1; buyReasons.push("HTF bullish"); }
  if (bearishHTF) { sell += 1; sellReasons.push("HTF bearish"); }
  if (bullishLTF) { buy += 0.7; buyReasons.push("LTF bullish"); }
  if (bearishLTF) { sell += 0.7; sellReasons.push("LTF bearish"); }
  if (flow.delta >= 0.12) { buy += 1.8; buyReasons.push(`Order Flow buyer pressure ${(flow.buyPressure*100).toFixed(0)}%`); }
  if (flow.delta <= -0.12) { sell += 1.8; sellReasons.push(`Order Flow seller pressure ${(flow.sellPressure*100).toFixed(0)}%`); }
  if (flow.delta >= 0.25 && impulse && last.close > last.open) { buy += 0.8; buyReasons.push("strong positive flow imbalance"); }
  if (flow.delta <= -0.25 && impulse && last.close < last.open) { sell += 0.8; sellReasons.push("strong negative flow imbalance"); }
  if (flow.absorption) {
    if (last.close > last.open) { buy += 0.4; buyReasons.push("flow absorption + bullish response"); }
    if (last.close < last.open) { sell += 0.4; sellReasons.push("flow absorption + bearish response"); }
  }
  if (poc > 0 && price > poc && e9 > e21) { buy += 1.0; buyReasons.push(`POC acceptance bullish (${poc.toFixed(5)})`); }
  if (poc > 0 && price < poc && e9 < e21) { sell += 1.0; sellReasons.push(`POC acceptance bearish (${poc.toFixed(5)})`); }
  // Avoid chasing when price is excessively stretched away from the volume control point.
  if (pocDistance > 3.0 && buy > sell) { buy -= 1.0; buyReasons.push("price stretched >3 ATR from POC"); }
  if (pocDistance > 3.0 && sell > buy) { sell -= 1.0; sellReasons.push("price stretched >3 ATR from POC"); }
  const newsBias = String(input.assetNewsIntelligence?.dominantBias || "").toUpperCase();
  const newsSNR = n(input.assetNewsIntelligence?.signalToNoiseRatio, 0);
  const newsAlignedBuy = newsBias.includes("BULL") && newsSNR >= 50;
  const newsAlignedSell = newsBias.includes("BEAR") && newsSNR >= 50;
  if (newsAlignedBuy) { buy += Math.min(1.5, 0.5 + newsSNR / 100); buyReasons.push(`News bias bullish (${newsSNR}% SNR)`); }
  if (newsAlignedSell) { sell += Math.min(1.5, 0.5 + newsSNR / 100); sellReasons.push(`News bias bearish (${newsSNR}% SNR)`); }
  if (newsBias && ((newsBias.includes("BEAR") && buy > sell + 2) || (newsBias.includes("BULL") && sell > buy + 2))) {
    if (newsBias.includes("BEAR")) buy -= 0.8;
    if (newsBias.includes("BULL")) sell -= 0.8;
  }

  // Avoid forcing entries in compressed volatility / direct contradiction.
  const compression = a > 0 && (bb.upper - bb.lower) < a * 1.35;
  const volatilityOK = !compression || Math.abs(last.close-prev.close) > a * 0.35;
  const edge = Math.abs(buy-sell);
  const winner = buy > sell ? "BUY" : "SELL";
  const winnerScore = Math.max(buy, sell);
  const enoughEdge = edge >= 1.0;
  const flowAligned = winner === "BUY" ? flow.delta >= 0.04 : flow.delta <= -0.04;
  const enoughStrength = d.adx >= 17 || (winnerScore >= 6.0 && impulse);

  if (!volatilityOK || !enoughEdge || !enoughStrength || !flowAligned) {
    result[key] = {
      status:"WAITING", type:"WAITING", orderExecutionType:"WAITING", symbol:input.symbol?.id, timeframe:input.timeframe?.id,
      entry:0, sl:0, tp:0, confidence:Math.round(clamp(45 + winnerScore*4,45,64)), rr:"-", confluenceScore:Math.round(winnerScore),
      confluencePassed:false, qualityGrade:"NO TRADE", method:"Adaptive Momentum + Trend + Volatility",
      analysis: !volatilityOK ? "Volatilitas terlalu terkompresi." : !flowAligned ? "Order Flow belum mendukung arah momentum." : "Momentum belum cukup dominan untuk entry.", timestamp:Date.now()
    };
    return result;
  }

  const signal = buildSignal(input, winner as AdaptiveDirection, winnerScore, winner === "BUY" ? buyReasons : sellReasons, bars);
  result[key] = signal;
  result[input.symbol?.id || key] = signal;
  return result;
}
