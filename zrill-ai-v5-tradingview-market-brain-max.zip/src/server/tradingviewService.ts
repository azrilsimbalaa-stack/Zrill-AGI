import WebSocket from "ws";

export interface TradingViewPrice {
  symbol: string;
  tradingviewSymbol: string;
  price: number;
  bid: number;
  ask: number;
  ch: number;
  chp: number;
  volume: number;
  high: number;
  low: number;
  open: number;
  updatedAt: number;
}

const SYMBOL_MAP: Record<string, string> = {
  "XAUUSD": "OANDA:XAUUSD",
  "BTCUSD": "COINBASE:BTCUSD",
  "BTCUSDT": "COINBASE:BTCUSD",
  "BTC": "COINBASE:BTCUSD",
  "US100": "OANDA:NAS100USD",
  "NAS100": "OANDA:NAS100USD",
  "NASDAQ": "OANDA:NAS100USD",
  "EURUSD": "OANDA:EURUSD",
  "GBPUSD": "OANDA:GBPUSD",
  "USDJPY": "OANDA:USDJPY",
  "AUDUSD": "OANDA:AUDUSD",
  "ETHUSD": "COINBASE:ETHUSD",
};

const ADDITIONAL_SYMBOLS: string[] = [];

const REVERSE_SYMBOL_MAP: Record<string, string> = {
  "OANDA:XAUUSD": "XAUUSD",
  "COINBASE:BTCUSD": "BTCUSD",
  "OANDA:NAS100USD": "US100",
  "OANDA:EURUSD": "EURUSD",
  "OANDA:GBPUSD": "GBPUSD",
  "OANDA:USDJPY": "USDJPY",
  "OANDA:AUDUSD": "AUDUSD",
  "COINBASE:ETHUSD": "ETHUSD",
};

const priceMap: Record<string, TradingViewPrice> = {};



function generateSession() {
  const chars = "abcdefghijklmnopqrstuvwxyz";
  let str = "";
  for (let i = 0; i < 12; i++) {
    str += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return "qs_" + str;
}

function constructMsg(func: string, params: any[]) {
  const jsonStr = JSON.stringify({ m: func, p: params });
  return `~m~${jsonStr.length}~m~${jsonStr}`;
}

let ws: WebSocket | null = null;
let session = "";
let heartbeatTimeout: NodeJS.Timeout | null = null;

export function initTradingViewEngine() {
  connect();
}

function connect() {
  try {
    session = generateSession();
    ws = new WebSocket("wss://data.tradingview.com/socket.io/websocket", {
      headers: { Origin: "https://data.tradingview.com" },
    });

    const resetHeartbeat = () => {
      if (heartbeatTimeout) clearTimeout(heartbeatTimeout);
      heartbeatTimeout = setTimeout(() => {
        console.warn("[TradingView Engine] Silent connection detected (30s timeout). Terminating to reconnect...");
        if (ws) {
          try {
            ws.terminate();
          } catch (e) {}
        }
      }, 30000);
    };

    resetHeartbeat();

    ws.on("open", () => {
      console.log("[TradingView Engine] Connected with session:", session);
      if (!ws) return;
      resetHeartbeat();
      ws.send(constructMsg("quote_create_session", [session]));
      ws.send(
        constructMsg("quote_set_fields", [
          session,
          "lp",
          "volume",
          "ch",
          "chp",
          "bid",
          "ask",
          "high_price",
          "low_price",
          "open_price",
        ])
      );

      const allSymbolsToSubscribe = Array.from(new Set([...Object.values(SYMBOL_MAP), ...ADDITIONAL_SYMBOLS]));
      for (const tvSym of allSymbolsToSubscribe) {
        ws.send(constructMsg("quote_add_symbols", [session, tvSym]));
      }
    });

    ws.on("message", (data: WebSocket.Data) => {
      const str = data.toString();
      resetHeartbeat();
      
      // Handle Pings
      const pingMatch = str.match(/~m~\d+~m~~h~(\d+)/);
      if (pingMatch) {
        const pingId = pingMatch[1];
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(`~m~${pingId.length}~m~~h~${pingId}`);
        }
        return;
      }

      // Handle Data Payload
      if (str.includes("qsd")) {
        // TradingView protocol uses ~m~LEN~m~MSG format. We split by this pattern to handle bundled messages
        const payloads = str.split(/~m~\d+~m~/);
        for (const rawPayload of payloads) {
          const payload = rawPayload.trim();
          if (!payload || !payload.startsWith("{") || !payload.endsWith("}")) {
            continue;
          }
          try {
            const parsed = JSON.parse(payload);
            if (parsed.m === "qsd" && parsed.p && parsed.p[1]) {
              const tvSymData = parsed.p[1];
              const tvSymbolName = tvSymData.n; // e.g. "OANDA:XAUUSD"
              const val = tvSymData.v || {};
              const internalSymbol = REVERSE_SYMBOL_MAP[tvSymbolName] || tvSymbolName;

              const existing = priceMap[internalSymbol] || {
                symbol: internalSymbol,
                tradingviewSymbol: tvSymbolName,
                price: 0,
                bid: 0,
                ask: 0,
                ch: 0,
                chp: 0,
                volume: 0,
                high: 0,
                low: 0,
                open: 0,
                updatedAt: Date.now(),
              };

              if (val.lp != null) existing.price = val.lp;
              if (val.bid != null) existing.bid = val.bid;
              if (val.ask != null) existing.ask = val.ask;
              if (val.ch != null) existing.ch = val.ch;
              if (val.chp != null) existing.chp = val.chp;
              if (val.volume != null) existing.volume = val.volume;
              if (val.high_price != null) existing.high = val.high_price;
              if (val.low_price != null) existing.low = val.low_price;
              if (val.open_price != null) existing.open = val.open_price;
              
              if (existing.bid === 0 && existing.price > 0) existing.bid = existing.price;
              if (existing.ask === 0 && existing.price > 0) existing.ask = existing.price;
              if (existing.price === 0 && existing.bid > 0) existing.price = existing.bid;

              existing.updatedAt = Date.now();
              priceMap[internalSymbol] = existing;
            }
          } catch (e) {
            // Ignore parse errors for individual malformed sub-frames
          }
        }
      }
    });

    ws.on("error", (err) => {
      console.error("[TradingView Engine] WS Error:", err.message);
    });

    ws.on("close", () => {
      console.warn("[TradingView Engine] WS Closed. Reconnecting in 3s...");
      setTimeout(connect, 3000);
    });
  } catch (err) {
    console.error("[TradingView Engine] Connection error:", err);
    setTimeout(connect, 5000);
  }
}

export function getTradingViewPrice(symbol: string): TradingViewPrice | null {
  const cleanSym = symbol.toUpperCase().replace("=X", "").replace("-USD", "");
  const cached = priceMap[cleanSym];
  if (cached && cached.price > 0) return cached;
  return null;
}

export function getAllTradingViewPrices(): Record<string, TradingViewPrice> {
  return priceMap;
}

export interface TradingViewCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

const CANDLE_SYMBOL_MAP: Record<string, string> = {
  XAUUSD: "OANDA:XAUUSD",
  BTCUSD: "COINBASE:BTCUSD",
  BTCUSDT: "COINBASE:BTCUSD",
  BTC: "COINBASE:BTCUSD",
  US100: "OANDA:NAS100USD",
  NAS100: "OANDA:NAS100USD",
  NASDAQ: "OANDA:NAS100USD",
  EURUSD: "OANDA:EURUSD",
  GBPUSD: "OANDA:GBPUSD",
  USDJPY: "OANDA:USDJPY",
  AUDUSD: "OANDA:AUDUSD",
  USDCAD: "OANDA:USDCAD",
  USDCHF: "OANDA:USDCHF",
  NZDUSD: "OANDA:NZDUSD",
};

function makeChartSession() {
  const chars = "abcdefghijklmnopqrstuvwxyz";
  let s = "cs_";
  for (let i = 0; i < 12; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
}

function tvFrame(method: string, params: any[]) {
  const json = JSON.stringify({ m: method, p: params });
  return `~m~${json.length}~m~${json}`;
}

function parseTvTimescale(raw: string): TradingViewCandle[] {
  const result: TradingViewCandle[] = [];
  const frames = raw.split(/~m~\d+~m~/);
  for (const frame of frames) {
    const text = frame.trim();
    if (!text.startsWith("{")) continue;
    try {
      const msg = JSON.parse(text);
      if (msg.m !== "timescale_update" || !Array.isArray(msg.p)) continue;
      const payload = msg.p[1];
      if (!payload || typeof payload !== "object") continue;
      const series = Object.values(payload).find((v: any) => v && Array.isArray(v.s)) as any;
      if (!series?.s) continue;
      for (const point of series.s) {
        const values = point?.v;
        if (!Array.isArray(values) || values.length < 5) continue;
        let ti = Number(values[0]);
        let offset = 1;
        if (!(ti > 900000000 && ti < 5000000000)) {
          ti = Number(values[1]);
          offset = 2;
        }
        const open = Number(values[offset]);
        const high = Number(values[offset + 1]);
        const low = Number(values[offset + 2]);
        const close = Number(values[offset + 3]);
        const volume = Number(values[offset + 4] ?? 0);
        if (![ti, open, high, low, close].every(Number.isFinite)) continue;
        result.push({ time: ti * 1000, open, high, low, close, volume: Number.isFinite(volume) ? volume : 0 });
      }
    } catch (_) {}
  }
  const unique = new Map<number, TradingViewCandle>();
  for (const c of result) unique.set(c.time, c);
  return [...unique.values()].sort((a, b) => a.time - b.time);
}

export async function fetchTradingViewCandles(symbol: string, interval: string, limit = 250): Promise<TradingViewCandle[]> {
  const clean = symbol.toUpperCase().replace("/", "");
  const tvSymbol = CANDLE_SYMBOL_MAP[clean] || SYMBOL_MAP[clean];
  if (!tvSymbol) throw new Error(`Unsupported TradingView symbol: ${symbol}`);

  const resolutionMap: Record<string, string> = {
    "1M": "1", "M1": "1", "1": "1",
    "5M": "5", "M5": "5", "5": "5",
    "15M": "15", "M15": "15", "15": "15",
    "30M": "30", "M30": "30", "30": "30",
    "1H": "60", "H1": "60", "60": "60",
    "4H": "240", "H4": "240", "240": "240",
    "1D": "D", "D1": "D", "D": "D",
  };
  const resolution = resolutionMap[String(interval).toUpperCase()] || String(interval);
  const chartSession = makeChartSession();

  return await new Promise<TradingViewCandle[]>((resolve, reject) => {
    const socket = new WebSocket("wss://data.tradingview.com/socket.io/websocket", {
      headers: { Origin: "https://data.tradingview.com" },
    });
    let settled = false;
    let buffer = "";
    const finish = (err?: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      try { socket.close(); } catch (_) {}
      if (err) reject(err); else resolve(parseTvTimescale(buffer).slice(-Math.min(limit, 1000)));
    };
    const timeout = setTimeout(() => finish(new Error(`TradingView candle timeout: ${tvSymbol} ${resolution}`)), 8000);

    socket.on("open", () => {
      socket.send(tvFrame("chart_create_session", [chartSession, ""]));
      socket.send(tvFrame("switch_timezone", [chartSession, "Etc/UTC"]));
      socket.send(tvFrame("resolve_symbol", [chartSession, "symbol_1", `={"symbol":"${tvSymbol}","adjustment":"splits"}`]));
      socket.send(tvFrame("create_series", [chartSession, "s1", "s1", "symbol_1", resolution, limit, ""]));
    });
    socket.on("message", (data: WebSocket.Data) => {
      const text = data.toString();
      if (text.includes("protocol_error") || text.includes("critical_error")) {
        finish(new Error(`TradingView protocol error for ${tvSymbol}`));
        return;
      }
      buffer += text;
      if (text.includes("series_completed") || text.includes("du")) {
        const parsed = parseTvTimescale(buffer);
        if (parsed.length >= Math.min(20, limit)) finish();
      }
    });
    socket.on("error", (err) => finish(err instanceof Error ? err : new Error(String(err))));
    socket.on("close", () => {
      if (!settled) {
        const parsed = parseTvTimescale(buffer);
        if (parsed.length >= Math.min(20, limit)) finish();
        else finish(new Error(`TradingView closed before candles arrived: ${tvSymbol} ${resolution}`));
      }
    });
  });
}

export async function fetchTradingViewMarketBundle(symbol: string, limits = 180): Promise<Record<string, TradingViewCandle[]>> {
  const tfs = ["M1", "M5", "M15", "H1", "H4", "D1"];
  const pairs = await Promise.all(tfs.map(async tf => [tf, await fetchTradingViewCandles(symbol, tf, limits)] as const));
  const bundle: Record<string, TradingViewCandle[]> = {};
  for (const [tf, candles] of pairs) {
    if (candles.length < 35) throw new Error(`Insufficient TradingView candles for ${symbol} ${tf}: ${candles.length}`);
    bundle[tf] = candles;
  }
  return bundle;
}
