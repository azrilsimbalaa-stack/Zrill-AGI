import React, { memo, useCallback, useEffect, useRef, useState } from "react";
import { createChart, CandlestickSeries, ColorType, CrosshairMode, type IChartApi, type ISeriesApi, type CandlestickData, type Time } from "lightweight-charts";
import { Lock, Maximize2, Minimize2, Unlock, Wifi, WifiOff } from "lucide-react";

interface TradingViewChartProps {
  symbol: string;
  timeframe: string;
  theme?: "dark" | "light";
  height?: number | string;
}

type BiquoteBar = {
  openTime: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
  tickVolume?: number;
  isOpen?: boolean;
};

type BiquoteResponse = {
  symbol: string;
  interval: string;
  bars: BiquoteBar[];
};

type BiquoteTick = {
  symbol?: string;
  bid?: number;
  ask?: number;
  mid?: number;
  time?: string;
  timestamp?: string;
  ts?: string | number;
};

declare global {
  interface Window {
    signalR?: any;
  }
}

const BIQUOTE_BASE = "https://biquote.io";
const SIGNALR_CDN = "https://cdnjs.cloudflare.com/ajax/libs/microsoft-signalr/8.0.7/signalr.min.js";

const TF_MAP: Record<string, { api: string; seconds: number }> = {
  M1: { api: "1m", seconds: 60 },
  M5: { api: "5m", seconds: 300 },
  M15: { api: "15m", seconds: 900 },
  M30: { api: "30m", seconds: 1800 },
  H1: { api: "1h", seconds: 3600 },
  H4: { api: "4h", seconds: 14400 },
  D1: { api: "1d", seconds: 86400 },
};

function normalizeSymbol(symbol: string): string {
  const clean = (symbol || "XAUUSD").toUpperCase().replace(/[/:_-]/g, "");
  if (clean.includes("GOLD") || clean.includes("XAU")) return "XAUUSD";
  if (clean.includes("BITCOIN") || clean.includes("BTC")) return "BTCUSD";
  if (clean.includes("ETH")) return "ETHUSD";
  if (clean.includes("NASDAQ") || clean.includes("NAS100")) return "NAS100USD";
  return clean;
}

function normalizeTimeframe(tf: string) {
  const clean = (tf || "M30").toUpperCase().trim();
  if (clean === "1" || clean === "1M" || clean === "M1") return "M1";
  if (clean === "5" || clean === "5M" || clean === "M5") return "M5";
  if (clean === "15" || clean === "15M" || clean === "M15") return "M15";
  if (clean === "30" || clean === "30M" || clean === "M30") return "M30";
  if (clean === "60" || clean === "1H" || clean === "H1") return "H1";
  if (clean === "240" || clean === "4H" || clean === "H4") return "H4";
  if (clean === "D" || clean === "1D" || clean === "D1") return "D1";
  return "M30";
}

function getPrice(tick: BiquoteTick): number | null {
  const value = Number(tick.mid ?? ((Number(tick.bid) + Number(tick.ask)) / 2));
  return Number.isFinite(value) && value > 0 ? value : null;
}

function getTickTime(tick: BiquoteTick): number {
  const raw = tick.time ?? tick.timestamp ?? tick.ts;
  if (typeof raw === "number") return raw > 2_000_000_000_000 ? raw : raw * 1000;
  const parsed = raw ? Date.parse(String(raw)) : NaN;
  return Number.isFinite(parsed) ? parsed : Date.now();
}

function loadSignalR(): Promise<any> {
  if (window.signalR) return Promise.resolve(window.signalR);
  return new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(`script[src="${SIGNALR_CDN}"]`);
    if (existing) {
      existing.addEventListener("load", () => resolve(window.signalR));
      existing.addEventListener("error", reject);
      return;
    }
    const script = document.createElement("script");
    script.src = SIGNALR_CDN;
    script.async = true;
    script.onload = () => window.signalR ? resolve(window.signalR) : reject(new Error("SignalR gagal dimuat"));
    script.onerror = () => reject(new Error("SignalR CDN gagal dimuat"));
    document.head.appendChild(script);
  });
}

export const TradingViewChart: React.FC<TradingViewChartProps> = memo(({ symbol, timeframe, theme = "dark", height = "100%" }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const connectionRef = useRef<any>(null);
  const currentBarRef = useRef<CandlestickData<Time> | null>(null);
  const intervalRef = useRef(TF_MAP.M30.seconds);
  const symbolRef = useRef("XAUUSD");
  const [locked, setLocked] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [live, setLive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await containerRef.current?.parentElement?.requestFullscreen();
        setFullscreen(true);
      } else {
        await document.exitFullscreen();
        setFullscreen(false);
      }
    } catch {
      setFullscreen(Boolean(document.fullscreenElement));
    }
  }, []);

  useEffect(() => {
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFullscreen);
    return () => document.removeEventListener("fullscreenchange", onFullscreen);
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let disposed = false;
    let resizeObserver: ResizeObserver | null = null;
    const cleanups: Array<() => void> = [];
    const cleanConnection = async () => {
      const conn = connectionRef.current;
      connectionRef.current = null;
      if (conn) {
        try { await conn.stop(); } catch { /* ignore */ }
      }
    };

    const tfKey = normalizeTimeframe(timeframe);
    const tf = TF_MAP[tfKey];
    const apiSymbol = normalizeSymbol(symbol);
    symbolRef.current = apiSymbol;
    intervalRef.current = tf.seconds;
    setLoading(true);
    setError("");
    setLive(false);

    container.innerHTML = "";
    const chart = createChart(container, {
      autoSize: true,
      layout: {
        background: { type: ColorType.Solid, color: theme === "light" ? "#f7f4ef" : "#0a0806" },
        textColor: theme === "light" ? "#5b4b3d" : "rgba(255,255,255,.65)",
        fontFamily: "-apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif",
      },
      grid: {
        vertLines: { color: theme === "light" ? "rgba(120,80,40,.08)" : "rgba(255,140,40,.055)" },
        horzLines: { color: theme === "light" ? "rgba(120,80,40,.08)" : "rgba(255,140,40,.055)" },
      },
      crosshair: { mode: CrosshairMode.Normal },
      rightPriceScale: { borderColor: theme === "light" ? "rgba(120,80,40,.15)" : "rgba(255,255,255,.08)" },
      timeScale: { borderColor: theme === "light" ? "rgba(120,80,40,.15)" : "rgba(255,255,255,.08)", timeVisible: true, secondsVisible: false },
      handleScroll: !locked,
      handleScale: !locked,
    });
    chartRef.current = chart;
    const series = chart.addSeries(CandlestickSeries, {
      upColor: "#ff8c28",
      downColor: "#f4f4f4",
      borderUpColor: "#ff8c28",
      borderDownColor: "#f4f4f4",
      wickUpColor: "#ff8c28",
      wickDownColor: "#f4f4f4",
      priceLineVisible: true,
      lastValueVisible: true,
    });
    seriesRef.current = series;

    resizeObserver = new ResizeObserver(() => chart.resize(container.clientWidth, container.clientHeight));
    resizeObserver.observe(container);

    const loadBars = async () => {
      const url = `${BIQUOTE_BASE}/api/${encodeURIComponent(apiSymbol)}/ohlc?interval=${tf.api}&limit=1000`;
      const response = await fetch(url, { headers: { Accept: "application/json" } });
      if (response.status === 429) {
        const retry = response.headers.get("Retry-After") || "60";
        throw new Error(`Biquote rate limit. Coba lagi dalam ${retry} detik.`);
      }
      if (!response.ok) throw new Error(`Biquote OHLC gagal (${response.status})`);
      const data = await response.json() as BiquoteResponse;
      if (!Array.isArray(data.bars) || !data.bars.length) throw new Error("Biquote tidak mengembalikan candle.");
      const bars = data.bars
        .filter(b => Number.isFinite(Number(b.open)) && Number.isFinite(Number(b.high)) && Number.isFinite(Number(b.low)) && Number.isFinite(Number(b.close)))
        .map(b => ({
          time: Math.floor(Date.parse(b.openTime) / 1000) as Time,
          open: Number(b.open), high: Number(b.high), low: Number(b.low), close: Number(b.close),
        }))
        .sort((a, b) => Number(a.time) - Number(b.time));
      series.setData(bars);
      currentBarRef.current = bars[bars.length - 1] || null;
      chart.timeScale().fitContent();
      setLoading(false);
    };

    const startStream = async () => {
      try {
        await loadBars();
        if (disposed) return;
        const signalR = await loadSignalR();
        const connection = new signalR.HubConnectionBuilder()
          .withUrl(`${BIQUOTE_BASE}/hubs/tick`)
          .withAutomaticReconnect([0, 1000, 2000, 5000, 10000])
          .build();
        connection.onreconnecting(() => setLive(false));
        connection.onreconnected(() => setLive(true));
        connection.onclose(() => setLive(false));
        connection.on("ReceiveTick", (tick: BiquoteTick) => {
          if (disposed || String(tick.symbol || "").toUpperCase() !== apiSymbol) return;
          const price = getPrice(tick);
          if (price == null || !seriesRef.current) return;
          const ts = getTickTime(tick);
          const bucket = Math.floor(ts / 1000 / intervalRef.current) * intervalRef.current;
          const current = currentBarRef.current;
          if (!current || Number(current.time) !== bucket) {
            const next: CandlestickData<Time> = { time: bucket as Time, open: price, high: price, low: price, close: price };
            currentBarRef.current = next;
            seriesRef.current.update(next);
          } else {
            const next: CandlestickData<Time> = {
              ...current,
              high: Math.max(current.high, price),
              low: Math.min(current.low, price),
              close: price,
            };
            currentBarRef.current = next;
            seriesRef.current.update(next);
          }
        });
        await connection.start();
        await connection.invoke("Subscribe", [apiSymbol]);
        connectionRef.current = connection;
        setLive(true);
      } catch (err) {
        if (!disposed) {
          setLoading(false);
          setLive(false);
          setError(err instanceof Error ? err.message : "Gagal menghubungkan market data.");
        }
      }
    };

    startStream();

    cleanups.push(() => { void cleanConnection(); });
    return () => {
      disposed = true;
      cleanups.forEach(fn => fn());
      resizeObserver?.disconnect();
      seriesRef.current = null;
      chart.remove();
      chartRef.current = null;
    };
  }, [symbol, timeframe, theme]);

  useEffect(() => {
    chartRef.current?.applyOptions({ handleScroll: !locked, handleScale: !locked });
  }, [locked]);

  return (
    <div
      className="w-full h-full relative overflow-hidden bg-[#0a0806]"
      style={{ height, touchAction: locked ? "none" : "manipulation" }}
    >
      <div className="absolute inset-x-0 top-0 z-30 pointer-events-none p-3 pt-[calc(12px+env(safe-area-inset-top))] flex justify-between items-start">
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="px-3 py-2 rounded-xl border border-orange-400/25 bg-[#1c140e]/90 backdrop-blur-xl shadow-lg text-orange-200 text-xs font-black tracking-tight flex items-center gap-2">
            <span className={`w-1.5 h-1.5 rounded-full ${live ? "bg-emerald-400 shadow-[0_0_9px_#30d158]" : "bg-orange-400"}`} />
            {apiSymbolLabel(symbolRef.current)}
          </div>
          <div className="px-3 py-2 rounded-xl border border-white/10 bg-[#1c140e]/90 backdrop-blur-xl text-white text-[11px] font-black">
            {normalizeTimeframe(timeframe)}
          </div>
        </div>
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className={`px-2.5 py-2 rounded-xl border backdrop-blur-xl text-[9px] font-black tracking-widest uppercase flex items-center gap-1.5 ${live ? "border-emerald-400/25 bg-emerald-400/10 text-emerald-300" : "border-orange-400/20 bg-black/30 text-orange-200"}`}>
            {live ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            {live ? "LIVE" : "CONNECTING"}
          </div>
          <button type="button" onClick={() => setLocked(v => !v)} className="w-9 h-9 rounded-xl border border-orange-400/20 bg-[#1c140e]/90 backdrop-blur-xl text-orange-200 flex items-center justify-center shadow-lg active:scale-95">
            {locked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
          </button>
          <button type="button" onClick={toggleFullscreen} className="w-9 h-9 rounded-xl border border-orange-400/20 bg-[#1c140e]/90 backdrop-blur-xl text-orange-200 flex items-center justify-center shadow-lg active:scale-95">
            {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {loading && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#0a0806] gap-3 pointer-events-none">
          <div className="w-10 h-10 rounded-full border-[3px] border-orange-400/15 border-t-orange-400 animate-spin" />
          <span className="text-[10px] font-black tracking-[.2em] uppercase text-orange-200/70">Memuat Biquote</span>
        </div>
      )}
      {error && (
        <div className="absolute left-3 right-3 bottom-3 z-30 rounded-xl border border-orange-400/20 bg-[#1c140e]/95 backdrop-blur-xl px-4 py-3 text-[11px] font-bold text-orange-100 shadow-xl">
          {error}
        </div>
      )}
      <div ref={containerRef} className="absolute inset-0" />
    </div>
  );
});

function apiSymbolLabel(symbol: string) {
  const clean = normalizeSymbol(symbol);
  return clean === "NAS100USD" ? "NASDAQ" : clean;
}

TradingViewChart.displayName = "TradingViewChart";
