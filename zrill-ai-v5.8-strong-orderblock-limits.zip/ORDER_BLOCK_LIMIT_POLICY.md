# Zrill v5.7 Strong Order Block Limit Policy

BUY LIMIT / SELL LIMIT are enabled again, but only when a strict Order Block gate passes.

Required conditions:
- correct bullish/bearish OB direction
- valid top/bottom/equilibrium
- fresh / virgin OB
- not invalidated
- zero mitigation count or active defense
- OB is the source of displacement
- tradable zone width
- H1/M15 directional confirmation
- confirming BOS/CHoCH or liquidity sweep
- sufficient distance from current price to avoid noise stop-out

If the gate fails, Zrill must not manufacture a limit entry from Fibonacci, FVG, SNR, or a generic POI. It falls back to the existing non-limit state.

A limit entry is placed at the Order Block equilibrium, not at a generic 0.618 fallback.
