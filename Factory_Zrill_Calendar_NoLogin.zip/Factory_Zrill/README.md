# Factory Zrill

Standalone calendar-only Android/Web project.

- App name: Factory Zrill
- Calendar source: Forex Factory official calendar embed
- No Zrill AI dashboard
- No market/chart UI
- Fullscreen immersive Android WebView

Source project basis: calendar-only separation requested from `zrill-agi (5).zip`.
