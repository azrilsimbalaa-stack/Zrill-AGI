import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Suppress transient WebSocket teardown errors (e.g. Market Feed / Binance WS unmounts)
if (typeof window !== 'undefined') {
  window.addEventListener(
    'error',
    (event) => {
      const msg = (event.message || '').toLowerCase();
      const src = (event.filename || '').toLowerCase();
      if (
        msg.includes('websocket') ||
        msg.includes('ws error') ||
        msg.includes('closed before the connection') ||
        src.includes('tradingview') ||
        src.includes('s3.tradingview.com')
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return true;
      }
    },
    true,
  );

  window.addEventListener('unhandledrejection', (event) => {
    const reason = String(event.reason || '').toLowerCase();
    if (
      reason.includes('websocket') ||
      reason.includes('ws error') ||
      reason.includes('closed before the connection') ||
      reason.includes('tradingview')
    ) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  });
}

// Register PWA service worker with auto-update
if ('serviceWorker' in navigator) {
  registerSW({
    immediate: true,
    onNeedRefresh() {
      console.log('PWA: Konten baru tersedia, memuat pembaruan...');
    },
    onOfflineReady() {
      console.log('PWA: Aplikasi siap dijalankan secara offline & fullscreen tanpa bilah status.');
    },
  });
}

// Auto-suppress Android Status Bar on mobile launch
if (typeof window !== 'undefined') {
  const enterFullscreen = () => {
    try {
      const docEl = document.documentElement as any;
      if (!document.fullscreenElement && !docEl.webkitFullscreenElement) {
        if (docEl.requestFullscreen) {
          docEl.requestFullscreen().catch(() => {});
        } else if (docEl.webkitRequestFullscreen) {
          docEl.webkitRequestFullscreen();
        }
      }
    } catch (e) {}
  };

  // Trigger on first touch if in standalone mode or mobile
  window.addEventListener('touchstart', enterFullscreen, { once: true, passive: true });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
