// Biquote Real-time Market Data & Historical OHLC Client
// Direct zero-latency EventSource (SSE) stream + Proxied OHLC historical feeds
// Supports automatic reconnect, HTTP 429 Retry-After handling, and zero-polling real-time updates.

export interface BiquoteTick {
  symbol: string;
  bid: number;
  ask: number;
  mid: number;
  price: number;
  last?: number;
  volume?: number;
  high?: number;
  low?: number;
  spread?: number;
  direction?: string;
  dayDiffPercent?: number;
  timestamp: string | number;
  source?: string;
}

export interface BiquoteBar {
  openTime: string;
  time: number; // Unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  tickVolume?: number;
  isOpen?: boolean;
}

export interface BiquoteOHLCResponse {
  symbol: string;
  interval: string;
  bars: BiquoteBar[];
}

type TickListener = (tick: BiquoteTick) => void;
type StatusListener = (status: "CONNECTED" | "CONNECTING" | "RECONNECTING" | "DISCONNECTED") => void;

class BiquoteClient {
  private subscribedSymbols = new Set<string>();
  private sseSources = new Map<string, EventSource>();
  private tickListeners: TickListener[] = [];
  private statusListeners: StatusListener[] = [];
  private currentStatus: "CONNECTED" | "CONNECTING" | "RECONNECTING" | "DISCONNECTED" = "CONNECTED";
  private latestPrices = new Map<string, BiquoteTick>();
  private lastRateLimitRetryAfter = 0;

  private setStatus(status: "CONNECTED" | "CONNECTING" | "RECONNECTING" | "DISCONNECTED") {
    if (this.currentStatus === status) return;
    this.currentStatus = status;
    for (const listener of this.statusListeners) {
      try {
        listener(status);
      } catch (err) {
        console.warn("[Biquote] Status listener error:", err);
      }
    }
  }

  public getStatus() {
    return this.currentStatus;
  }

  public onStatusChange(listener: StatusListener) {
    this.statusListeners.push(listener);
    listener(this.currentStatus);
    return () => {
      this.statusListeners = this.statusListeners.filter(l => l !== listener);
    };
  }

  public onTick(listener: TickListener) {
    this.tickListeners.push(listener);
    return () => {
      this.tickListeners = this.tickListeners.filter(l => l !== listener);
    };
  }

  public getLatestTick(symbol: string): BiquoteTick | undefined {
    return this.latestPrices.get(symbol.toUpperCase());
  }

  private handleIncomingTick = (raw: any) => {
    if (!raw) return;
    const sym = String(raw.symbol || raw.asset || "XAUUSD").toUpperCase();

    const bid = Number(raw.bid || raw.price || raw.last || 0) || 0;
    const ask = Number(raw.ask || raw.price || raw.last || 0) || 0;
    const mid = typeof raw.mid === "number" && raw.mid > 0
      ? raw.mid
      : (bid > 0 && ask > 0 ? (bid + ask) / 2 : (raw.price || raw.last || bid || ask || 0));

    const tick: BiquoteTick = {
      symbol: sym,
      bid: bid > 0 ? bid : mid,
      ask: ask > 0 ? ask : mid,
      mid: Number(mid.toFixed(sym.includes("JPY") ? 3 : sym.includes("BTC") ? 2 : 2)),
      price: mid,
      last: raw.last || mid,
      volume: raw.volume,
      high: raw.high,
      low: raw.low,
      spread: raw.spread ?? (ask > 0 && bid > 0 ? Number((ask - bid).toFixed(3)) : 0),
      direction: raw.direction,
      dayDiffPercent: raw.dayDiffPercent,
      timestamp: raw.timestamp || raw.updatedAt || Date.now(),
      source: raw.source || "Institutional Stream",
    };

    this.latestPrices.set(sym, tick);
    this.setStatus("CONNECTED");

    // Notify all subscribers
    for (const listener of this.tickListeners) {
      try {
        listener(tick);
      } catch (e) {
        console.warn("[Biquote] Tick listener error:", e);
      }
    }
  };

  private startSseForSymbol(symbol: string) {
    if (typeof window === "undefined") return;
    const cleanSym = symbol.toUpperCase().trim();
    if (this.sseSources.has(cleanSym)) return;

    try {
      const sse = new EventSource(`/api/tradingview/stream?symbol=${cleanSym}`);
      
      sse.onmessage = (event) => {
        try {
          if (!event.data || event.data.startsWith(":")) return; // heartbeat
          const parsed = JSON.parse(event.data);
          this.handleIncomingTick(parsed);
        } catch {}
      };

      sse.onopen = () => {
        this.setStatus("CONNECTED");
      };

      sse.onerror = () => {
        // EventSource will auto-reconnect automatically
      };

      this.sseSources.set(cleanSym, sse);
    } catch {}
  }

  public subscribe(symbol: string) {
    const cleanSym = symbol.toUpperCase().trim();
    this.subscribedSymbols.add(cleanSym);
    this.startSseForSymbol(cleanSym);
  }

  public unsubscribe(symbol: string) {
    const cleanSym = symbol.toUpperCase().trim();
    this.subscribedSymbols.delete(cleanSym);

    const sse = this.sseSources.get(cleanSym);
    if (sse) {
      sse.close();
      this.sseSources.delete(cleanSym);
    }
  }

  // Fetch OHLC Candlestick data with automatic HTTP 429 Retry-After handling & multi-tier fallbacks
  public async fetchOHLC(symbol: string, timeframe: string, limit = 200): Promise<BiquoteBar[]> {
    const cleanSym = symbol.toUpperCase().trim();
    
    // Map standard timeframe to Biquote interval
    const intervalMap: Record<string, string> = {
      "M1": "1m",
      "1M": "1m",
      "M5": "5m",
      "5M": "5m",
      "M15": "15m",
      "15M": "15m",
      "M30": "30m",
      "30M": "30m",
      "H1": "1h",
      "1H": "1h",
      "H4": "4h",
      "4H": "4h",
      "D1": "1d",
      "1D": "1d",
    };
    const interval = intervalMap[timeframe.toUpperCase()] || "15m";

    // Check if currently under 429 rate limit cooldown
    if (this.lastRateLimitRetryAfter > Date.now()) {
      const waitTimeMs = this.lastRateLimitRetryAfter - Date.now();
      await new Promise(r => setTimeout(r, Math.min(waitTimeMs, 2000)));
    }

    const parseBiquoteBars = (rawBars: any[]): BiquoteBar[] => {
      const formattedBars: BiquoteBar[] = rawBars
        .map((b: any) => {
          const timeSec = Math.floor(new Date(b.openTime || b.time || Date.now()).getTime() / 1000);
          return {
            openTime: b.openTime || new Date(timeSec * 1000).toISOString(),
            time: timeSec,
            open: Number(b.open),
            high: Number(b.high),
            low: Number(b.low),
            close: Number(b.close),
            volume: Number(b.volume || b.tickVolume || 0),
            tickVolume: Number(b.tickVolume || b.volume || 0),
            isOpen: b.isOpen,
          };
        })
        .filter((b: BiquoteBar) => !isNaN(b.time) && b.time > 0 && !isNaN(b.close))
        .sort((a: BiquoteBar, b: BiquoteBar) => a.time - b.time);

      const uniqueBars: BiquoteBar[] = [];
      for (const bar of formattedBars) {
        if (uniqueBars.length === 0 || uniqueBars[uniqueBars.length - 1].time !== bar.time) {
          uniqueBars.push(bar);
        } else {
          uniqueBars[uniqueBars.length - 1] = bar;
        }
      }
      return uniqueBars;
    };

    // Tier 1: Server proxy for Biquote OHLC (Avoids browser CORS & negotiation blocks)
    try {
      const proxyUrl = `/api/biquote/ohlc?symbol=${cleanSym}&interval=${interval}&limit=${limit}`;
      const res = await fetch(proxyUrl, { headers: { "Accept": "application/json" } });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data?.bars) && data.bars.length > 0) {
          return parseBiquoteBars(data.bars);
        }
      }
    } catch {}

    // Tier 2: Dedicated Klines proxy (Binance / Coinbase / TradingView feed)
    try {
      const klinesUrl = `/api/klines?symbol=${cleanSym}&interval=${interval}&limit=${limit}`;
      const res = await fetch(klinesUrl, { headers: { "Accept": "application/json" } });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          const convertedBars: BiquoteBar[] = data.map((k: any) => {
            const timeMs = Number(k[0]);
            const timeSec = Math.floor(timeMs / 1000);
            return {
              openTime: new Date(timeMs).toISOString(),
              time: timeSec,
              open: Number(k[1]),
              high: Number(k[2]),
              low: Number(k[3]),
              close: Number(k[4]),
              volume: Number(k[5] || 0),
              tickVolume: Number(k[5] || 0),
              isOpen: false,
            };
          }).filter((b: BiquoteBar) => !isNaN(b.time) && b.time > 0 && !isNaN(b.close));

          if (convertedBars.length > 0) {
            return convertedBars;
          }
        }
      }
    } catch {}

    // Tier 3: Direct API call if available
    try {
      const directUrl = `https://api.biquote.io/api/${cleanSym}/ohlc?interval=${interval}&limit=${limit}`;
      const res = await fetch(directUrl, { headers: { "Accept": "application/json" } });
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data?.bars) && data.bars.length > 0) {
          return parseBiquoteBars(data.bars);
        }
      }
    } catch {}

    return [];
  }
}

export const biquoteClient = new BiquoteClient();
