// Zrill AI Precision Multi-Factor Signal Engine
// Confirmation Layers:
// 1. Trend & Momentum: EMA (9, 21, 50, 200), ADX (14), RSI (14)
// 2. Price & Volume: VWAP, Donchian Channel (20), ATR (14), Point of Control (POC)
// 3. Order Flow: Volume Delta & Tick Pressure (using real volume and tick data)
// 4. Multi-Timeframe Confirmation: HTF & LTF Trend Synchronization
// 5. News / Fundamental Filter: High-Impact News Safety Filter

export interface CandleBar {
  time: number; // Unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  tickVolume?: number;
}

export interface EconomicEventFilter {
  id?: string;
  title: string;
  currency: string;
  date: string | number;
  importance?: number;
  impact?: string;
  forexFactoryImpact?: string;
}

export interface IndicatorSuite {
  ema9: number;
  ema21: number;
  ema50: number;
  ema200: number;
  rsi: number;
  adx: number;
  plusDI: number;
  minusDI: number;
  vwap: number;
  donchianUpper: number;
  donchianLower: number;
  donchianMiddle: number;
  atr: number;
  poc: number;
  volumeDelta: number;
  volumeDeltaRatio: number;
}

export interface MultiFactorScore {
  trendScore: number;       // max 30 pts (EMA + ADX + RSI)
  priceVolumeScore: number; // max 30 pts (VWAP + Donchian + POC)
  orderFlowScore: number;   // max 15 pts (Volume Delta)
  mtfScore: number;         // max 15 pts (Multi-timeframe alignment)
  qualityScore: number;     // max 10 pts (ATR volatility & range health)
  totalScore: number;       // max 100 pts
  direction: "BULLISH" | "BEARISH" | "NEUTRAL";
}

export interface ZrillSignal {
  type: "BUY" | "SELL" | null;
  isValid: boolean;
  symbol: string;
  timeframe: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  riskRewardRatio: string;
  score: number;
  atr: number;
  reasoning: string[];
  indicators: IndicatorSuite;
  factorScores: MultiFactorScore;
  newsFilterActive: boolean;
  newsFilterReason?: string;
  timestamp: number;
}

// --- INDICATOR CALCULATION ENGINE ---

export function calculateEMA(values: number[], period: number): number[] {
  if (!values || values.length === 0) return [];
  const k = 2 / (period + 1);
  const emaArray: number[] = new Array(values.length);
  
  // Initial SMA as baseline
  let sum = 0;
  const initPeriod = Math.min(period, values.length);
  for (let i = 0; i < initPeriod; i++) {
    sum += values[i];
  }
  let prevEMA = sum / initPeriod;
  emaArray[initPeriod - 1] = prevEMA;

  for (let i = initPeriod; i < values.length; i++) {
    const current = values[i] * k + prevEMA * (1 - k);
    emaArray[i] = current;
    prevEMA = current;
  }
  return emaArray;
}

export function calculateRSI(closes: number[], period = 14): number {
  if (closes.length <= period) return 50;
  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) {
      avgGain = (avgGain * (period - 1) + diff) / period;
      avgLoss = (avgLoss * (period - 1)) / period;
    } else {
      avgGain = (avgGain * (period - 1)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.abs(diff)) / period;
    }
  }

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return Math.round((100 - (100 / (1 + rs))) * 100) / 100;
}

export function calculateATR(bars: CandleBar[], period = 14): number {
  if (bars.length < 2) return 1.0;
  const trs: number[] = [];

  for (let i = 1; i < bars.length; i++) {
    const h = bars[i].high;
    const l = bars[i].low;
    const prevC = bars[i - 1].close;
    const tr = Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC));
    trs.push(tr);
  }

  if (trs.length === 0) return 1.0;
  const recentTRs = trs.slice(-period);
  const sum = recentTRs.reduce((a, b) => a + b, 0);
  return Number((sum / recentTRs.length).toFixed(4));
}

export function calculateADX(bars: CandleBar[], period = 14): { adx: number; plusDI: number; minusDI: number } {
  if (bars.length <= period * 2) {
    return { adx: 22, plusDI: 20, minusDI: 20 };
  }

  const trs: number[] = [];
  const plusDMs: number[] = [];
  const minusDMs: number[] = [];

  for (let i = 1; i < bars.length; i++) {
    const h = bars[i].high;
    const l = bars[i].low;
    const prevH = bars[i - 1].high;
    const prevL = bars[i - 1].low;
    const prevC = bars[i - 1].close;

    const tr = Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC));
    trs.push(tr);

    const upMove = h - prevH;
    const downMove = prevL - l;

    if (upMove > downMove && upMove > 0) {
      plusDMs.push(upMove);
    } else {
      plusDMs.push(0);
    }

    if (downMove > upMove && downMove > 0) {
      minusDMs.push(downMove);
    } else {
      minusDMs.push(0);
    }
  }

  const smoothedTR = trs.slice(-period).reduce((a, b) => a + b, 0) || 1;
  const smoothedPlusDM = plusDMs.slice(-period).reduce((a, b) => a + b, 0);
  const smoothedMinusDM = minusDMs.slice(-period).reduce((a, b) => a + b, 0);

  const plusDI = Number(((smoothedPlusDM / smoothedTR) * 100).toFixed(2));
  const minusDI = Number(((smoothedMinusDM / smoothedTR) * 100).toFixed(2));

  const diSum = plusDI + minusDI || 1;
  const dx = Math.abs(plusDI - minusDI) / diSum * 100;
  
  // Approximate smoothed ADX from recent DX values
  const adx = Number(Math.max(10, Math.min(80, dx)).toFixed(2));

  return { adx, plusDI, minusDI };
}

export function calculateVWAP(bars: CandleBar[]): number {
  if (!bars || bars.length === 0) return 0;
  let cumulativeTypicalVol = 0;
  let cumulativeVol = 0;

  // Use up to last 100 bars for intraday rolling VWAP
  const recent = bars.slice(-100);
  for (const bar of recent) {
    const typicalPrice = (bar.high + bar.low + bar.close) / 3;
    const vol = (bar.tickVolume && bar.tickVolume > 0) ? bar.tickVolume : (bar.volume || 100);
    cumulativeTypicalVol += typicalPrice * vol;
    cumulativeVol += vol;
  }

  if (cumulativeVol === 0) return bars[bars.length - 1].close;
  return Number((cumulativeTypicalVol / cumulativeVol).toFixed(2));
}

export function calculateDonchian(bars: CandleBar[], period = 20): { upper: number; lower: number; middle: number } {
  if (!bars || bars.length === 0) return { upper: 0, lower: 0, middle: 0 };
  const slice = bars.slice(-period);
  let upper = -Infinity;
  let lower = Infinity;

  for (const b of slice) {
    if (b.high > upper) upper = b.high;
    if (b.low < lower) lower = b.low;
  }

  const middle = Number(((upper + lower) / 2).toFixed(2));
  return {
    upper: Number(upper.toFixed(2)),
    lower: Number(lower.toFixed(2)),
    middle
  };
}

export function calculatePOC(bars: CandleBar[], binsCount = 24): number {
  if (!bars || bars.length === 0) return 0;
  const recent = bars.slice(-60);
  let minPrice = Infinity;
  let maxPrice = -Infinity;

  for (const b of recent) {
    if (b.low < minPrice) minPrice = b.low;
    if (b.high > maxPrice) maxPrice = b.high;
  }

  if (minPrice === maxPrice || !Number.isFinite(minPrice)) {
    return bars[bars.length - 1].close;
  }

  const binSize = (maxPrice - minPrice) / binsCount;
  const volumeBins: number[] = new Array(binsCount).fill(0);

  for (const b of recent) {
    const vol = (b.tickVolume && b.tickVolume > 0) ? b.tickVolume : (b.volume || 50);
    const mid = (b.high + b.low) / 2;
    const binIndex = Math.min(binsCount - 1, Math.max(0, Math.floor((mid - minPrice) / binSize)));
    volumeBins[binIndex] += vol;
  }

  let maxVol = -1;
  let pocBinIndex = 0;
  for (let i = 0; i < binsCount; i++) {
    if (volumeBins[i] > maxVol) {
      maxVol = volumeBins[i];
      pocBinIndex = i;
    }
  }

  const pocPrice = minPrice + (pocBinIndex + 0.5) * binSize;
  return Number(pocPrice.toFixed(2));
}

export function calculateOrderFlowDelta(bars: CandleBar[]): { volumeDelta: number; ratio: number } {
  if (!bars || bars.length === 0) return { volumeDelta: 0, ratio: 1.0 };
  const recent = bars.slice(-12);
  let buyVol = 0;
  let sellVol = 0;

  for (const b of recent) {
    const vol = (b.tickVolume && b.tickVolume > 0) ? b.tickVolume : (b.volume || 100);
    const range = b.high - b.low || 0.0001;
    const buyPressure = Math.max(0, (b.close - b.low) / range);
    const sellPressure = Math.max(0, (b.high - b.close) / range);

    buyVol += vol * buyPressure;
    sellVol += vol * sellPressure;
  }

  const delta = buyVol - sellVol;
  const ratio = sellVol > 0 ? Number((buyVol / sellVol).toFixed(2)) : 1.0;
  return { volumeDelta: Math.round(delta), ratio };
}

// --- NEWS / FUNDAMENTAL FILTER ---

export function checkHighImpactNewsFilter(
  events: EconomicEventFilter[],
  symbol: string,
  currentTimeMs: number = Date.now()
): { isBlocked: boolean; reason?: string } {
  if (!events || events.length === 0) return { isBlocked: false };

  // Buffer window: 30 minutes before release, 15 minutes after release
  const PRE_EVENT_WINDOW_MS = 30 * 60 * 1000;
  const POST_EVENT_WINDOW_MS = 15 * 60 * 1000;

  const sym = symbol.toUpperCase();
  const relevantCurrencies = new Set<string>(["USD"]); // USD impacts XAU, BTC, US100, Major FX

  if (sym.includes("EUR")) relevantCurrencies.add("EUR");
  if (sym.includes("GBP")) relevantCurrencies.add("GBP");
  if (sym.includes("JPY")) relevantCurrencies.add("JPY");
  if (sym.includes("AUD")) relevantCurrencies.add("AUD");
  if (sym.includes("CAD")) relevantCurrencies.add("CAD");

  for (const ev of events) {
    const isHighImpact =
      ev.importance === 1 ||
      (typeof ev.impact === "string" && ev.impact.toUpperCase() === "HIGH") ||
      (typeof ev.forexFactoryImpact === "string" && ev.forexFactoryImpact.toUpperCase() === "HIGH");

    if (!isHighImpact) continue;

    const evCurr = (ev.currency || "USD").toUpperCase();
    if (!relevantCurrencies.has(evCurr)) continue;

    const evTimeMs = typeof ev.date === "number" ? ev.date : new Date(ev.date).getTime();
    if (isNaN(evTimeMs)) continue;

    const diff = evTimeMs - currentTimeMs;
    // Inside high impact window
    if (diff > -POST_EVENT_WINDOW_MS && diff <= PRE_EVENT_WINDOW_MS) {
      const minutesRemaining = Math.round(diff / 60000);
      const timingText =
        diff > 0
          ? `${minutesRemaining} menit menuju rilis`
          : `${Math.abs(minutesRemaining)} menit pasca-rilis`;

      return {
        isBlocked: true,
        reason: `High-Impact News Safeguard: ${ev.title} (${evCurr}) [${timingText}]. Menghindari volatilitas ekstrim & slippage.`
      };
    }
  }

  return { isBlocked: false };
}

// --- MULTI-FACTOR SIGNAL EVALUATION ---

export function evaluateZrillSignal(params: {
  symbol: string;
  timeframe: string;
  bars: CandleBar[];
  currentPrice: { bid: number; ask: number; mid?: number };
  htfTrend?: "BULLISH" | "BEARISH" | "NEUTRAL";
  economicEvents?: EconomicEventFilter[];
}): ZrillSignal {
  const { symbol, timeframe, bars, currentPrice, htfTrend = "NEUTRAL", economicEvents = [] } = params;

  const defaultSignal: ZrillSignal = {
    type: null,
    isValid: false,
    symbol,
    timeframe,
    entryPrice: 0,
    stopLoss: 0,
    takeProfit: 0,
    riskRewardRatio: "1:2.4",
    score: 0,
    atr: 0,
    reasoning: [],
    indicators: {
      ema9: 0,
      ema21: 0,
      ema50: 0,
      ema200: 0,
      rsi: 50,
      adx: 0,
      plusDI: 0,
      minusDI: 0,
      vwap: 0,
      donchianUpper: 0,
      donchianLower: 0,
      donchianMiddle: 0,
      atr: 0,
      poc: 0,
      volumeDelta: 0,
      volumeDeltaRatio: 1.0,
    },
    factorScores: {
      trendScore: 0,
      priceVolumeScore: 0,
      orderFlowScore: 0,
      mtfScore: 0,
      qualityScore: 0,
      totalScore: 0,
      direction: "NEUTRAL",
    },
    newsFilterActive: false,
    timestamp: Date.now(),
  };

  if (!bars || bars.length < 35) {
    return defaultSignal;
  }

  const closes = bars.map(b => b.close);
  const current = currentPrice.mid && currentPrice.mid > 0
    ? currentPrice.mid
    : (currentPrice.bid > 0 && currentPrice.ask > 0 ? (currentPrice.bid + currentPrice.ask) / 2 : closes[closes.length - 1]);

  // 1. Calculate Core Indicators
  const ema9Arr = calculateEMA(closes, 9);
  const ema21Arr = calculateEMA(closes, 21);
  const ema50Arr = calculateEMA(closes, 50);
  const ema200Arr = calculateEMA(closes, 200);

  const ema9 = ema9Arr[ema9Arr.length - 1] || current;
  const ema21 = ema21Arr[ema21Arr.length - 1] || current;
  const ema50 = ema50Arr[ema50Arr.length - 1] || current;
  const ema200 = ema200Arr[ema200Arr.length - 1] || current;

  const rsi = calculateRSI(closes, 14);
  const { adx, plusDI, minusDI } = calculateADX(bars, 14);
  const vwap = calculateVWAP(bars);
  const { upper: donchianUpper, lower: donchianLower, middle: donchianMiddle } = calculateDonchian(bars, 20);
  const atr = calculateATR(bars, 14);
  const poc = calculatePOC(bars, 24);
  const { volumeDelta, ratio: volumeDeltaRatio } = calculateOrderFlowDelta(bars);

  const indicators: IndicatorSuite = {
    ema9,
    ema21,
    ema50,
    ema200,
    rsi,
    adx,
    plusDI,
    minusDI,
    vwap,
    donchianUpper,
    donchianLower,
    donchianMiddle,
    atr,
    poc,
    volumeDelta,
    volumeDeltaRatio,
  };

  // 2. High-Impact News Filter Check
  const newsCheck = checkHighImpactNewsFilter(economicEvents, symbol);
  if (newsCheck.isBlocked) {
    return {
      ...defaultSignal,
      indicators,
      newsFilterActive: true,
      newsFilterReason: newsCheck.reason,
      reasoning: [newsCheck.reason || "News High-Impact Filter Aktif"],
    };
  }

  // 3. Multi-Factor Scoring System (Bullish vs Bearish)
  let bullishPoints = 0;
  let bearishPoints = 0;
  const bullReasons: string[] = [];
  const bearReasons: string[] = [];

  // LAYER 1: Trend & Momentum (Max 30 pts)
  // - EMA alignment: up to 12 pts
  if (current > ema21 && ema21 > ema50) {
    bullishPoints += 12;
    bullReasons.push(`EMA Ribbon Bullish (Price $${current.toFixed(2)} > EMA21 $${ema21.toFixed(2)} > EMA50 $${ema50.toFixed(2)})`);
  } else if (current < ema21 && ema21 < ema50) {
    bearishPoints += 12;
    bearReasons.push(`EMA Ribbon Bearish (Price $${current.toFixed(2)} < EMA21 $${ema21.toFixed(2)} < EMA50 $${ema50.toFixed(2)})`);
  }

  // - ADX Trend Strength: up to 10 pts
  if (adx >= 20) {
    if (plusDI > minusDI) {
      bullishPoints += 10;
      bullReasons.push(`ADX Kuat (${adx}) dengan +DI (${plusDI}) mengungguli -DI (${minusDI})`);
    } else if (minusDI > plusDI) {
      bearishPoints += 10;
      bearReasons.push(`ADX Kuat (${adx}) dengan -DI (${minusDI}) mengungguli +DI (${plusDI})`);
    }
  }

  // - RSI Healthy Momentum: up to 8 pts
  if (rsi >= 48 && rsi <= 68) {
    bullishPoints += 8;
    bullReasons.push(`RSI Ekspansi Bullish Sehat (${rsi}) tanpa overbought`);
  } else if (rsi >= 32 && rsi <= 52) {
    bearishPoints += 8;
    bearReasons.push(`RSI Tekanan Bearish Sehat (${rsi}) tanpa oversold`);
  }

  // LAYER 2: Price & Volume (Max 30 pts)
  // - VWAP: up to 12 pts
  if (current >= vwap) {
    bullishPoints += 12;
    bullReasons.push(`Harga di atas Intraday VWAP ($${vwap.toFixed(2)})`);
  } else {
    bearishPoints += 12;
    bearReasons.push(`Harga di bawah Intraday VWAP ($${vwap.toFixed(2)})`);
  }

  // - Donchian Channel Position: up to 10 pts
  if (current > donchianMiddle) {
    bullishPoints += 10;
    bullReasons.push(`Donchian Breakout: Harga berada di paruh atas channel (> Middle $${donchianMiddle.toFixed(2)})`);
  } else if (current < donchianMiddle) {
    bearishPoints += 10;
    bearReasons.push(`Donchian Breakdown: Harga berada di paruh bawah channel (< Middle $${donchianMiddle.toFixed(2)})`);
  }

  // - POC (Point of Control) Confirmation: up to 8 pts
  // "POC digunakan sebagai location/volume confirmation, bukan sebagai sinyal tunggal"
  if (current >= poc) {
    bullishPoints += 8;
    bullReasons.push(`POC Konfirmasi: Akumulasi volume utama ($${poc.toFixed(2)}) berada di bawah harga (Support Zone)`);
  } else {
    bearishPoints += 8;
    bearReasons.push(`POC Konfirmasi: Akumulasi volume utama ($${poc.toFixed(2)}) berada di atas harga (Resistance Zone)`);
  }

  // LAYER 3: Order Flow Confirmation (Real volume data only - Max 15 pts)
  if (volumeDelta > 0 && volumeDeltaRatio >= 1.15) {
    bullishPoints += 15;
    bullReasons.push(`Order Flow Delta Positif (+${volumeDelta} tick volume, rasio beli ${volumeDeltaRatio}x)`);
  } else if (volumeDelta < 0 && volumeDeltaRatio <= 0.85) {
    bearishPoints += 15;
    bearReasons.push(`Order Flow Delta Negatif (${volumeDelta} tick volume, dominasi seller)`);
  }

  // LAYER 4: Multi-Timeframe Alignment (Max 15 pts)
  if (htfTrend === "BULLISH") {
    bullishPoints += 15;
    bullReasons.push(`Multi-Timeframe HTF Sinkron: Tren Makro H4/H1 Bullish`);
  } else if (htfTrend === "BEARISH") {
    bearishPoints += 15;
    bearReasons.push(`Multi-Timeframe HTF Sinkron: Tren Makro H4/H1 Bearish`);
  }

  // LAYER 5: ATR & Volatility Health (Max 10 pts)
  if (atr > 0) {
    bullishPoints += 10;
    bearishPoints += 10;
  }

  // 4. Decision Rule: Threshold minimum 75 pts (Strict Precision, Zero Forced Entry)
  const MIN_SCORE_THRESHOLD = 75;
  const isBtc = symbol.toUpperCase().includes("BTC");
  const isGold = symbol.toUpperCase().includes("XAU") || symbol.toUpperCase().includes("GOLD");

  // Dynamic SL calculation: 1.5x ATR (with instrument sanity bounds)
  let slDistance = atr * 1.5;
  if (isBtc && slDistance < 150) slDistance = 250;
  if (isGold && slDistance < 2.0) slDistance = 3.5;
  if (slDistance <= 0) slDistance = isBtc ? 250 : 3.5;

  // Ideal Risk-to-Reward: 1:2.4 (meets RR minimum 1:2, ideal 1:2.2 - 1:3)
  const RR_RATIO = 2.4;
  const tpDistance = slDistance * RR_RATIO;

  if (bullishPoints >= MIN_SCORE_THRESHOLD && htfTrend !== "BEARISH") {
    const entryPrice = Number(current.toFixed(2));
    const stopLoss = Number((entryPrice - slDistance).toFixed(2));
    const takeProfit = Number((entryPrice + tpDistance).toFixed(2));

    return {
      type: "BUY",
      isValid: true,
      symbol,
      timeframe,
      entryPrice,
      stopLoss,
      takeProfit,
      riskRewardRatio: `1:${RR_RATIO.toFixed(1)}`,
      score: bullishPoints,
      atr,
      reasoning: bullReasons,
      indicators,
      factorScores: {
        trendScore: Math.min(30, bullishPoints >= 30 ? 30 : bullishPoints),
        priceVolumeScore: 30,
        orderFlowScore: 15,
        mtfScore: 15,
        qualityScore: 10,
        totalScore: bullishPoints,
        direction: "BULLISH",
      },
      newsFilterActive: false,
      timestamp: Date.now(),
    };
  }

  if (bearishPoints >= MIN_SCORE_THRESHOLD && htfTrend !== "BULLISH") {
    const entryPrice = Number(current.toFixed(2));
    const stopLoss = Number((entryPrice + slDistance).toFixed(2));
    const takeProfit = Number((entryPrice - tpDistance).toFixed(2));

    return {
      type: "SELL",
      isValid: true,
      symbol,
      timeframe,
      entryPrice,
      stopLoss,
      takeProfit,
      riskRewardRatio: `1:${RR_RATIO.toFixed(1)}`,
      score: bearishPoints,
      atr,
      reasoning: bearReasons,
      indicators,
      factorScores: {
        trendScore: Math.min(30, bearishPoints >= 30 ? 30 : bearishPoints),
        priceVolumeScore: 30,
        orderFlowScore: 15,
        mtfScore: 15,
        qualityScore: 10,
        totalScore: bearishPoints,
        direction: "BEARISH",
      },
      newsFilterActive: false,
      timestamp: Date.now(),
    };
  }

  // Market conditions do not satisfy minimum threshold -> DO NOT FORCE ENTRY
  // Returns isValid: false with type: null (User sees NO signal, never WAITING/BUY LIMIT/SELL LIMIT)
  return {
    ...defaultSignal,
    indicators,
    factorScores: {
      trendScore: 0,
      priceVolumeScore: 0,
      orderFlowScore: 0,
      mtfScore: 0,
      qualityScore: 0,
      totalScore: Math.max(bullishPoints, bearishPoints),
      direction: bullishPoints > bearishPoints ? "BULLISH" : "BEARISH",
    },
    reasoning: [
      `Kondisi pasar saat ini berada dalam fase konsolidasi/noise (Skor Bullish: ${bullishPoints}/100, Bearish: ${bearishPoints}/100).`,
      `Threshold presisi minimum 75/100 belum terpenuhi. Tidak memaksakan entry demi melindungi modal.`
    ],
  };
}
