// Standalone Biquote Candlestick Chart (Replacing TradingView completely)
import React, { memo } from "react";
import { StandaloneChart, StandaloneChartProps } from "./StandaloneChart";

export interface TradingViewChartProps {
  symbol: string;
  timeframe: string;
  theme?: "dark" | "light";
  height?: number | string;
  onSymbolChange?: (symbol: string) => void;
  onTimeframeChange?: (timeframe: string) => void;
  onPriceUpdate?: (price: { bid: number; ask: number; mid: number; timestamp: number | string }) => void;
  onCandlesUpdate?: (bars: any[]) => void;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = memo(({
  symbol,
  timeframe,
  height = "100%",
  onSymbolChange,
  onTimeframeChange,
  onPriceUpdate,
  onCandlesUpdate,
}) => {
  return (
    <StandaloneChart
      symbol={symbol}
      timeframe={timeframe}
      height={height}
      onSymbolChange={onSymbolChange}
      onTimeframeChange={onTimeframeChange}
      onPriceUpdate={onPriceUpdate}
      onCandlesUpdate={onCandlesUpdate}
    />
  );
});

TradingViewChart.displayName = "TradingViewChart";
