<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/6b124b9c-f81b-49b6-bfe7-e4ebb14cf123

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Configure the required market/news data connections if your deployment uses them. The native reasoning engine itself does not require an AI API key.
3. Run the app:
   `npm run dev`

## TradingView MCP

The current architecture supports the official TradingView MCP endpoint as a secondary validation/data source. The realtime WebSocket remains the primary market feed. See `TRADINGVIEW_MCP_INTEGRATION.md`.
