# Zrill Adaptive Reasoning

The native reasoning engine uses a bounded online-learning loop:
1. Build independent BUY and SELL hypotheses from structure, displacement, liquidity, location, MTF and fundamental context.
2. Compare hypotheses and run an adversarial counter-check against the opposite side.
3. Refuse a directional decision when evidence is insufficient.
4. Store the setup fingerprint and realized outcome.
5. Update global feature weights and contextual weights keyed by `side + market regime`.
6. Reuse those learned priors on later observations with bounded influence.

This is adaptive software reasoning, not model retraining and not a copy of GPT. It does not invent outcomes or silently label unresolved trades as wins/losses.
