# TradingView MCP integration

Zrill uses the official TradingView MCP as a secondary historical/validation source. The existing TradingView WebSocket remains the primary low-latency market feed.

Official endpoint: `https://mcp.tradingview.com/mcp`

The official service uses OAuth 2.1. For a server deployment, provide an authorized access token through `TV_MCP_ACCESS_TOKEN` using the deployment secret manager. Do not put tokens in frontend code, Git, prompts, or JSON state files.

## Data flow

- WebSocket -> realtime ticks -> signal engine
- MCP -> OHLCV / technical / macro validation -> reasoning and signal validation

MCP is intentionally not used as a tick stream. TradingView documents a tool rate limit of about 100 requests/minute/user, so Zrill should use MCP for historical bars, independent validation, news/economic context, and recovery.

## Routes

- `GET /api/mcp/status`
- `GET /api/mcp/tools`
- `POST /api/mcp/execute`
- `GET /api/mcp/ohlcv?symbol=OANDA:XAUUSD&interval=1m&count=180`
