import fs from "fs";
import path from "path";

export interface CandlePoint {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export type ZoneType =
  | "BULLISH_OB"
  | "BEARISH_OB"
  | "BULLISH_FVG"
  | "BEARISH_FVG"
  | "STRONG_OB_AND_FVG_CONFLUENCE"
  | "BULLISH_IFVG"
  | "BEARISH_IFVG";

export type ZoneCategory = "ORDER_BLOCK" | "FVG" | "CONFLUENCE" | "IFVG";
export type ZoneDirection = "BUY" | "SELL";
export type ZoneStatus = "ACTIVE_PENDING" | "TESTING_ENTRY" | "CONFIRMED_ENTRY" | "MITIGATED" | "INVALIDATED";

export interface TrackedZone {
  id: string;
  symbol: string;
  timeframe: string; // e.g. "M15", "M5", "H1", "H4"
  type: ZoneType;
  category: ZoneCategory;
  direction: ZoneDirection;
  low: number;
  high: number;
  equilibrium: number;
  entryPrice: number;
  sl: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: number; // e.g. 2.2
  status: ZoneStatus;
  isFresh: boolean;
  mitigationCount: number;
  displacementScore: number;
  formationCandleTime: number;
  createdAt: number;
  updatedAt: number;
  lastTestPrice?: number;
  description: string;
}

export interface ZoneDetectionInput {
  symbol: string;
  timeframe: string;
  type: ZoneType;
  category: ZoneCategory;
  direction: ZoneDirection;
  low: number;
  high: number;
  equilibrium: number;
  displacementScore: number;
  formationCandleTime: number;
  currentPrice: number;
  atr: number;
  description?: string;
  targetPrice?: number;
}

export class ZoneStateService {
  private zones: Map<string, TrackedZone> = new Map();
  private filePath: string;
  private saveDebounceTimer: NodeJS.Timeout | null = null;

  constructor(storageDir = path.join(process.cwd(), "data")) {
    try {
      fs.mkdirSync(storageDir, { recursive: true });
    } catch {
      // Ignore if exists
    }
    this.filePath = path.join(storageDir, "zrill-zone-state.json");
    this.load();
  }

  /**
   * Load stored zone states from JSON
   */
  public load(): void {
    try {
      if (fs.existsSync(this.filePath)) {
        const raw = fs.readFileSync(this.filePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          this.zones.clear();
          for (const item of parsed) {
            if (item && item.id) {
              this.zones.set(item.id, item);
            }
          }
        }
      }
    } catch (err) {
      console.warn("[ZoneStateService] Failed to load zone state file:", err);
    }
  }

  /**
   * Persist zone states to disk
   */
  public save(): void {
    if (this.saveDebounceTimer) return;
    this.saveDebounceTimer = setTimeout(() => {
      this.saveDebounceTimer = null;
      try {
        const list = Array.from(this.zones.values());
        fs.writeFileSync(this.filePath, JSON.stringify(list, null, 2));
      } catch (err) {
        console.warn("[ZoneStateService] Failed to write zone state:", err);
      }
    }, 200);
  }

  /**
   * Generate deterministic unique ID for a zone
   */
  private generateId(symbol: string, tf: string, type: string, low: number, high: number): string {
    return `${symbol.toUpperCase()}_${tf}_${type}_${low.toFixed(2)}_${high.toFixed(2)}`;
  }

  /**
   * Upsert or update a detected Fresh OB / FVG into tracked state
   */
  public registerOrUpdateZone(input: ZoneDetectionInput): TrackedZone {
    const id = this.generateId(input.symbol, input.timeframe, input.type, input.low, input.high);
    const existing = this.zones.get(id);

    const now = Date.now();
    const buffer = Math.max(input.atr * 0.15, 0.20);
    const sl = input.direction === "BUY"
      ? Number((input.low - buffer).toFixed(2))
      : Number((input.high + buffer).toFixed(2));

    const risk = Math.max(Math.abs(input.equilibrium - sl), input.atr * 0.25);
    const target = input.targetPrice && input.targetPrice > 0
      ? input.targetPrice
      : (input.direction === "BUY" ? input.equilibrium + risk * 2.3 : input.equilibrium - risk * 2.3);

    const rr = Number((Math.abs(target - input.equilibrium) / risk).toFixed(1));
    const tp1 = Number((input.direction === "BUY" ? input.equilibrium + risk * 1.5 : input.equilibrium - risk * 1.5).toFixed(2));
    const tp2 = Number((input.direction === "BUY" ? input.equilibrium + risk * 2.2 : input.equilibrium - risk * 2.2).toFixed(2));
    const tp3 = Number((input.direction === "BUY" ? input.equilibrium + risk * 3.0 : input.equilibrium - risk * 3.0).toFixed(2));

    // Determine initial status based on live currentPrice
    let status: ZoneStatus = "ACTIVE_PENDING";
    if (input.currentPrice >= input.low && input.currentPrice <= input.high) {
      status = "TESTING_ENTRY";
    }

    if (existing) {
      existing.updatedAt = now;
      existing.lastTestPrice = input.currentPrice;
      existing.displacementScore = Math.max(existing.displacementScore, input.displacementScore);
      if (status === "TESTING_ENTRY" && existing.status === "ACTIVE_PENDING") {
        existing.status = "TESTING_ENTRY";
        existing.mitigationCount = (existing.mitigationCount || 0) + 1;
      }
      this.save();
      return existing;
    }

    const newZone: TrackedZone = {
      id,
      symbol: input.symbol.toUpperCase(),
      timeframe: input.timeframe,
      type: input.type,
      category: input.category,
      direction: input.direction,
      low: Number(input.low.toFixed(2)),
      high: Number(input.high.toFixed(2)),
      equilibrium: Number(input.equilibrium.toFixed(2)),
      entryPrice: Number(input.equilibrium.toFixed(2)),
      sl,
      tp1,
      tp2,
      tp3,
      rr: Math.max(2.0, rr),
      status,
      isFresh: true,
      mitigationCount: status === "TESTING_ENTRY" ? 1 : 0,
      displacementScore: Number(input.displacementScore.toFixed(2)),
      formationCandleTime: input.formationCandleTime,
      createdAt: now,
      updatedAt: now,
      lastTestPrice: input.currentPrice,
      description: input.description || `${input.type} at ${input.low.toFixed(2)} - ${input.high.toFixed(2)}`,
    };

    this.zones.set(id, newZone);
    this.save();
    return newZone;
  }

  /**
   * Update active zones with live tick/candle prices (checks mitigation / invalidation)
   */
  public updateWithPrice(symbol: string, currentPrice: number): void {
    const sym = symbol.toUpperCase();
    let changed = false;

    for (const zone of this.zones.values()) {
      if (zone.symbol !== sym || zone.status === "INVALIDATED") continue;

      // Invalidation check
      if (zone.direction === "BUY" && currentPrice < zone.sl) {
        zone.status = "INVALIDATED";
        zone.isFresh = false;
        zone.updatedAt = Date.now();
        changed = true;
        continue;
      }
      if (zone.direction === "SELL" && currentPrice > zone.sl) {
        zone.status = "INVALIDATED";
        zone.isFresh = false;
        zone.updatedAt = Date.now();
        changed = true;
        continue;
      }

      // Inside zone check (testing entry)
      if (currentPrice >= zone.low && currentPrice <= zone.high) {
        if (zone.status !== "TESTING_ENTRY" && zone.status !== "CONFIRMED_ENTRY") {
          zone.status = "TESTING_ENTRY";
          zone.mitigationCount = (zone.mitigationCount || 0) + 1;
          zone.updatedAt = Date.now();
          changed = true;
        }
      }
    }

    if (changed) {
      this.save();
    }
  }

  /**
   * Logic layer to detect Fair Value Gaps (FVG) by identifying imbalances
   * between successive candle closes and extremes, and register them into tracked state.
   */
  public detectAndRegisterFVGs(
    symbol: string,
    timeframe: string,
    candles: CandlePoint[],
    currentPrice: number,
    atr: number
  ): TrackedZone[] {
    if (!candles || candles.length < 15 || !atr) return [];
    const registered: TrackedZone[] = [];
    const maxLookback = Math.min(40, candles.length - 2);

    for (let i = candles.length - 2; i >= Math.max(1, candles.length - maxLookback); i--) {
      const c1 = candles[i - 1]; // Left candle
      const c2 = candles[i];     // Middle impulse candle
      const c3 = candles[i + 1]; // Right candle
      if (!c1 || !c2 || !c3) continue;

      // 1. Bullish FVG Imbalance:
      // - Gap between c1.high and c3.low
      // - Successive candle close imbalance: c2.close surged strongly above c1.close
      // - c3.close preserved above the gap floor
      if (c3.low > c1.high && c2.close > c2.open) {
        const gap = c3.low - c1.high;
        const closeImbalance = c2.close - c1.close;
        const minImbalance = atr * 0.18;

        if (gap >= atr * 0.10 && closeImbalance >= minImbalance) {
          const low = c1.high;
          const high = c3.low;
          const eq = Number(((low + high) / 2).toFixed(2));

          // Freshness validation: no subsequent closed candle pierced below low
          let isFresh = true;
          let testCount = 0;
          for (let j = i + 2; j < candles.length; j++) {
            if (candles[j].close < low) {
              isFresh = false;
              break;
            }
            if (candles[j].low <= high) {
              testCount++;
            }
          }

          if (isFresh && testCount <= 2) {
            const fvg = this.registerOrUpdateZone({
              symbol,
              timeframe,
              type: "BULLISH_FVG",
              category: "FVG",
              direction: "BUY",
              low,
              high,
              equilibrium: eq,
              displacementScore: Number((gap / atr + closeImbalance / atr).toFixed(2)),
              formationCandleTime: c2.time,
              currentPrice,
              atr,
              description: `Strong Bullish FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
            });
            registered.push(fvg);
          }
        }
      }

      // 2. Bearish FVG Imbalance:
      // - Gap between c3.high and c1.low
      // - Successive candle close imbalance: c2.close plummeted strongly below c1.close
      // - c3.close preserved below the gap ceiling
      if (c3.high < c1.low && c2.close < c2.open) {
        const gap = c1.low - c3.high;
        const closeImbalance = c1.close - c2.close;
        const minImbalance = atr * 0.18;

        if (gap >= atr * 0.10 && closeImbalance >= minImbalance) {
          const low = c3.high;
          const high = c1.low;
          const eq = Number(((low + high) / 2).toFixed(2));

          // Freshness validation: no subsequent closed candle pierced above high
          let isFresh = true;
          let testCount = 0;
          for (let j = i + 2; j < candles.length; j++) {
            if (candles[j].close > high) {
              isFresh = false;
              break;
            }
            if (candles[j].high >= low) {
              testCount++;
            }
          }

          if (isFresh && testCount <= 2) {
            const fvg = this.registerOrUpdateZone({
              symbol,
              timeframe,
              type: "BEARISH_FVG",
              category: "FVG",
              direction: "SELL",
              low,
              high,
              equilibrium: eq,
              displacementScore: Number((gap / atr + closeImbalance / atr).toFixed(2)),
              formationCandleTime: c2.time,
              currentPrice,
              atr,
              description: `Strong Bearish FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
            });
            registered.push(fvg);
          }
        }
      }
    }

    return registered;
  }

  /**
   * Get all active (non-invalidated) zones for a symbol
   */
  public getActiveZones(symbol: string, direction?: ZoneDirection): TrackedZone[] {
    const sym = symbol.toUpperCase();
    const result: TrackedZone[] = [];
    for (const z of this.zones.values()) {
      if (z.symbol === sym && z.status !== "INVALIDATED") {
        if (!direction || z.direction === direction) {
          result.push(z);
        }
      }
    }
    // Sort by freshness and displacement score
    return result.sort((a, b) => b.displacementScore - a.displacementScore || b.updatedAt - a.updatedAt);
  }

  /**
   * Find the nearest active Fresh OB or FVG to current price
   */
  public getNearestFreshZone(symbol: string, currentPrice: number, preferredDirection?: ZoneDirection): TrackedZone | null {
    const active = this.getActiveZones(symbol, preferredDirection);
    if (!active.length) {
      // If preferred direction had no zones, look at any active zone
      if (preferredDirection) {
        const anyActive = this.getActiveZones(symbol);
        if (anyActive.length) return this.pickClosest(anyActive, currentPrice);
      }
      return null;
    }
    return this.pickClosest(active, currentPrice);
  }

  private pickClosest(zones: TrackedZone[], currentPrice: number): TrackedZone {
    let closest = zones[0];
    let minDistance = Infinity;

    for (const z of zones) {
      // Distance from currentPrice to zone equilibrium or boundary
      const dist = currentPrice >= z.low && currentPrice <= z.high
        ? 0
        : Math.min(Math.abs(currentPrice - z.low), Math.abs(currentPrice - z.high));

      // Favor confluence and order blocks slightly
      const weight = z.category === "CONFLUENCE" ? 0.7 : z.category === "ORDER_BLOCK" ? 0.85 : 1.0;
      const weightedDist = dist * weight;

      if (weightedDist < minDistance) {
        minDistance = weightedDist;
        closest = z;
      }
    }

    return closest;
  }

  /**
   * Get all tracked zones across all symbols
   */
  public getAllZones(): TrackedZone[] {
    return Array.from(this.zones.values()).sort((a, b) => b.updatedAt - a.updatedAt);
  }

  /**
   * Clear out stale or invalidated zones older than 48 hours
   */
  public purgeOldZones(maxAgeMs = 48 * 60 * 60 * 1000): void {
    const cutoff = Date.now() - maxAgeMs;
    let purged = 0;
    for (const [id, zone] of this.zones.entries()) {
      if (zone.status === "INVALIDATED" && zone.updatedAt < cutoff) {
        this.zones.delete(id);
        purged++;
      }
    }
    if (purged > 0) {
      this.save();
    }
  }
}

export const zoneStateService = new ZoneStateService();
