import crypto from "crypto";

export type McpBar = { time: number; open: number; high: number; low: number; close: number; volume?: number };

type McpConfig = {
  url: string;
  accessToken?: string;
  timeoutMs: number;
};

type JsonRpcResponse = {
  result?: any;
  error?: { code?: number; message?: string; data?: any };
};

/**
 * Optional TradingView Official MCP adapter.
 * WebSocket remains the low-latency primary feed. MCP is used for historical
 * OHLCV and independent validation, never as a tick stream.
 *
 * Official endpoint: https://mcp.tradingview.com/mcp
 * Authentication is OAuth 2.1. For a server-side deployment, provide an
 * access token through TV_MCP_ACCESS_TOKEN after authenticating the MCP client.
 */
export class TradingViewMcpService {
  private readonly config: McpConfig;
  private sessionId: string | null = null;
  private requestId = 0;
  private initialized = false;
  private toolCache: any[] | null = null;

  constructor() {
    this.config = {
      url: process.env.TV_MCP_URL || "https://mcp.tradingview.com/mcp",
      accessToken: process.env.TV_MCP_ACCESS_TOKEN,
      timeoutMs: Number(process.env.TV_MCP_TIMEOUT_MS || 8000),
    };
  }

  isConfigured(): boolean {
    return Boolean(this.config.accessToken);
  }

  getStatus() {
    return {
      enabled: true,
      configured: this.isConfigured(),
      authenticated: Boolean(this.sessionId && this.initialized),
      url: this.config.url,
      mode: "SECONDARY_VALIDATION",
      primaryFeed: "TRADINGVIEW_WEBSOCKET",
    };
  }

  private async rpc(method: string, params: Record<string, any> = {}): Promise<any> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.config.timeoutMs);
    const headers: Record<string, string> = {
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
    };
    if (this.config.accessToken) headers.authorization = `Bearer ${this.config.accessToken}`;
    if (this.sessionId) headers["mcp-session-id"] = this.sessionId;

    const body = JSON.stringify({
      jsonrpc: "2.0",
      id: ++this.requestId,
      method,
      params,
    });

    try {
      const response = await fetch(this.config.url, {
        method: "POST",
        headers,
        body,
        signal: controller.signal,
      });
      const contentType = response.headers.get("content-type") || "";
      const session = response.headers.get("mcp-session-id");
      if (session) this.sessionId = session;

      const text = await response.text();
      if (!response.ok) throw new Error(`TradingView MCP HTTP ${response.status}: ${text.slice(0, 300)}`);

      const payload = this.parsePayload(text, contentType);
      if (payload?.error) throw new Error(payload.error.message || "TradingView MCP RPC error");
      return payload?.result ?? payload;
    } finally {
      clearTimeout(timer);
    }
  }

  private parsePayload(text: string, contentType: string): any {
    const trimmed = text.trim();
    if (!trimmed) return {};
    if (contentType.includes("text/event-stream") || trimmed.startsWith("event:") || trimmed.includes("\ndata:")) {
      const chunks = trimmed.split(/\n\n+/).reverse();
      for (const chunk of chunks) {
        const data = chunk.split(/\n/).filter(x => x.startsWith("data:")).map(x => x.slice(5).trim()).join("\n");
        if (!data || data === "[DONE]") continue;
        try { return JSON.parse(data); } catch { /* continue */ }
      }
    }
    try { return JSON.parse(trimmed); } catch {
      throw new Error(`TradingView MCP returned non-JSON data: ${trimmed.slice(0, 120)}`);
    }
  }

  private async ensureInitialized() {
    if (this.initialized) return;
    await this.rpc("initialize", {
      protocolVersion: "2025-06-18",
      capabilities: {},
      clientInfo: { name: "Zrill AI", version: "5.8-mcp" },
    });
    try { await this.rpc("notifications/initialized", {}); } catch { /* notification may not return a result */ }
    this.initialized = true;
  }

  async listTools(): Promise<any[]> {
    if (this.toolCache) return this.toolCache;
    await this.ensureInitialized();
    const result = await this.rpc("tools/list", {});
    this.toolCache = Array.isArray(result?.tools) ? result.tools : [];
    return this.toolCache;
  }

  async callTool(name: string, arguments_: Record<string, any> = {}): Promise<any> {
    await this.ensureInitialized();
    const result = await this.rpc("tools/call", { name, arguments: arguments_ });
    return result;
  }

  async getOhlcv(symbol: string, interval: string, count = 180): Promise<McpBar[]> {
    if (!this.isConfigured()) return [];
    const result = await this.callTool("get_ohlcv", { symbol, interval, count: Math.min(5000, Math.max(20, count)), summary: false });
    const content = Array.isArray(result?.content) ? result.content : [];
    const textBlock = content.find((x: any) => x?.type === "text")?.text;
    const raw = textBlock ? this.parseEmbeddedJson(textBlock) : result?.structuredContent ?? result;
    const bars = raw?.bars || raw?.data?.bars || raw?.result?.bars || raw?.ohlcv || [];
    if (!Array.isArray(bars)) return [];
    return bars.map((b: any) => ({
      time: Number(b.t ?? b.time ?? b.timestamp) * (Number(b.t ?? b.time ?? b.timestamp) < 1e12 ? 1000 : 1),
      open: Number(b.o ?? b.open), high: Number(b.h ?? b.high), low: Number(b.l ?? b.low), close: Number(b.c ?? b.close), volume: Number.isFinite(Number(b.v ?? b.volume)) ? Number(b.v ?? b.volume) : undefined,
    })).filter((b: McpBar) => b.time > 0 && [b.open,b.high,b.low,b.close].every(Number.isFinite));
  }

  private parseEmbeddedJson(text: string): any {
    try { return JSON.parse(text); } catch {}
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) {
      try { return JSON.parse(text.slice(start, end + 1)); } catch {}
    }
    return null;
  }

  fingerprintBars(bars: McpBar[]): string {
    return crypto.createHash("sha256").update(JSON.stringify(bars.slice(-10))).digest("hex").slice(0, 16);
  }
}

export const tradingViewMcp = new TradingViewMcpService();
