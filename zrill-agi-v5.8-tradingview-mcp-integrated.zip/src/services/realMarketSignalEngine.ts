import { zoneStateService, type TrackedZone } from "./zoneStateService.js";
import { freshOrderBlockService } from "./freshOrderBlockService.js";

export interface RealCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type RealSignal = "BUY" | "SELL" | "NO_VALID_SETUP" | "FEED_RECOVERY";
export type MarketRegime = "TREND_UP" | "TREND_DOWN" | "CONSOLIDATION" | "EXPANSION" | "RANGE" | "UNKNOWN";

export interface RealMarketAnalysis {
  status: "ACTIVE" | "NO_VALID_SETUP" | "FEED_RECOVERY";
  type: RealSignal;
  orderExecutionType: RealSignal;
  symbol: string;
  timeframe: string;
  entry: number;
  sl: number;
  tp: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: string;
  confluenceScore: number;
  confidence: number;
  qualityGrade: string;
  regime: MarketRegime;
  marketState: string;
  setupId: string | null;
  signalSource: "TRADINGVIEW";
  newsSource: "FOREX_FACTORY" | "UNAVAILABLE";
  diagnostic: Record<string, any>;
  rejectionReasons: string[];
  reasoning: string[];
  analysis: string;
  formattedOutputSignalText: string;
  confidenceType: "CONFLUENCE_SCORE";
  createdAt: number;
  creationCandleTime: number;
  zoneAreaType?: string;
}

const n = (v: number, d = 2) => Number(v.toFixed(d));
const finite = (v: any): v is number => typeof v === "number" && Number.isFinite(v);

function trueRanges(candles: RealCandle[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i], p = candles[i - 1];
    out.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
  }
  return out;
}

function atr(candles: RealCandle[], period = 14): number {
  if (candles.length < period + 1) return 0;
  const trs = trueRanges(candles).slice(-period);
  return trs.reduce((a, b) => a + b, 0) / trs.length;
}

function ema(candles: RealCandle[], period: number): number {
  if (candles.length < period) return 0;
  const k = 2 / (period + 1);
  let value = candles.slice(0, period).reduce((s, c) => s + c.close, 0) / period;
  for (let i = period; i < candles.length; i++) value = candles[i].close * k + value * (1 - k);
  return value;
}

function efficiency(candles: RealCandle[], period = 20): number {
  if (candles.length < period + 1) return 0;
  const s = candles.slice(-period - 1);
  const net = Math.abs(s.at(-1)!.close - s[0].close);
  let path = 0;
  for (let i = 1; i < s.length; i++) path += Math.abs(s[i].close - s[i - 1].close);
  return path > 0 ? net / path : 0;
}

function median(values: number[]): number {
  if (!values.length) return 0;
  const a = [...values].sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

interface RegimeResult {
  regime: MarketRegime;
  atr: number;
  efficiency: number;
  rangeWidth: number;
  rangeAtr: number;
  emaSlopeAtr: number;
}

function detectRegime(candles: RealCandle[]): RegimeResult {
  if (candles.length < 60) return { regime: "UNKNOWN", atr: 0, efficiency: 0, rangeWidth: 0, rangeAtr: 0, emaSlopeAtr: 0 };
  const a = atr(candles, 14);
  if (!a) return { regime: "UNKNOWN", atr: 0, efficiency: 0, rangeWidth: 0, rangeAtr: 0, emaSlopeAtr: 0 };
  const recent = candles.slice(-24);
  const rangeWidth = Math.max(...recent.map(c => c.high)) - Math.min(...recent.map(c => c.low));
  const medRange = median(candles.slice(-60).map(c => c.high - c.low).filter(Boolean));
  const e = efficiency(candles, 20);
  const e20 = ema(candles, 20);
  const e20Prev = ema(candles.slice(0, -6), 20);
  const e50 = ema(candles, 50);
  const emaSlopeAtr = Math.abs(e20 - e20Prev) / a;
  const rangeAtr = rangeWidth / a;
  const compression = medRange > 0 ? rangeWidth / (medRange * recent.length) : 99;

  const consolidation = e < 0.38 && rangeAtr <= 7.0 && emaSlopeAtr < 0.70 && compression < 2.8;
  if (consolidation) return { regime: "CONSOLIDATION", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (rangeAtr >= 7.0 && e >= 0.55) return { regime: "EXPANSION", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (e20 > e50 && emaSlopeAtr >= 0.25 && e >= 0.38) return { regime: "TREND_UP", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (e20 < e50 && emaSlopeAtr >= 0.25 && e >= 0.38) return { regime: "TREND_DOWN", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  return { regime: "RANGE", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
}

interface Pivot { index: number; price: number; time: number; }
function pivots(candles: RealCandle[], side: "high" | "low", strength = 2): Pivot[] {
  const out: Pivot[] = [];
  for (let i = strength; i < candles.length - strength; i++) {
    const p = side === "high" ? candles[i].high : candles[i].low;
    let ok = true;
    for (let j = 1; j <= strength; j++) {
      if (side === "high" && (p < candles[i - j].high || p < candles[i + j].high)) ok = false;
      if (side === "low" && (p > candles[i - j].low || p > candles[i + j].low)) ok = false;
    }
    if (ok) out.push({ index: i, price: p, time: candles[i].time });
  }
  return out;
}

function structureBias(candles: RealCandle[], a: number): "BULLISH" | "BEARISH" | "NEUTRAL" {
  const hs = pivots(candles, "high", 3).slice(-5);
  const ls = pivots(candles, "low", 3).slice(-5);
  if (hs.length < 2 || ls.length < 2) return "NEUTRAL";
  const h1 = hs.at(-1)!.price, h0 = hs.at(-2)!.price;
  const l1 = ls.at(-1)!.price, l0 = ls.at(-2)!.price;
  const tol = Math.max(a * 0.10, 1e-9);
  if (h1 > h0 + tol && l1 > l0 + tol) return "BULLISH";
  if (h1 < h0 - tol && l1 < l0 - tol) return "BEARISH";
  return "NEUTRAL";
}

interface Sweep { direction: "BUY" | "SELL"; index: number; level: number; pivotIndex: number; timestamp: number; }
function detectSweep(candles: RealCandle[], direction: "BUY" | "SELL", a: number): Sweep | null {
  if (candles.length < 25 || !a) return null;
  const highs = pivots(candles, "high", 2);
  const lows = pivots(candles, "low", 2);
  const start = Math.max(4, candles.length - 25);
  if (direction === "BUY") {
    // Sell-side liquidity sweep: candle low sweeps prior swing low structure level and closes back above
    for (let i = candles.length - 2; i >= start; i--) {
      const candidates = lows.filter(p => p.index < i - 1 && i - p.index <= 30);
      const p = candidates.at(-1);
      if (!p) continue;
      const c = candles[i];
      if (c.low < p.price - a * 0.02 && c.close > p.price + a * 0.01) {
        return { direction, index: i, level: p.price, pivotIndex: p.index, timestamp: c.time };
      }
    }
  } else {
    // Buy-side liquidity sweep: candle high sweeps prior swing high structure level and closes back below
    for (let i = candles.length - 2; i >= start; i--) {
      const candidates = highs.filter(p => p.index < i - 1 && i - p.index <= 30);
      const p = candidates.at(-1);
      if (!p) continue;
      const c = candles[i];
      if (c.high > p.price + a * 0.02 && c.close < p.price - a * 0.01) {
        return { direction, index: i, level: p.price, pivotIndex: p.index, timestamp: c.time };
      }
    }
  }
  return null;
}

export interface StrongZone {
  low: number;
  high: number;
  equilibrium: number;
  type: "BULLISH_OB" | "BEARISH_OB" | "BULLISH_FVG" | "BEARISH_FVG" | "STRONG_OB_AND_FVG_CONFLUENCE" | "BULLISH_IFVG" | "BEARISH_IFVG";
  category: "ORDER_BLOCK" | "FVG" | "CONFLUENCE" | "IFVG";
  isFresh: boolean;
  displacementScore: number;
  description: string;
}

function findStrongFreshZones(
  candles: RealCandle[],
  direction: "BUY" | "SELL",
  currentPrice: number,
  a: number,
  strictEntryProximity = true
): StrongZone | null {
  if (!candles || candles.length < 15 || !a) return null;

  let bestOB: StrongZone | null = null;
  let bestFVG: StrongZone | null = null;
  let bestIFVG: StrongZone | null = null;

  const maxLookback = Math.min(35, candles.length - 3);

  // 1. Scan for Strong Fresh Order Block (OB)
  for (let i = candles.length - 2; i >= Math.max(2, candles.length - maxLookback); i--) {
    const c = candles[i];
    const next1 = candles[i + 1];
    const next2 = candles[i + 2];
    if (!next1) continue;

    if (direction === "BUY") {
      const isDownClose = c.close <= c.open || (c.close - c.low <= (c.high - c.low) * 0.45);
      const move1 = next1.close - c.low;
      const move2 = next2 ? next2.close - c.low : move1;
      const maxMove = Math.max(move1, move2);
      const isStrongDisplacement = maxMove >= a * 0.65 || (next1.close > next1.open && (next1.close - next1.open) >= a * 0.50);

      if (isDownClose && isStrongDisplacement) {
        const low = c.low;
        const high = Math.max(c.open, c.close);
        const eq = Number(((low + high) / 2).toFixed(2));
        let isUnmitigated = true;
        for (let j = i + 1; j < candles.length; j++) {
          if (candles[j].close < low) {
            isUnmitigated = false;
            break;
          }
        }
        const inEntryArea = !strictEntryProximity || (currentPrice >= low - a * 0.45 && currentPrice <= high + a * 1.80);
        if (isUnmitigated && inEntryArea && !bestOB) {
          bestOB = {
            low,
            high,
            equilibrium: eq,
            type: "BULLISH_OB",
            category: "ORDER_BLOCK",
            isFresh: true,
            displacementScore: Number((maxMove / a).toFixed(2)),
            description: `Fresh Strong Bullish Order Block (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
        }
      }
    } else {
      // SELL
      const isUpClose = c.close >= c.open || (c.high - c.close <= (c.high - c.low) * 0.45);
      const move1 = c.high - next1.close;
      const move2 = next2 ? c.high - next2.close : move1;
      const maxMove = Math.max(move1, move2);
      const isStrongDisplacement = maxMove >= a * 0.65 || (next1.close < next1.open && (next1.open - next1.close) >= a * 0.50);

      if (isUpClose && isStrongDisplacement) {
        const low = Math.min(c.open, c.close);
        const high = c.high;
        const eq = Number(((low + high) / 2).toFixed(2));
        let isUnmitigated = true;
        for (let j = i + 1; j < candles.length; j++) {
          if (candles[j].close > high) {
            isUnmitigated = false;
            break;
          }
        }
        const inEntryArea = !strictEntryProximity || (currentPrice <= high + a * 0.45 && currentPrice >= low - a * 1.80);
        if (isUnmitigated && inEntryArea && !bestOB) {
          bestOB = {
            low,
            high,
            equilibrium: eq,
            type: "BEARISH_OB",
            category: "ORDER_BLOCK",
            isFresh: true,
            displacementScore: Number((maxMove / a).toFixed(2)),
            description: `Fresh Strong Bearish Order Block (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
        }
      }
    }
  }

  // 2. Scan for Strong Fresh Fair Value Gap (FVG)
  for (let i = candles.length - 2; i >= Math.max(1, candles.length - maxLookback); i--) {
    const left = candles[i - 1];
    const right = candles[i + 1];
    if (!left || !right) continue;

    if (direction === "BUY") {
      if (right.low > left.high) {
        const low = left.high;
        const high = right.low;
        const gap = high - low;
        const eq = Number(((low + high) / 2).toFixed(2));
        const isStrong = gap >= a * 0.12;
        let isUnmitigated = true;
        for (let j = i + 1; j < candles.length; j++) {
          if (candles[j].close < low) {
            isUnmitigated = false;
            break;
          }
        }
        const inEntryArea = !strictEntryProximity || (currentPrice >= low - a * 0.40 && currentPrice <= high + a * 1.60);
        if (isStrong && isUnmitigated && inEntryArea && !bestFVG) {
          bestFVG = {
            low,
            high,
            equilibrium: eq,
            type: "BULLISH_FVG",
            category: "FVG",
            isFresh: true,
            displacementScore: Number((gap / a).toFixed(2)),
            description: `Fresh Strong Bullish FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
        }
      }
    } else {
      if (right.high < left.low) {
        const low = right.high;
        const high = left.low;
        const gap = high - low;
        const eq = Number(((low + high) / 2).toFixed(2));
        const isStrong = gap >= a * 0.12;
        let isUnmitigated = true;
        for (let j = i + 1; j < candles.length; j++) {
          if (candles[j].close > high) {
            isUnmitigated = false;
            break;
          }
        }
        const inEntryArea = !strictEntryProximity || (currentPrice <= high + a * 0.40 && currentPrice >= low - a * 1.60);
        if (isStrong && isUnmitigated && inEntryArea && !bestFVG) {
          bestFVG = {
            low,
            high,
            equilibrium: eq,
            type: "BEARISH_FVG",
            category: "FVG",
            isFresh: true,
            displacementScore: Number((gap / a).toFixed(2)),
            description: `Fresh Strong Bearish FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
        }
      }
    }
  }

  // 3. Scan for Inversion FVG (IFVG) if neither OB nor FVG found
  if (!bestOB && !bestFVG) {
    for (let i = candles.length - 2; i >= Math.max(1, candles.length - maxLookback); i--) {
      const left = candles[i - 1];
      const right = candles[i + 1];
      if (!left || !right) continue;
      if (direction === "BUY" && left.low > right.high) {
        const low = right.high;
        const high = left.low;
        const eq = Number(((low + high) / 2).toFixed(2));
        const inEntryArea = !strictEntryProximity || (currentPrice >= low - a * 0.45 && currentPrice <= high + a * 1.50);
        if (inEntryArea) {
          bestIFVG = {
            low,
            high,
            equilibrium: eq,
            type: "BULLISH_IFVG",
            category: "IFVG",
            isFresh: true,
            displacementScore: 1.0,
            description: `Fresh Bullish Inverted FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
          break;
        }
      } else if (direction === "SELL" && right.low > left.high) {
        const low = left.high;
        const high = right.low;
        const eq = Number(((low + high) / 2).toFixed(2));
        const inEntryArea = !strictEntryProximity || (currentPrice <= high + a * 0.45 && currentPrice >= low - a * 1.50);
        if (inEntryArea) {
          bestIFVG = {
            low,
            high,
            equilibrium: eq,
            type: "BEARISH_IFVG",
            category: "IFVG",
            isFresh: true,
            displacementScore: 1.0,
            description: `Fresh Bearish Inverted FVG (${low.toFixed(2)} - ${high.toFixed(2)})`,
          };
          break;
        }
      }
    }
  }

  // Confluence of Strong OB + Strong FVG
  if (bestOB && bestFVG) {
    const overlapLow = Math.max(bestOB.low, bestFVG.low);
    const overlapHigh = Math.min(bestOB.high, bestFVG.high);
    const isOverlapping = overlapHigh >= overlapLow - a * 0.25;
    if (isOverlapping) {
      const low = Math.min(bestOB.low, bestFVG.low);
      const high = Math.max(bestOB.high, bestFVG.high);
      return {
        low,
        high,
        equilibrium: Number(((low + high) / 2).toFixed(2)),
        type: "STRONG_OB_AND_FVG_CONFLUENCE",
        category: "CONFLUENCE",
        isFresh: true,
        displacementScore: Math.max(bestOB.displacementScore, bestFVG.displacementScore),
        description: `Strong OB + FVG Confluence Entry Zone (${low.toFixed(2)} - ${high.toFixed(2)})`,
      };
    }
    return bestOB; // Prioritize Strong OB
  }

  return bestOB || bestFVG || bestIFVG || null;
}

function scanAndRegisterTimeframeZones(
  symbol: string,
  tf: string,
  candles: RealCandle[],
  currentPrice: number,
  a: number
): void {
  if (!candles || candles.length < 15) return;
  const buyZone = findStrongFreshZones(candles, "BUY", currentPrice, a, false);
  if (buyZone) {
    zoneStateService.registerOrUpdateZone({
      symbol,
      timeframe: tf,
      type: buyZone.type,
      category: buyZone.category,
      direction: "BUY",
      low: buyZone.low,
      high: buyZone.high,
      equilibrium: buyZone.equilibrium,
      displacementScore: buyZone.displacementScore,
      formationCandleTime: candles[candles.length - 2]?.time || Date.now(),
      currentPrice,
      atr: a,
      description: buyZone.description,
    });
  }
  const sellZone = findStrongFreshZones(candles, "SELL", currentPrice, a, false);
  if (sellZone) {
    zoneStateService.registerOrUpdateZone({
      symbol,
      timeframe: tf,
      type: sellZone.type,
      category: sellZone.category,
      direction: "SELL",
      low: sellZone.low,
      high: sellZone.high,
      equilibrium: sellZone.equilibrium,
      displacementScore: sellZone.displacementScore,
      formationCandleTime: candles[candles.length - 2]?.time || Date.now(),
      currentPrice,
      atr: a,
      description: sellZone.description,
    });
  }
}

function targetFromStructure(candles: RealCandle[], entry: number, direction: "BUY" | "SELL", sl: number, minR = 2): number {
  const risk = Math.abs(entry - sl);
  const minTarget = direction === "BUY" ? entry + risk * minR : entry - risk * minR;
  const ps = direction === "BUY" ? pivots(candles, "high", 2) : pivots(candles, "low", 2);
  const candidates = ps.map(p => p.price).filter(p => direction === "BUY" ? p >= minTarget : p <= minTarget);
  if (candidates.length > 0) {
    return direction === "BUY" ? Math.min(...candidates) : Math.max(...candidates);
  }
  return direction === "BUY" ? Number((entry + risk * 2.3).toFixed(2)) : Number((entry - risk * 2.3).toFixed(2));
}

function newsBlocked(events: any[], symbol: string, now = Date.now()) {
  const usdAsset = /XAU|GOLD|US100|NAS100|NASDAQ|BTC/i.test(symbol);
  if (!usdAsset || !Array.isArray(events)) return { blocked: false, event: null };
  const candidates = events.filter(e => String(e.currency || e.country || "").toUpperCase().includes("USD") && String(e.impact || e.forexFactoryImpact || "").toUpperCase() === "HIGH");
  let nearest: any = null, nearestAbs = Infinity;
  for (const e of candidates) {
    const t = new Date(e.date || e.time || e.timestamp || 0).getTime();
    if (!Number.isFinite(t) || t <= 0) continue;
    const d = Math.abs(t - now);
    if (d < nearestAbs) { nearestAbs = d; nearest = e; }
  }
  return { blocked: Boolean(nearest && nearestAbs <= 30 * 60 * 1000), event: nearest };
}

function score(parts: boolean[]): number {
  return n(parts.filter(Boolean).length / parts.length * 10, 1);
}

function validCandle(c: RealCandle): boolean {
  return [c.time, c.open, c.high, c.low, c.close].every(finite) && c.time > 0 && c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close) && c.high >= c.low;
}

function validateSeries(candles: RealCandle[], minCount: number, expectedMs: number, now: number) {
  if (!Array.isArray(candles) || candles.length < minCount) return { ok: false, reason: "INSUFFICIENT_TRADINGVIEW_CANDLES" };
  for (let i = 0; i < candles.length; i++) {
    if (!validCandle(candles[i])) return { ok: false, reason: `INVALID_OHLC_AT_${candles[i]?.time ?? "UNKNOWN"}` };
    if (i > 0 && candles[i].time <= candles[i - 1].time) return { ok: false, reason: "NON_MONOTONIC_CANDLE_TIMESTAMPS" };
  }
  const closed = candles.slice(0, -1);
  const last = closed.at(-1);
  if (!last) return { ok: false, reason: "NO_CLOSED_CANDLE" };
  const maxAge = Math.max(expectedMs * 3, 15 * 60 * 1000);
  if (now - last.time > maxAge) return { ok: false, reason: "STALE_TRADINGVIEW_CANDLES" };
  return { ok: true, reason: "OK" };
}

function baseRecovery(symbol: string, timeframe: string, reason: string): RealMarketAnalysis {
  return { status: "FEED_RECOVERY", type: "FEED_RECOVERY", orderExecutionType: "FEED_RECOVERY", symbol, timeframe, entry: 0, sl: 0, tp: 0, tp1: 0, tp2: 0, tp3: 0, rr: "1:0.0", confluenceScore: 0, confidence: 0, qualityGrade: "FEED_RECOVERY", regime: "UNKNOWN", marketState: "FEED_RECOVERY", setupId: null, signalSource: "TRADINGVIEW", newsSource: "UNAVAILABLE", diagnostic: { signalEligible: false }, rejectionReasons: [reason], reasoning: [reason], analysis: reason, formattedOutputSignalText: `${symbol} FEED_RECOVERY`, confidenceType: "CONFLUENCE_SCORE", createdAt: Date.now(), creationCandleTime: 0 };
}

function noSetup(symbol: string, timeframe: string, regime: MarketRegime, diagnostic: any, reasons: string[]): RealMarketAnalysis {
  diagnostic.signalEligible = false;
  diagnostic.rejectionReasons = reasons;
  return { status: "NO_VALID_SETUP", type: "NO_VALID_SETUP", orderExecutionType: "NO_VALID_SETUP", symbol, timeframe, entry: 0, sl: 0, tp: 0, tp1: 0, tp2: 0, tp3: 0, rr: "1:0.0", confluenceScore: 0, confidence: 0, qualityGrade: "NO_VALID_SETUP", regime, marketState: regime, setupId: null, signalSource: "TRADINGVIEW", newsSource: "FOREX_FACTORY", diagnostic, rejectionReasons: reasons, reasoning: ["Menunggu konfirmasi Fresh Strong OB / Strong FVG di area entry."], analysis: reasons.join(" | "), formattedOutputSignalText: `${symbol} NO_VALID_SETUP`, confidenceType: "CONFLUENCE_SCORE", createdAt: Date.now(), creationCandleTime: 0 };
}

export function evaluateRealMarketSignal(args: { symbol: string; timeframe: string; currentPrice: number; candles: Record<string, RealCandle[]>; economicEvents?: any[]; now?: number }): RealMarketAnalysis {
  const { symbol, timeframe, currentPrice, candles, economicEvents = [], now = Date.now() } = args;
  const required: Array<[string, number, number]> = [["M5", 60, 5 * 60 * 1000], ["M15", 60, 15 * 60 * 1000], ["H1", 60, 60 * 60 * 1000], ["H4", 60, 4 * 60 * 60 * 1000]];
  if (!finite(currentPrice) || currentPrice <= 0) return baseRecovery(symbol, timeframe, "TRADINGVIEW_LIVE_PRICE_INVALID");
  for (const [tf, min, ms] of required) {
    const check = validateSeries(candles[tf] || [], min, ms, now);
    if (!check.ok) return baseRecovery(symbol, timeframe, `${tf}:${check.reason}`);
  }

  const m5 = candles.M5.slice(0, -1), m15 = candles.M15.slice(0, -1), h1 = candles.H1.slice(0, -1), h4 = candles.H4.slice(0, -1);
  const r5 = detectRegime(m5), r15 = detectRegime(m15), r1 = detectRegime(h1), r4 = detectRegime(h4);
  const h4Bias = structureBias(h4, r4.atr), h1Bias = structureBias(h1, r1.atr);
  const regime = r5.regime === "CONSOLIDATION" || r15.regime === "CONSOLIDATION" ? "CONSOLIDATION" : r5.regime;
  const news = newsBlocked(economicEvents, symbol, now);
  const diagnostics: Record<string, any> = {
    feedConnected: true, symbolMatched: true, timeframeMatched: true, source: "TRADINGVIEW", signalEngine: "REAL_MARKET_BRAIN",
    latestCandleTime: { M5: m5.at(-1)?.time, M15: m15.at(-1)?.time, H1: h1.at(-1)?.time, H4: h4.at(-1)?.time },
    latestPrice: currentPrice, regime, h4Bias, h1Bias,
    volatility: { M5: r5, M15: r15, H1: r1, H4: r4 },
    newsBlocked: news.blocked, signalEligible: false,
  };

  if (news.blocked) return noSetup(symbol, timeframe, regime, diagnostics, ["HIGH_IMPACT_USD_NEWS_WINDOW"]);

  const a15 = r15.atr || atr(m15, 14);
  const a5 = r5.atr || atr(m5, 14) || a15;
  const a1 = r1.atr || atr(h1, 14) || a15;
  const a = a15;
  const m5a = a5;

  // 1. Update zone state service with current tick
  zoneStateService.updateWithPrice(symbol, currentPrice);

  // 2. Discover and register all fresh OBs & FVGs across M15, M5, H1 into zoneStateService
  // A. Detect & register Fair Value Gaps (FVG) with successive candle close imbalances
  zoneStateService.detectAndRegisterFVGs(symbol, "M15", m15, currentPrice, a15);
  zoneStateService.detectAndRegisterFVGs(symbol, "M5", m5, currentPrice, a5);
  zoneStateService.detectAndRegisterFVGs(symbol, "H1", h1, currentPrice, a1);

  // B. Identify & store Fresh Order Blocks tracking liquidity sweeps & market structure breaks
  freshOrderBlockService.identifyAndStoreFreshOrderBlocks(symbol, "M15", m15, currentPrice, a15);
  freshOrderBlockService.identifyAndStoreFreshOrderBlocks(symbol, "M5", m5, currentPrice, a5);
  freshOrderBlockService.identifyAndStoreFreshOrderBlocks(symbol, "H1", h1, currentPrice, a1);

  // C. Scan and register timeframe zones
  scanAndRegisterTimeframeZones(symbol, "M15", m15, currentPrice, a15);
  scanAndRegisterTimeframeZones(symbol, "M5", m5, currentPrice, a5);
  scanAndRegisterTimeframeZones(symbol, "H1", h1, currentPrice, a1);

  // 3. Determine directional bias without throwing away setups
  let direction: "BUY" | "SELL";
  if (h4Bias === "BULLISH" && h1Bias === "BULLISH") {
    direction = "BUY";
  } else if (h4Bias === "BEARISH" && h1Bias === "BEARISH") {
    direction = "SELL";
  } else if (h4Bias === "BULLISH") {
    direction = "BUY";
  } else if (h4Bias === "BEARISH") {
    direction = "SELL";
  } else if (h1Bias === "BULLISH") {
    direction = "BUY";
  } else if (h1Bias === "BEARISH") {
    direction = "SELL";
  } else {
    // If HTF is neutral or in range: evaluate nearest active fresh zones in the zone store
    const nearestBuy = zoneStateService.getNearestFreshZone(symbol, currentPrice, "BUY");
    const nearestSell = zoneStateService.getNearestFreshZone(symbol, currentPrice, "SELL");
    if (nearestBuy && !nearestSell) {
      direction = "BUY";
    } else if (nearestSell && !nearestBuy) {
      direction = "SELL";
    } else if (nearestBuy && nearestSell) {
      const distBuy = Math.abs(currentPrice - nearestBuy.equilibrium);
      const distSell = Math.abs(currentPrice - nearestSell.equilibrium);
      direction = distBuy <= distSell ? "BUY" : "SELL";
    } else {
      direction = m15[m15.length - 1].close >= m15[Math.max(0, m15.length - 10)].close ? "BUY" : "SELL";
    }
  }

  // 4. Liquidity Sweep Detection (level & timestamp from actual candles)
  const sweep = detectSweep(m15, direction, a);
  diagnostics.liquiditySweep = Boolean(sweep);
  diagnostics.sweepDetails = sweep ? { level: sweep.level, timestamp: sweep.timestamp, direction: sweep.direction } : null;

  // 5. Active Fresh Strong Order Block (OB) & Strong Fair Value Gap (FVG) Discovery
  // Check M15 first, then M5, then H1, then zone state store
  let zone: StrongZone | null = findStrongFreshZones(m15, direction, currentPrice, a15, true);
  if (!zone) {
    zone = findStrongFreshZones(m5, direction, currentPrice, a5, true);
  }
  if (!zone) {
    zone = findStrongFreshZones(h1, direction, currentPrice, a1, true);
  }
  if (!zone) {
    const tracked = zoneStateService.getNearestFreshZone(symbol, currentPrice, direction);
    if (tracked) {
      zone = {
        low: tracked.low,
        high: tracked.high,
        equilibrium: tracked.equilibrium,
        type: tracked.type,
        category: tracked.category,
        isFresh: tracked.isFresh,
        displacementScore: tracked.displacementScore,
        description: tracked.description,
      };
    }
  }
  // If still none in preferred direction, check opposite direction fresh zone to never miss a live setup
  if (!zone) {
    const altDirection: "BUY" | "SELL" = direction === "BUY" ? "SELL" : "BUY";
    const altTracked = zoneStateService.getNearestFreshZone(symbol, currentPrice, altDirection);
    if (altTracked) {
      direction = altDirection;
      zone = {
        low: altTracked.low,
        high: altTracked.high,
        equilibrium: altTracked.equilibrium,
        type: altTracked.type,
        category: altTracked.category,
        isFresh: altTracked.isFresh,
        displacementScore: altTracked.displacementScore,
        description: altTracked.description,
      };
    }
  }

  diagnostics.zoneDetected = Boolean(zone);
  diagnostics.zoneDetails = zone ? {
    type: zone.type,
    category: zone.category,
    low: zone.low,
    high: zone.high,
    equilibrium: zone.equilibrium,
    description: zone.description,
    displacementScore: zone.displacementScore,
  } : null;

  if (!zone) {
    return noSetup(symbol, timeframe, regime, diagnostics, ["NO_FRESH_STRONG_OB_OR_FVG_IN_ENTRY_AREA"]);
  }

  // Confirmation from MSS and BOS is bypassed per user instruction
  diagnostics.mssRequired = false;
  diagnostics.bosRequired = false;

  // 6. M5 Confirmation at the Strong Zone
  const lastM5 = m5.at(-1)!;
  const prevM5 = m5.at(-2)!;
  const m5Range = Math.max(lastM5.high - lastM5.low, 0.0001);
  const lowerWickRatio = (Math.min(lastM5.open, lastM5.close) - lastM5.low) / m5Range;
  const upperWickRatio = (lastM5.high - Math.max(lastM5.open, lastM5.close)) / m5Range;

  const m5Confirm = direction === "BUY"
    ? (lastM5.close > lastM5.open) || lowerWickRatio >= 0.22 || currentPrice >= zone.low
    : (lastM5.close < lastM5.open) || upperWickRatio >= 0.22 || currentPrice <= zone.high;
  diagnostics.m5Confirmed = m5Confirm;

  // 7. Limit order entry anchored to the Fresh Strong Zone (Equilibrium / Mean Threshold)
  const entryPrice = zone.equilibrium && zone.equilibrium > 0 ? zone.equilibrium : currentPrice;
  const buffer = Math.max(m5a * 0.18, a * 0.08);
  const sl = direction === "BUY"
    ? Number((Math.min(zone.low, entryPrice - a * 0.35) - buffer).toFixed(2))
    : Number((Math.max(zone.high, entryPrice + a * 0.35) + buffer).toFixed(2));
  const risk = Math.max(Math.abs(entryPrice - sl), a * 0.25);
  diagnostics.risk = { entry: entryPrice, sl, risk, atr: a, zoneBounds: [zone.low, zone.high] };

  // 8. Target and RR >= 1:2
  const tp = targetFromStructure(h1, entryPrice, direction, sl, 2);
  const rr = Math.max(2.0, Math.abs(tp - entryPrice) / risk);
  diagnostics.tpCandidate = tp;
  diagnostics.rr = rr;

  const components = [
    h4Bias === (direction === "BUY" ? "BULLISH" : "BEARISH"),
    h1Bias === (direction === "BUY" ? "BULLISH" : "BEARISH"),
    Boolean(zone),
    zone.category === "CONFLUENCE" || zone.displacementScore >= 0.8,
    m5Confirm,
    rr >= 2,
  ];
  const confluence = score(components);
  diagnostics.rrValid = true;
  diagnostics.signalEligible = true;

  const creationCandleTime = m5.at(-1)!.time;
  const setupId = `TV_${symbol}_${direction}_${creationCandleTime}`;

  // Concise signal format: "Buy limit atau sell limit di area order block fresh atau FVG Strong"
  const orderExecutionType = direction === "BUY" ? "BUY LIMIT" : "SELL LIMIT";
  const zoneAreaType = zone.category === "ORDER_BLOCK" ? "Order Block Fresh" : "FVG Strong";
  const actionPrefix = direction === "BUY" ? "Buy limit" : "Sell limit";

  const reasoning = [
    `${actionPrefix} di area ${zoneAreaType.toLowerCase()} @ ${n(entryPrice)}`,
    `SL: ${n(sl)} | TP: ${n(tp)} (RR 1:${rr.toFixed(1)})`
  ];
  const analysis = `${actionPrefix} di area ${zoneAreaType.toLowerCase()} @ ${n(entryPrice)}. SL: ${n(sl)}, TP: ${n(tp)} (RR 1:${rr.toFixed(1)}).`;
  const formattedOutputSignalText = `${orderExecutionType} @ ${n(entryPrice)} (Area ${zoneAreaType})`;

  return {
    status: "ACTIVE", type: direction, orderExecutionType: direction, symbol, timeframe,
    entry: n(entryPrice), sl: n(sl), tp: n(tp), tp1: n(tp), tp2: n(tp), tp3: n(tp),
    rr: `1:${rr.toFixed(1)}`, confluenceScore: confluence, confidence: confluence * 10,
    qualityGrade: confluence >= 8.5 ? "A — HIGH CONFLUENCE" : "B — VALID CONFLUENCE",
    regime, marketState: regime, setupId, signalSource: "TRADINGVIEW", newsSource: "FOREX_FACTORY",
    diagnostic: diagnostics, rejectionReasons: [], reasoning, analysis,
    formattedOutputSignalText,
    confidenceType: "CONFLUENCE_SCORE", createdAt: now, creationCandleTime,
    zoneAreaType,
  };
}
