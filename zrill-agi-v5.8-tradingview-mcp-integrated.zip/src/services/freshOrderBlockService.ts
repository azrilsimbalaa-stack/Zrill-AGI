import { zoneStateService, type TrackedZone, type CandlePoint } from "./zoneStateService.js";

export interface LiquiditySweep {
  type: "SELL_SIDE_LIQUIDITY_SWEEP" | "BUY_SIDE_LIQUIDITY_SWEEP";
  level: number;
  sweepCandleTime: number;
  sweepIndex: number;
  penetration: number;
  direction: "BUY" | "SELL";
}

export interface MarketStructureBreak {
  type: "BULLISH_MSB" | "BEARISH_MSB";
  brokenLevel: number;
  breakCandleTime: number;
  breakIndex: number;
  displacementBody: number;
  direction: "BUY" | "SELL";
}

export interface FreshOrderBlockSetup {
  symbol: string;
  timeframe: string;
  direction: "BUY" | "SELL";
  type: "BULLISH_OB" | "BEARISH_OB";
  low: number;
  high: number;
  equilibrium: number;
  entryPrice: number;
  sl: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: number;
  sweep: LiquiditySweep;
  msb: MarketStructureBreak;
  isFresh: boolean;
  mitigationCount: number;
  displacementScore: number;
  formationCandleTime: number;
  description: string;
}

export class FreshOrderBlockService {
  /**
   * Detect pivots (swing highs and swing lows) from real candle history
   */
  private findPivots(candles: CandlePoint[], window = 3) {
    const highs: Array<{ index: number; price: number; time: number }> = [];
    const lows: Array<{ index: number; price: number; time: number }> = [];

    for (let i = window; i < candles.length - window; i++) {
      let isHigh = true;
      let isLow = true;
      const c = candles[i];

      for (let j = i - window; j <= i + window; j++) {
        if (j === i) continue;
        if (candles[j].high >= c.high) isHigh = false;
        if (candles[j].low <= c.low) isLow = false;
      }

      if (isHigh) highs.push({ index: i, price: c.high, time: c.time });
      if (isLow) lows.push({ index: i, price: c.low, time: c.time });
    }

    return { highs, lows };
  }

  /**
   * Identifies real liquidity sweeps where candle wicks take out prior swing liquidity
   * but price reclaims and closes back inside the structure.
   */
  public detectLiquiditySweeps(candles: CandlePoint[], atr: number): LiquiditySweep[] {
    if (!candles || candles.length < 20 || !atr) return [];
    const { highs, lows } = this.findPivots(candles, 2);
    const sweeps: LiquiditySweep[] = [];
    const minLookback = Math.max(0, candles.length - 35);

    // 1. Sell-Side Liquidity (SSL) Sweep for Bullish reversal
    for (const lowPivot of lows) {
      if (lowPivot.index < minLookback) continue;
      for (let i = lowPivot.index + 1; i < candles.length; i++) {
        const c = candles[i];
        // Wick pierced below swing low, but candle closed back above swing low
        if (c.low < lowPivot.price && c.close >= lowPivot.price) {
          const penetration = lowPivot.price - c.low;
          if (penetration >= atr * 0.05) {
            sweeps.push({
              type: "SELL_SIDE_LIQUIDITY_SWEEP",
              level: Number(lowPivot.price.toFixed(2)),
              sweepCandleTime: c.time,
              sweepIndex: i,
              penetration: Number(penetration.toFixed(2)),
              direction: "BUY",
            });
            break;
          }
        }
      }
    }

    // 2. Buy-Side Liquidity (BSL) Sweep for Bearish reversal
    for (const highPivot of highs) {
      if (highPivot.index < minLookback) continue;
      for (let i = highPivot.index + 1; i < candles.length; i++) {
        const c = candles[i];
        // Wick pierced above swing high, but candle closed back below swing high
        if (c.high > highPivot.price && c.close <= highPivot.price) {
          const penetration = c.high - highPivot.price;
          if (penetration >= atr * 0.05) {
            sweeps.push({
              type: "BUY_SIDE_LIQUIDITY_SWEEP",
              level: Number(highPivot.price.toFixed(2)),
              sweepCandleTime: c.time,
              sweepIndex: i,
              penetration: Number(penetration.toFixed(2)),
              direction: "SELL",
            });
            break;
          }
        }
      }
    }

    return sweeps;
  }

  /**
   * Tracks Market Structure Break (MSB / BOS / MSS) following a confirmed liquidity sweep
   */
  public detectMarketStructureBreak(
    candles: CandlePoint[],
    sweep: LiquiditySweep,
    atr: number
  ): MarketStructureBreak | null {
    const { highs, lows } = this.findPivots(candles, 2);

    if (sweep.direction === "BUY") {
      // Find the most recent structural high prior to or during the sweep
      const priorHighs = highs.filter(h => h.index < sweep.sweepIndex && h.index >= sweep.sweepIndex - 15);
      if (!priorHighs.length) return null;
      const keyHigh = priorHighs.reduce((prev, curr) => (curr.price > prev.price ? curr : prev));

      // Check subsequent candles after sweep for clean close above keyHigh
      for (let i = sweep.sweepIndex; i < candles.length; i++) {
        const c = candles[i];
        const body = c.close - c.open;
        if (c.close > keyHigh.price && body >= atr * 0.25) {
          return {
            type: "BULLISH_MSB",
            brokenLevel: Number(keyHigh.price.toFixed(2)),
            breakCandleTime: c.time,
            breakIndex: i,
            displacementBody: Number(body.toFixed(2)),
            direction: "BUY",
          };
        }
      }
    } else {
      // SELL: Find the most recent structural low prior to or during the sweep
      const priorLows = lows.filter(l => l.index < sweep.sweepIndex && l.index >= sweep.sweepIndex - 15);
      if (!priorLows.length) return null;
      const keyLow = priorLows.reduce((prev, curr) => (curr.price < prev.price ? curr : prev));

      // Check subsequent candles after sweep for clean close below keyLow
      for (let i = sweep.sweepIndex; i < candles.length; i++) {
        const c = candles[i];
        const body = c.open - c.close;
        if (c.close < keyLow.price && body >= atr * 0.25) {
          return {
            type: "BEARISH_MSB",
            brokenLevel: Number(keyLow.price.toFixed(2)),
            breakCandleTime: c.time,
            breakIndex: i,
            displacementBody: Number(body.toFixed(2)),
            direction: "SELL",
          };
        }
      }
    }

    return null;
  }

  /**
   * Identifies 'Fresh' Order Blocks by tracking liquidity sweeps and market structure breaks,
   * ensuring only valid, unmitigated setups are stored into the zoneStateService.
   */
  public identifyAndStoreFreshOrderBlocks(
    symbol: string,
    timeframe: string,
    candles: CandlePoint[],
    currentPrice: number,
    atr: number
  ): FreshOrderBlockSetup[] {
    if (!candles || candles.length < 25 || !atr) return [];

    const sweeps = this.detectLiquiditySweeps(candles, atr);
    const validSetups: FreshOrderBlockSetup[] = [];

    for (const sweep of sweeps) {
      const msb = this.detectMarketStructureBreak(candles, sweep, atr);
      if (!msb) continue;

      // Locate the origin Order Block candle
      if (sweep.direction === "BUY") {
        // Find the last down-close candle before the upward expansion
        let obCandleIndex = -1;
        for (let i = sweep.sweepIndex; i >= Math.max(0, sweep.sweepIndex - 8); i--) {
          const c = candles[i];
          if (c.close <= c.open || c.close - c.low <= (c.high - c.low) * 0.45) {
            obCandleIndex = i;
            break;
          }
        }
        if (obCandleIndex === -1) obCandleIndex = sweep.sweepIndex;

        const obCandle = candles[obCandleIndex];
        const low = obCandle.low;
        const high = Math.max(obCandle.open, obCandle.close);
        const equilibrium = Number(((low + high) / 2).toFixed(2));

        // Strict Freshness Validation:
        // 1. Invalidation: No subsequent closed candle has closed below ob.low
        // 2. Mitigation count: Touched <= 1 time
        let isFresh = true;
        let mitigationCount = 0;

        for (let j = obCandleIndex + 1; j < candles.length; j++) {
          const c = candles[j];
          if (c.close < low) {
            isFresh = false;
            break;
          }
          if (c.low <= high) {
            mitigationCount++;
          }
        }

        if (isFresh && mitigationCount <= 1) {
          const buffer = Math.max(atr * 0.15, 0.20);
          const sl = Number((low - buffer).toFixed(2));
          const risk = Math.max(equilibrium - sl, atr * 0.25);
          const tp1 = Number((equilibrium + risk * 1.5).toFixed(2));
          const tp2 = Number((equilibrium + risk * 2.3).toFixed(2));
          const tp3 = Number((equilibrium + risk * 3.2).toFixed(2));
          const rr = Number((Math.abs(tp2 - equilibrium) / risk).toFixed(1));

          const setup: FreshOrderBlockSetup = {
            symbol: symbol.toUpperCase(),
            timeframe,
            direction: "BUY",
            type: "BULLISH_OB",
            low: Number(low.toFixed(2)),
            high: Number(high.toFixed(2)),
            equilibrium,
            entryPrice: equilibrium,
            sl,
            tp1,
            tp2,
            tp3,
            rr: Math.max(2.0, rr),
            sweep,
            msb,
            isFresh: true,
            mitigationCount,
            displacementScore: Number((msb.displacementBody / atr).toFixed(2)),
            formationCandleTime: obCandle.time,
            description: `Fresh Bullish OB at ${low.toFixed(2)} - ${high.toFixed(2)} (SSL Swept @ ${sweep.level}, MSB @ ${msb.brokenLevel})`,
          };

          // Store verified valid setup into zoneStateService
          zoneStateService.registerOrUpdateZone({
            symbol,
            timeframe,
            type: "BULLISH_OB",
            category: "ORDER_BLOCK",
            direction: "BUY",
            low: setup.low,
            high: setup.high,
            equilibrium: setup.equilibrium,
            displacementScore: setup.displacementScore,
            formationCandleTime: setup.formationCandleTime,
            currentPrice,
            atr,
            description: setup.description,
            targetPrice: setup.tp2,
          });

          validSetups.push(setup);
        }
      } else {
        // SELL: Find the last up-close candle before the downward expansion
        let obCandleIndex = -1;
        for (let i = sweep.sweepIndex; i >= Math.max(0, sweep.sweepIndex - 8); i--) {
          const c = candles[i];
          if (c.close >= c.open || c.high - c.close <= (c.high - c.low) * 0.45) {
            obCandleIndex = i;
            break;
          }
        }
        if (obCandleIndex === -1) obCandleIndex = sweep.sweepIndex;

        const obCandle = candles[obCandleIndex];
        const low = Math.min(obCandle.open, obCandle.close);
        const high = obCandle.high;
        const equilibrium = Number(((low + high) / 2).toFixed(2));

        // Strict Freshness Validation:
        // 1. Invalidation: No subsequent closed candle has closed above ob.high
        // 2. Mitigation count: Touched <= 1 time
        let isFresh = true;
        let mitigationCount = 0;

        for (let j = obCandleIndex + 1; j < candles.length; j++) {
          const c = candles[j];
          if (c.close > high) {
            isFresh = false;
            break;
          }
          if (c.high >= low) {
            mitigationCount++;
          }
        }

        if (isFresh && mitigationCount <= 1) {
          const buffer = Math.max(atr * 0.15, 0.20);
          const sl = Number((high + buffer).toFixed(2));
          const risk = Math.max(sl - equilibrium, atr * 0.25);
          const tp1 = Number((equilibrium - risk * 1.5).toFixed(2));
          const tp2 = Number((equilibrium - risk * 2.3).toFixed(2));
          const tp3 = Number((equilibrium - risk * 3.2).toFixed(2));
          const rr = Number((Math.abs(equilibrium - tp2) / risk).toFixed(1));

          const setup: FreshOrderBlockSetup = {
            symbol: symbol.toUpperCase(),
            timeframe,
            direction: "SELL",
            type: "BEARISH_OB",
            low: Number(low.toFixed(2)),
            high: Number(high.toFixed(2)),
            equilibrium,
            entryPrice: equilibrium,
            sl,
            tp1,
            tp2,
            tp3,
            rr: Math.max(2.0, rr),
            sweep,
            msb,
            isFresh: true,
            mitigationCount,
            displacementScore: Number((msb.displacementBody / atr).toFixed(2)),
            formationCandleTime: obCandle.time,
            description: `Fresh Bearish OB at ${low.toFixed(2)} - ${high.toFixed(2)} (BSL Swept @ ${sweep.level}, MSB @ ${msb.brokenLevel})`,
          };

          // Store verified valid setup into zoneStateService
          zoneStateService.registerOrUpdateZone({
            symbol,
            timeframe,
            type: "BEARISH_OB",
            category: "ORDER_BLOCK",
            direction: "SELL",
            low: setup.low,
            high: setup.high,
            equilibrium: setup.equilibrium,
            displacementScore: setup.displacementScore,
            formationCandleTime: setup.formationCandleTime,
            currentPrice,
            atr,
            description: setup.description,
            targetPrice: setup.tp2,
          });

          validSetups.push(setup);
        }
      }
    }

    return validSetups;
  }

  /**
   * Monitor across multiple timeframes and store fresh setups
   */
  public monitorMultiTimeframe(
    symbol: string,
    bundles: Record<string, CandlePoint[]>,
    currentPrice: number,
    atrs: Record<string, number>
  ): FreshOrderBlockSetup[] {
    const allSetups: FreshOrderBlockSetup[] = [];
    for (const [tf, candles] of Object.entries(bundles)) {
      const a = atrs[tf] || 2.0;
      const setups = this.identifyAndStoreFreshOrderBlocks(symbol, tf, candles, currentPrice, a);
      allSetups.push(...setups);
    }
    return allSetups;
  }
}

export const freshOrderBlockService = new FreshOrderBlockService();
