export interface RealCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type RealSignal = "BUY" | "SELL" | "NO_VALID_SETUP" | "FEED_RECOVERY";
export type MarketRegime = "TREND_UP" | "TREND_DOWN" | "CONSOLIDATION" | "EXPANSION" | "RANGE" | "UNKNOWN";

export interface RealMarketAnalysis {
  status: "ACTIVE" | "NO_VALID_SETUP" | "FEED_RECOVERY";
  type: RealSignal;
  orderExecutionType: RealSignal;
  symbol: string;
  timeframe: string;
  entry: number;
  sl: number;
  tp: number;
  tp1: number;
  tp2: number;
  tp3: number;
  rr: string;
  confluenceScore: number;
  confidence: number;
  qualityGrade: string;
  regime: MarketRegime;
  marketState: string;
  setupId: string | null;
  signalSource: "TRADINGVIEW";
  newsSource: "FOREX_FACTORY" | "UNAVAILABLE";
  diagnostic: Record<string, any>;
  rejectionReasons: string[];
  reasoning: string[];
  analysis: string;
  formattedOutputSignalText: string;
  confidenceType: "CONFLUENCE_SCORE";
  createdAt: number;
  creationCandleTime: number;
}

const n = (v: number, d = 2) => Number(v.toFixed(d));
const finite = (v: any): v is number => typeof v === "number" && Number.isFinite(v);

function trueRanges(candles: RealCandle[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i], p = candles[i - 1];
    out.push(Math.max(c.high - c.low, Math.abs(c.high - p.close), Math.abs(c.low - p.close)));
  }
  return out;
}

function atr(candles: RealCandle[], period = 14): number {
  if (candles.length < period + 1) return 0;
  const trs = trueRanges(candles).slice(-period);
  return trs.reduce((a, b) => a + b, 0) / trs.length;
}

function ema(candles: RealCandle[], period: number): number {
  if (candles.length < period) return 0;
  const k = 2 / (period + 1);
  let value = candles.slice(0, period).reduce((s, c) => s + c.close, 0) / period;
  for (let i = period; i < candles.length; i++) value = candles[i].close * k + value * (1 - k);
  return value;
}

function efficiency(candles: RealCandle[], period = 20): number {
  if (candles.length < period + 1) return 0;
  const s = candles.slice(-period - 1);
  const net = Math.abs(s.at(-1)!.close - s[0].close);
  let path = 0;
  for (let i = 1; i < s.length; i++) path += Math.abs(s[i].close - s[i - 1].close);
  return path > 0 ? net / path : 0;
}

function median(values: number[]): number {
  if (!values.length) return 0;
  const a = [...values].sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

interface RegimeResult {
  regime: MarketRegime;
  atr: number;
  efficiency: number;
  rangeWidth: number;
  rangeAtr: number;
  emaSlopeAtr: number;
}

function detectRegime(candles: RealCandle[]): RegimeResult {
  if (candles.length < 60) return { regime: "UNKNOWN", atr: 0, efficiency: 0, rangeWidth: 0, rangeAtr: 0, emaSlopeAtr: 0 };
  const a = atr(candles, 14);
  if (!a) return { regime: "UNKNOWN", atr: 0, efficiency: 0, rangeWidth: 0, rangeAtr: 0, emaSlopeAtr: 0 };
  const recent = candles.slice(-24);
  const rangeWidth = Math.max(...recent.map(c => c.high)) - Math.min(...recent.map(c => c.low));
  const medRange = median(candles.slice(-60).map(c => c.high - c.low).filter(Boolean));
  const e = efficiency(candles, 20);
  const e20 = ema(candles, 20);
  const e20Prev = ema(candles.slice(0, -6), 20);
  const e50 = ema(candles, 50);
  const emaSlopeAtr = Math.abs(e20 - e20Prev) / a;
  const rangeAtr = rangeWidth / a;
  const compression = medRange > 0 ? rangeWidth / (medRange * recent.length) : 99;

  const consolidation = e < 0.38 && rangeAtr <= 7.0 && emaSlopeAtr < 0.70 && compression < 2.8;
  if (consolidation) return { regime: "CONSOLIDATION", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (rangeAtr >= 7.0 && e >= 0.55) return { regime: "EXPANSION", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (e20 > e50 && emaSlopeAtr >= 0.25 && e >= 0.38) return { regime: "TREND_UP", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  if (e20 < e50 && emaSlopeAtr >= 0.25 && e >= 0.38) return { regime: "TREND_DOWN", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
  return { regime: "RANGE", atr: a, efficiency: e, rangeWidth, rangeAtr, emaSlopeAtr };
}

interface Pivot { index: number; price: number; time: number; }
function pivots(candles: RealCandle[], side: "high" | "low", strength = 2): Pivot[] {
  const out: Pivot[] = [];
  for (let i = strength; i < candles.length - strength; i++) {
    const p = side === "high" ? candles[i].high : candles[i].low;
    let ok = true;
    for (let j = 1; j <= strength; j++) {
      if (side === "high" && (p < candles[i - j].high || p < candles[i + j].high)) ok = false;
      if (side === "low" && (p > candles[i - j].low || p > candles[i + j].low)) ok = false;
    }
    if (ok) out.push({ index: i, price: p, time: candles[i].time });
  }
  return out;
}

function structureBias(candles: RealCandle[], a: number): "BULLISH" | "BEARISH" | "NEUTRAL" {
  const hs = pivots(candles, "high", 3).slice(-5);
  const ls = pivots(candles, "low", 3).slice(-5);
  if (hs.length < 2 || ls.length < 2) return "NEUTRAL";
  const h1 = hs.at(-1)!.price, h0 = hs.at(-2)!.price;
  const l1 = ls.at(-1)!.price, l0 = ls.at(-2)!.price;
  const tol = Math.max(a * 0.10, 1e-9);
  if (h1 > h0 + tol && l1 > l0 + tol) return "BULLISH";
  if (h1 < h0 - tol && l1 < l0 - tol) return "BEARISH";
  return "NEUTRAL";
}

interface Sweep { direction: "BUY" | "SELL"; index: number; level: number; pivotIndex: number; }
function detectSweep(candles: RealCandle[], direction: "BUY" | "SELL", a: number): Sweep | null {
  if (candles.length < 35 || !a) return null;
  const highs = pivots(candles, "high", 2);
  const lows = pivots(candles, "low", 2);
  const start = Math.max(8, candles.length - 10);
  if (direction === "BUY") {
    for (let i = candles.length - 2; i >= start; i--) {
      const candidates = lows.filter(p => p.index < i - 1 && i - p.index <= 25);
      const p = candidates.at(-1);
      if (!p) continue;
      const c = candles[i];
      if (c.low < p.price - a * 0.03 && c.close > p.price + a * 0.02) return { direction, index: i, level: p.price, pivotIndex: p.index };
    }
  } else {
    for (let i = candles.length - 2; i >= start; i--) {
      const candidates = highs.filter(p => p.index < i - 1 && i - p.index <= 25);
      const p = candidates.at(-1);
      if (!p) continue;
      const c = candles[i];
      if (c.high > p.price + a * 0.03 && c.close < p.price - a * 0.02) return { direction, index: i, level: p.price, pivotIndex: p.index };
    }
  }
  return null;
}

function displacementAndMss(candles: RealCandle[], sweep: Sweep, a: number): { displacementIndex: number; mss: boolean; brokenLevel: number } | null {
  const end = Math.min(candles.length - 2, sweep.index + 4);
  for (let i = sweep.index + 1; i <= end; i++) {
    const c = candles[i];
    const body = Math.abs(c.close - c.open);
    const range = c.high - c.low;
    const bodyRatio = range > 0 ? body / range : 0;
    const directional = sweep.direction === "BUY" ? c.close > c.open : c.close < c.open;
    if (!directional || body < a * 0.85 || bodyRatio < 0.58) continue;
    const before = candles.slice(Math.max(sweep.pivotIndex + 1, sweep.index - 12), sweep.index + 1);
    const brokenLevel = sweep.direction === "BUY"
      ? Math.max(...before.map(x => x.high))
      : Math.min(...before.map(x => x.low));
    const mss = sweep.direction === "BUY" ? c.close > brokenLevel : c.close < brokenLevel;
    if (mss) return { displacementIndex: i, mss: true, brokenLevel };
    for (let j = i + 1; j <= Math.min(end + 2, candles.length - 2); j++) {
      const cj = candles[j];
      if ((sweep.direction === "BUY" && cj.close > brokenLevel) || (sweep.direction === "SELL" && cj.close < brokenLevel)) {
        return { displacementIndex: i, mss: true, brokenLevel };
      }
    }
  }
  return null;
}

function freshZone(candles: RealCandle[], displacementIndex: number, direction: "BUY" | "SELL", price: number, a: number) {
  // Pending-limit zone selection: do NOT require price to already be inside the zone.
  // A valid zone must be fresh, directional, and located on the retracement side of price.
  const candidates: Array<{ low: number; high: number; type: "BULLISH_OB" | "BEARISH_OB" | "BULLISH_FVG" | "BEARISH_FVG"; strength: number; sourceIndex: number }> = [];

  // Order blocks: last opposite candle before the displacement.
  for (let i = displacementIndex - 1; i >= Math.max(2, displacementIndex - 8); i--) {
    const c = candles[i];
    const body = Math.abs(c.close - c.open);
    const range = c.high - c.low;
    if (!range || body > a * 1.15) continue;

    if (direction === "BUY" && c.close < c.open) {
      const low = c.low, high = c.open;
      if (high < price) {
        const impulse = Math.max(0, candles[displacementIndex].close - c.high);
        const strength = Math.min(100, 55 + (impulse / Math.max(a, 1e-9)) * 18 + (1 - body / Math.max(a, 1e-9)) * 12);
        candidates.push({ low, high, type: "BULLISH_OB", strength, sourceIndex: i });
      }
    }
    if (direction === "SELL" && c.close > c.open) {
      const low = c.open, high = c.high;
      if (low > price) {
        const impulse = Math.max(0, c.low - candles[displacementIndex].close);
        const strength = Math.min(100, 55 + (impulse / Math.max(a, 1e-9)) * 18 + (1 - body / Math.max(a, 1e-9)) * 12);
        candidates.push({ low, high, type: "BEARISH_OB", strength, sourceIndex: i });
      }
    }
  }

  // FVGs created around the displacement. Require meaningful gap width.
  for (let i = Math.max(1, displacementIndex - 3); i <= Math.min(candles.length - 2, displacementIndex + 1); i++) {
    const left = candles[i - 1], right = candles[i + 1];
    if (!left || !right) continue;

    if (direction === "BUY" && right.low > left.high) {
      const low = left.high, high = right.low;
      const width = high - low;
      if (width >= a * 0.12 && high < price) {
        const strength = Math.min(100, 60 + (width / Math.max(a, 1e-9)) * 25);
        candidates.push({ low, high, type: "BULLISH_FVG", strength, sourceIndex: i });
      }
    }
    if (direction === "SELL" && right.high < left.low) {
      const low = right.high, high = left.low;
      const width = high - low;
      if (width >= a * 0.12 && low > price) {
        const strength = Math.min(100, 60 + (width / Math.max(a, 1e-9)) * 25);
        candidates.push({ low, high, type: "BEARISH_FVG", strength, sourceIndex: i });
      }
    }
  }

  // Prefer the strongest zone, then the closest valid retracement zone.
  candidates.sort((x, y) => {
    const strengthDelta = y.strength - x.strength;
    if (Math.abs(strengthDelta) > 4) return strengthDelta;
    const dx = Math.abs(((x.low + x.high) / 2) - price);
    const dy = Math.abs(((y.low + y.high) / 2) - price);
    return dx - dy;
  });

  const best = candidates[0];
  if (!best || best.strength < 68) return null;
  return best;
}

function targetFromStructure(candles: RealCandle[], entry: number, direction: "BUY" | "SELL", sl: number, minR = 2): number | null {
  const risk = Math.abs(entry - sl);
  if (!risk) return null;
  const minTarget = direction === "BUY" ? entry + risk * minR : entry - risk * minR;
  const ps = direction === "BUY" ? pivots(candles, "high", 2) : pivots(candles, "low", 2);
  const candidates = ps.map(p => p.price).filter(p => direction === "BUY" ? p >= minTarget : p <= minTarget);
  if (!candidates.length) return null;
  return direction === "BUY" ? Math.min(...candidates) : Math.max(...candidates);
}

function newsBlocked(events: any[], symbol: string, now = Date.now()) {
  const usdAsset = /XAU|GOLD|US100|NAS100|NASDAQ|BTC/i.test(symbol);
  if (!usdAsset || !Array.isArray(events)) return { blocked: false, event: null };
  const candidates = events.filter(e => String(e.currency || e.country || "").toUpperCase().includes("USD") && String(e.impact || e.forexFactoryImpact || "").toUpperCase() === "HIGH");
  let nearest: any = null, nearestAbs = Infinity;
  for (const e of candidates) {
    const t = new Date(e.date || e.time || e.timestamp || 0).getTime();
    if (!Number.isFinite(t) || t <= 0) continue;
    const d = Math.abs(t - now);
    if (d < nearestAbs) { nearestAbs = d; nearest = e; }
  }
  return { blocked: Boolean(nearest && nearestAbs <= 30 * 60 * 1000), event: nearest };
}

function score(parts: boolean[]): number {
  return n(parts.filter(Boolean).length / parts.length * 10, 1);
}

function validCandle(c: RealCandle): boolean {
  return [c.time, c.open, c.high, c.low, c.close].every(finite) && c.time > 0 && c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close) && c.high >= c.low;
}

function validateSeries(candles: RealCandle[], minCount: number, expectedMs: number, now: number) {
  if (!Array.isArray(candles) || candles.length < minCount) return { ok: false, reason: "INSUFFICIENT_TRADINGVIEW_CANDLES" };
  for (let i = 0; i < candles.length; i++) {
    if (!validCandle(candles[i])) return { ok: false, reason: `INVALID_OHLC_AT_${candles[i]?.time ?? "UNKNOWN"}` };
    if (i > 0 && candles[i].time <= candles[i - 1].time) return { ok: false, reason: "NON_MONOTONIC_CANDLE_TIMESTAMPS" };
  }
  const closed = candles.slice(0, -1);
  const last = closed.at(-1);
  if (!last) return { ok: false, reason: "NO_CLOSED_CANDLE" };
  const maxAge = Math.max(expectedMs * 3, 15 * 60 * 1000);
  if (now - last.time > maxAge) return { ok: false, reason: "STALE_TRADINGVIEW_CANDLES" };
  return { ok: true, reason: "OK" };
}

function baseRecovery(symbol: string, timeframe: string, reason: string): RealMarketAnalysis {
  return { status: "FEED_RECOVERY", type: "FEED_RECOVERY", orderExecutionType: "FEED_RECOVERY", symbol, timeframe, entry: 0, sl: 0, tp: 0, tp1: 0, tp2: 0, tp3: 0, rr: "1:0.0", confluenceScore: 0, confidence: 0, qualityGrade: "FEED_RECOVERY", regime: "UNKNOWN", marketState: "FEED_RECOVERY", setupId: null, signalSource: "TRADINGVIEW", newsSource: "UNAVAILABLE", diagnostic: { signalEligible: false }, rejectionReasons: [reason], reasoning: [reason], analysis: reason, formattedOutputSignalText: `${symbol} FEED_RECOVERY`, confidenceType: "CONFLUENCE_SCORE", createdAt: Date.now(), creationCandleTime: 0 };
}

function noSetup(symbol: string, timeframe: string, regime: MarketRegime, diagnostic: any, reasons: string[]): RealMarketAnalysis {
  diagnostic.signalEligible = false;
  diagnostic.rejectionReasons = reasons;
  return { status: "NO_VALID_SETUP", type: "NO_VALID_SETUP", orderExecutionType: "NO_VALID_SETUP", symbol, timeframe, entry: 0, sl: 0, tp: 0, tp1: 0, tp2: 0, tp3: 0, rr: "1:0.0", confluenceScore: 0, confidence: 0, qualityGrade: "NO_VALID_SETUP", regime, marketState: regime, setupId: null, signalSource: "TRADINGVIEW", newsSource: "FOREX_FACTORY", diagnostic, rejectionReasons: reasons, reasoning: ["Tidak ada sequence liquidity → displacement → MSS/BOS → confirmation yang lengkap."], analysis: reasons.join(" | "), formattedOutputSignalText: `${symbol} NO_VALID_SETUP`, confidenceType: "CONFLUENCE_SCORE", createdAt: Date.now(), creationCandleTime: 0 };
}

export function evaluateRealMarketSignal(args: { symbol: string; timeframe: string; currentPrice: number; candles: Record<string, RealCandle[]>; economicEvents?: any[]; now?: number }): RealMarketAnalysis {
  const { symbol, timeframe, currentPrice, candles, economicEvents = [], now = Date.now() } = args;
  const required: Array<[string, number, number]> = [["M5", 60, 5 * 60 * 1000], ["M15", 60, 15 * 60 * 1000], ["H1", 60, 60 * 60 * 1000], ["H4", 60, 4 * 60 * 60 * 1000]];
  if (!finite(currentPrice) || currentPrice <= 0) return baseRecovery(symbol, timeframe, "TRADINGVIEW_LIVE_PRICE_INVALID");
  for (const [tf, min, ms] of required) {
    const check = validateSeries(candles[tf] || [], min, ms, now);
    if (!check.ok) return baseRecovery(symbol, timeframe, `${tf}:${check.reason}`);
  }

  const m5 = candles.M5.slice(0, -1), m15 = candles.M15.slice(0, -1), h1 = candles.H1.slice(0, -1), h4 = candles.H4.slice(0, -1);
  const r5 = detectRegime(m5), r15 = detectRegime(m15), r1 = detectRegime(h1), r4 = detectRegime(h4);
  const h4Bias = structureBias(h4, r4.atr), h1Bias = structureBias(h1, r1.atr);
  const regime = r5.regime === "CONSOLIDATION" || r15.regime === "CONSOLIDATION" ? "CONSOLIDATION" : r5.regime;
  const news = newsBlocked(economicEvents, symbol, now);
  const diagnostics: Record<string, any> = {
    feedConnected: true, symbolMatched: true, timeframeMatched: true, source: "TRADINGVIEW", signalEngine: "REAL_MARKET_BRAIN",
    latestCandleTime: { M5: m5.at(-1)?.time, M15: m15.at(-1)?.time, H1: h1.at(-1)?.time, H4: h4.at(-1)?.time },
    latestPrice: currentPrice, regime, h4Bias, h1Bias,
    volatility: { M5: r5, M15: r15, H1: r1, H4: r4 },
    newsBlocked: news.blocked, signalEligible: false,
  };

  if (regime === "CONSOLIDATION" || regime === "RANGE") return noSetup(symbol, timeframe, regime, diagnostics, ["MARKET_CONSOLIDATION_OR_RANGE"]);
  if (news.blocked) return noSetup(symbol, timeframe, regime, diagnostics, ["HIGH_IMPACT_USD_NEWS_WINDOW"]);
  if (h4Bias === "NEUTRAL" || h1Bias === "NEUTRAL") return noSetup(symbol, timeframe, regime, diagnostics, ["HTF_STRUCTURE_NEUTRAL"]);

  const directions: Array<"BUY" | "SELL"> = [];
  if (h4Bias === "BULLISH" && h1Bias === "BULLISH") directions.push("BUY");
  if (h4Bias === "BEARISH" && h1Bias === "BEARISH") directions.push("SELL");
  if (directions.length !== 1) return noSetup(symbol, timeframe, regime, diagnostics, ["HTF_STRUCTURE_NOT_ALIGNED"]);

  const direction = directions[0];
  const a = r15.atr || atr(m15, 14);
  const sweep = detectSweep(m15, direction, a);
  diagnostics.liquiditySweep = Boolean(sweep);
  if (!sweep) return noSetup(symbol, timeframe, regime, diagnostics, [direction === "BUY" ? "NO_SELL_SIDE_LIQUIDITY_SWEEP" : "NO_BUY_SIDE_LIQUIDITY_SWEEP"]);

  const dm = displacementAndMss(m15, sweep, a);
  diagnostics.displacement = Boolean(dm);
  diagnostics.mssConfirmed = Boolean(dm?.mss);
  if (!dm) return noSetup(symbol, timeframe, regime, diagnostics, ["NO_VALID_DISPLACEMENT_OR_MSS"]);

  const zone = freshZone(m15, dm.displacementIndex, direction, currentPrice, a);
  diagnostics.zoneDetected = Boolean(zone);
  if (!zone) return noSetup(symbol, timeframe, regime, diagnostics, ["NO_FRESH_OB_OR_FVG"]);

  const m5a = atr(m5, 14) || a;
  const lastM5 = m5.at(-1)!;
  const prevM5 = m5.at(-2)!;
  const m5Body = Math.abs(lastM5.close - lastM5.open);
  const m5Range = lastM5.high - lastM5.low;
  const m5BodyRatio = m5Range > 0 ? m5Body / m5Range : 0;
  const m5Confirm = direction === "BUY"
    ? lastM5.close > lastM5.open && m5Body >= m5a * 0.45 && m5BodyRatio >= 0.55 && lastM5.close > prevM5.high
    : lastM5.close < lastM5.open && m5Body >= m5a * 0.45 && m5BodyRatio >= 0.55 && lastM5.close < prevM5.low;
  diagnostics.m5Confirmed = m5Confirm;
  if (!m5Confirm) return noSetup(symbol, timeframe, regime, diagnostics, ["M5_CONFIRMATION_MISSING"]);

  const zoneMid = (zone.low + zone.high) / 2;
  const entry = direction === "BUY"
    ? Math.min(zone.high, zoneMid + (zone.high - zone.low) * 0.15)
    : Math.max(zone.low, zoneMid - (zone.high - zone.low) * 0.15);

  // Limit order must remain a true retracement order, not a disguised market entry.
  if (direction === "BUY" && entry >= currentPrice) return noSetup(symbol, timeframe, regime, diagnostics, ["BUY_LIMIT_ZONE_NOT_BELOW_MARKET"]);
  if (direction === "SELL" && entry <= currentPrice) return noSetup(symbol, timeframe, regime, diagnostics, ["SELL_LIMIT_ZONE_NOT_ABOVE_MARKET"]);

  const structural = direction === "BUY"
    ? Math.min(...m15.slice(Math.max(0, sweep.index - 2), dm.displacementIndex + 1).map(c => c.low), zone.low)
    : Math.max(...m15.slice(Math.max(0, sweep.index - 2), dm.displacementIndex + 1).map(c => c.high), zone.high);
  const buffer = Math.max(m5a * 0.15, a * 0.05);
  const sl = direction === "BUY" ? Math.min(structural, zone.low) - buffer : Math.max(structural, zone.high) + buffer;
  const risk = Math.abs(entry - sl);
  diagnostics.limitOrder = {
    execution: direction === "BUY" ? "BUY_LIMIT" : "SELL_LIMIT",
    zoneType: zone.type,
    zoneLow: zone.low,
    zoneHigh: zone.high,
    zoneStrength: zone.strength,
    entry,
    marketPrice: currentPrice
  };
  diagnostics.risk = { entry, sl, risk, atr: a };
  if (!risk || risk > a * 2.75) return noSetup(symbol, timeframe, regime, diagnostics, ["STRUCTURAL_RISK_TOO_WIDE"]);

  const tp = targetFromStructure(h1, entry, direction, sl, 2);
  diagnostics.tpCandidate = tp;
  if (!tp) return noSetup(symbol, timeframe, regime, diagnostics, ["NO_STRUCTURAL_TARGET_WITH_RR_2"]);
  const rr = Math.abs(tp - entry) / risk;
  if (rr < 2) return noSetup(symbol, timeframe, regime, diagnostics, ["RR_BELOW_1_2"]);

  const components = [
    h4Bias === (direction === "BUY" ? "BULLISH" : "BEARISH"),
    h1Bias === (direction === "BUY" ? "BULLISH" : "BEARISH"),
    Boolean(sweep), Boolean(dm), Boolean(dm.mss), Boolean(zone), m5Confirm, rr >= 2,
  ];
  const confluence = score(components);
  diagnostics.rrValid = true;
  diagnostics.signalEligible = true;

  const creationCandleTime = m5.at(-1)!.time;
  const setupId = `TV_${symbol}_${direction}_${creationCandleTime}`;
  const reasoning = [
    `${direction}: H4/H1 structure aligned (${h4Bias}/${h1Bias}).`,
    `${direction}: liquidity sweep confirmed on closed M15 candle at ${n(sweep.level)}.`,
    `Displacement + MSS/BOS confirmed by closed-candle structure.`,
    `Fresh ${zone.type} confluence and independent M5 confirmation detected.`,
    `Structural risk valid; target is opposing H1 structure with RR ${rr.toFixed(2)}.`,
  ];
  return {
    status: "ACTIVE", type: direction, symbol, timeframe,
    entry: n(entry), sl: n(sl), tp: n(tp), tp1: n(tp), tp2: n(tp), tp3: n(tp),
    rr: `1:${rr.toFixed(1)}`, confluenceScore: confluence, confidence: confluence * 10,
    qualityGrade: confluence >= 8.5 ? "A — HIGH CONFLUENCE" : "B — VALID CONFLUENCE",
    regime, marketState: regime, setupId, signalSource: "TRADINGVIEW", newsSource: "FOREX_FACTORY",
    diagnostic: diagnostics, rejectionReasons: [], reasoning, analysis: reasoning.join(" "),
    orderExecutionType: direction,
    formattedOutputSignalText: `${direction === "BUY" ? "BUY LIMIT" : "SELL LIMIT"} @ ${n(entry)}`,
    confidenceType: "CONFLUENCE_SCORE", createdAt: now, creationCandleTime,
  };
}
