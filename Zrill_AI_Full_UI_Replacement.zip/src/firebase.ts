// Firebase is completely disabled per user constraints.
// The application uses SQLite/JSON-based Express server for session and auth management.
export const db: any = null;
export const auth: any = null;

// Lightweight stubs to allow smooth compilation without external Firebase libraries
export const doc = (...args: any[]) => ({}) as any;
export const collection = (...args: any[]) => ({}) as any;
export const query = (...args: any[]) => ({}) as any;
export const orderBy = (...args: any[]) => ({}) as any;
export const where = (...args: any[]) => ({}) as any;
export const limit = (...args: any[]) => ({}) as any;
export const setDoc = async (...args: any[]) => ({}) as any;
export const getDoc = async (...args: any[]) => ({
  exists: () => false,
  data: () => ({} as any)
});
export const getDocs = async (...args: any[]) => ({
  empty: true,
  docs: [] as any[],
  forEach: (cb: any) => {}
});
export const updateDoc = async (...args: any[]) => ({}) as any;
export const writeBatch = (...args: any[]) => ({
  set: (docRef: any, data: any) => {},
  commit: async () => {}
});
export const onSnapshot = (ref: any, callback: any, errorCallback?: any) => {
  // returns clean mock unsubscribe
  return () => {};
};
export const onAuthStateChanged = (authRef: any, callback: any) => {
  return () => {};
};
