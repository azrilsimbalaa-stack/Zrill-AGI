import { useEffect, useState, useCallback } from "react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

export interface AndroidVersionInfo {
  isAndroid: boolean;
  versionStr: string;
  versionNumber: number;
  isLegacy: boolean; // Android 4.0 - 7.1
  isModern: boolean; // Android 8.0 - 16.0+
  compatibilityBadge: string;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [androidInfo, setAndroidInfo] = useState<AndroidVersionInfo>({
    isAndroid: false,
    versionStr: "",
    versionNumber: 0,
    isLegacy: false,
    isModern: true,
    compatibilityBadge: "Android 4.0 - 16.0 Full Support",
  });

  useEffect(() => {
    // Detect standalone mode (already running as installed PWA)
    const isStandalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true ||
      document.referrer.includes("android-app://");
    setIsInstalled(isStandalone);

    // Detect User Agent
    const ua = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(ua);
    setIsIOS(isIOSDevice);

    const isAndroidDevice = /android/.test(ua);
    let verNum = 0;
    let verStr = "";
    if (isAndroidDevice) {
      const match = ua.match(/android\s([0-9\.]+)/);
      if (match && match[1]) {
        verStr = match[1];
        verNum = parseFloat(match[1]);
      }
    }

    const isLegacy = isAndroidDevice && verNum > 0 && verNum < 8.0;
    const isModern = !isAndroidDevice || verNum >= 8.0;

    let compatibilityBadge = "Semua Versi Android (4.0 - 16.0) Kompatibel";
    if (verNum > 0) {
      if (verNum >= 16.0) {
        compatibilityBadge = `Android ${verStr} (Baklava 16.0) - High Performance WebAPK`;
      } else if (verNum >= 15.0) {
        compatibilityBadge = `Android ${verStr} (Vanilla Ice Cream 15.0) - Native WebAPK`;
      } else if (verNum >= 14.0) {
        compatibilityBadge = `Android ${verStr} (Upside Down Cake 14.0) - Native WebAPK`;
      } else if (verNum >= 10.0) {
        compatibilityBadge = `Android ${verStr} - 1-Click WebAPK Supported`;
      } else if (verNum >= 8.0) {
        compatibilityBadge = `Android ${verStr} (Oreo/Pie) - WebAPK Standalone`;
      } else {
        compatibilityBadge = `Android ${verStr} (Legacy KitKat/Lollipop/Nougat) - APK Wrapper Ready`;
      }
    }

    setAndroidInfo({
      isAndroid: isAndroidDevice,
      versionStr: verStr || "All Versions",
      versionNumber: verNum,
      isLegacy,
      isModern,
      compatibilityBadge,
    });

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const installPWA = useCallback(async (): Promise<boolean> => {
    if (!deferredPrompt) {
      return false;
    }
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsInstalled(true);
        setDeferredPrompt(null);
        return true;
      }
    } catch (err) {
      console.warn("PWA install error:", err);
    }
    return false;
  }, [deferredPrompt]);

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isIOS,
    androidInfo,
    installPWA,
    deferredPrompt,
  };
}
