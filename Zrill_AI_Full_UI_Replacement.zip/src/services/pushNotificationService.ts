// ZRILL SHARK AI & News Real-Time Push Notification Engine
// Supports Android 6.0 through Android 16.0 Native Web & PWA Push Notifications

export interface NotificationPayload {
  title: string;
  body: string;
  tag?: string;
  icon?: string;
  badge?: string;
  data?: any;
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === "undefined" || !("Notification" in window)) {
    console.warn("Notifications not supported in this browser/environment.");
    return false;
  }

  if (Notification.permission === "granted") {
    return true;
  }

  if (Notification.permission !== "denied") {
    try {
      const permission = await Notification.requestPermission();
      return permission === "granted";
    } catch (e) {
      console.warn("Notification permission request error:", e);
      return false;
    }
  }

  return false;
}

export function isNotificationSupportedAndGranted(): boolean {
  if (typeof window === "undefined" || !("Notification" in window)) return false;
  return Notification.permission === "granted";
}

// Play Futuristic Sound Alert on Push
export function playNotificationSound() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    // High tech two-tone notification ping
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(1318.51, ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.4);
  } catch (e) {}
}

export async function sendZrilPushNotification(payload: NotificationPayload): Promise<boolean> {
  if (typeof window === "undefined" || !("Notification" in window)) return false;

  const isGranted = Notification.permission === "granted" || (await requestNotificationPermission());
  if (!isGranted) return false;

  playNotificationSound();

  const icon = payload.icon || "/zrill-shark-logo.png";
  const badge = payload.badge || "/pwa-192x192.png";

  try {
    if ("serviceWorker" in navigator && navigator.serviceWorker.ready) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification(payload.title, {
        body: payload.body,
        icon,
        badge,
        tag: payload.tag || "zrill-shark-alert",
        vibrate: [200, 100, 200],
        requireInteraction: false,
        data: payload.data || { url: window.location.origin },
      } as NotificationOptions);
      return true;
    } else {
      new Notification(payload.title, {
        body: payload.body,
        icon,
        tag: payload.tag || "zrill-shark-alert",
      });
      return true;
    }
  } catch (e) {
    console.warn("Push notification send error:", e);
    return false;
  }
}
