import React, { useState } from "react";
import { Download, Smartphone, ArrowDownToLine, CheckCircle2 } from "lucide-react";
import { usePWAInstall } from "../hooks/usePWAInstall";
import { AndroidApkInstallerModal } from "./AndroidApkInstallerModal";

interface PWAInstallButtonProps {
  onOpenApkModal?: () => void;
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  onOpenApkModal,
  className = "",
}) => {
  const { isInstallable, isInstalled, isIOS, androidInfo, installPWA } = usePWAInstall();
  const [showInternalModal, setShowInternalModal] = useState(false);

  const handleClick = () => {
    if (onOpenApkModal) {
      onOpenApkModal();
    } else {
      setShowInternalModal(true);
    }
  };

  return (
    <>
      <button
        onClick={handleClick}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500/30 via-teal-500/25 to-emerald-500/30 hover:from-emerald-500/40 hover:to-teal-500/40 text-emerald-300 border-2 border-emerald-500/50 text-[10px] sm:text-[11px] font-black tracking-wide transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] cursor-pointer active:scale-95 uppercase font-mono ${className}`}
        title="Pasang Web App untuk Android, iOS, dan Desktop"
      >
        <ArrowDownToLine className="w-4 h-4 text-emerald-400 animate-bounce" />
        <span>PASANG WEB APP</span>
        <span className="hidden sm:inline-block px-1.5 py-0.2 rounded bg-emerald-500/40 text-[8.5px] text-white font-black ml-0.5">
          FULLSCREEN
        </span>
      </button>

      {showInternalModal && (
        <AndroidApkInstallerModal
          isOpen={showInternalModal}
          onClose={() => setShowInternalModal(false)}
        />
      )}
    </>
  );
};
