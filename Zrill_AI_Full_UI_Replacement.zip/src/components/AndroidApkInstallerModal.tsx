import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Smartphone,
  Download,
  CheckCircle2,
  X,
  RefreshCw,
  Zap,
  ShieldCheck,
  ExternalLink,
  Layers,
  Sparkles,
  ArrowDownToLine,
  Check,
  Globe,
  Maximize,
  HelpCircle,
} from "lucide-react";
import { usePWAInstall } from "../hooks/usePWAInstall";

interface AndroidApkInstallerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkInstallerModal: React.FC<AndroidApkInstallerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isInstallable, isInstalled, isIOS, androidInfo, installPWA } = usePWAInstall();

  const [activeTab, setActiveTab] = useState<"DIRECT_PWA" | "GUIDE">("DIRECT_PWA");
  const [apkAppName, setApkAppName] = useState("Zrill AI");
  const [apkPackageName, setApkPackageName] = useState("com.zrill.ai");
  const [minSdkVersion] = useState("21 (Android 5.0+)");
  const [targetSdkVersion] = useState("34 (Android 14)");
  const [isFullscreenActive, setIsFullscreenActive] = useState(false);

  const [isCompilingApk, setIsCompilingApk] = useState(false);
  const [apkCompileProgress, setApkCompileProgress] = useState(0);
  const [apkCompileLogs, setApkCompileLogs] = useState<string[]>([]);
  const [apkCompiledSuccessfully, setApkCompiledSuccessfully] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const triggerFullscreenImmersive = () => {
    try {
      const docEl = document.documentElement as any;
      if (!document.fullscreenElement && !docEl.webkitFullscreenElement) {
        if (docEl.requestFullscreen) {
          docEl.requestFullscreen();
        } else if (docEl.webkitRequestFullscreen) {
          docEl.webkitRequestFullscreen();
        } else if (docEl.msRequestFullscreen) {
          docEl.msRequestFullscreen();
        }
        setIsFullscreenActive(true);
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if ((document as any).webkitExitFullscreen) {
          (document as any).webkitExitFullscreen();
        }
        setIsFullscreenActive(false);
      }
    } catch (e) {
      console.warn("Fullscreen toggle error:", e);
    }
  };

  const handleDirectInstall = async () => {
    if (isInstallable) {
      const ok = await installPWA();
      if (ok) {
        onClose();
      }
    } else {
      // If browser doesn't support direct prompt, guide the user
      alert("Untuk memasang WebApp di HP Android:\n1. Ketuk ikon titik 3 (⋮) di kanan atas browser Chrome/browser HP Anda\n2. Pilih 'Instal Aplikasi' atau 'Tambahkan ke Layar Utama'\n3. Aplikasi ZRILL SHARK akan langsung terpasang di layar utama HP Anda tanpa batas!");
    }
  };

  const handleDirectDownloadApkFile = () => {
    const downloadUrl = `/api/apk/download?name=${encodeURIComponent(apkAppName)}&package=${encodeURIComponent(apkPackageName)}&t=${Date.now()}`;
    const link = document.createElement("a");
    link.href = downloadUrl;
    link.download = "ZRILL_SHARK_v5_Apex_Terminal.apk";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyAppUrl = () => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <motion.div
      key="apk-modal-backdrop"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
      onClick={onClose}
      className="fixed inset-0 bg-black/85 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xl overflow-y-auto"
    >
      <motion.div
        key="apk-modal-content"
        drag="y"
        dragConstraints={{ top: 0, bottom: 0 }}
        dragElastic={{ top: 0.04, bottom: 0.65 }}
        onDragEnd={(_e, info) => {
          if (info.offset.y > 50 || info.velocity.y > 260) {
            onClose();
          }
        }}
        initial={{ y: 50, opacity: 0, scale: 0.96 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: 50, opacity: 0, scale: 0.94 }}
        transition={{ type: "spring", stiffness: 500, damping: 35 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-[#090d16]/98 backdrop-blur-3xl border-2 border-cyan-500/40 rounded-[28px] w-full max-w-lg p-4 sm:p-6 shadow-[0_25px_70px_rgba(0,0,0,0.95),0_0_30px_rgba(0,240,255,0.2)] relative transform-gpu select-none max-h-[92vh] overflow-y-auto font-sans"
      >
        {/* Drag Pill */}
        <div className="w-10 h-1 bg-white/30 hover:bg-white/45 active:bg-white/60 rounded-full mx-auto -mt-1 mb-3 cursor-grab transition-colors" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-all cursor-pointer border border-white/15"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/30 to-blue-600/30 border border-cyan-400/50 flex items-center justify-center shadow-[0_0_25px_rgba(0,240,255,0.4)] shrink-0 overflow-hidden">
            <img
              src="/zrill-shark-logo.png"
              alt="ZRILL SHARK"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = "/zrill-logo.png";
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                Instalasi ZRILL SHARK WebApp
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/25 text-cyan-300 border border-cyan-400/50 font-mono text-[9px] font-black uppercase">
                100% BEBAS ERROR
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5 font-mono">
              Bebas blokir Google Play Protect &bull; Fullscreen Tanpa Status Bar
            </p>
          </div>
        </div>

        {/* Solusi Terbaik: 1-Click Native WebAPK Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/70 via-black to-emerald-950/70 border-2 border-cyan-400/60 shadow-[0_0_25px_rgba(0,240,255,0.25)] mb-4 flex flex-col gap-3 font-mono">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-xs font-black text-cyan-300 uppercase tracking-wide">
                METODE RESMI WEBAPK (100% BISA DI SEMUA ANDROID)
              </span>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[9px] font-bold">
              ANDROID 4.0 - 16.0
            </span>
          </div>

          <p className="text-[11px] text-gray-200 leading-relaxed">
            Format WebApp resmi Android langsung dipasang ke layar utama HP Anda dengan ikon ZRILL SHARK, 100% fullscreen tanpa status bar, dan <strong>tidak akan pernah gagal install</strong> karena telah terverifikasi secara instan!
          </p>

          <button
            onClick={handleDirectInstall}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-300 to-emerald-400 hover:brightness-110 active:scale-98 text-black font-black text-sm tracking-wider transition-all flex items-center justify-center gap-2.5 shadow-[0_0_30px_rgba(0,240,255,0.5)] cursor-pointer"
          >
            <Sparkles className="w-5 h-5 text-black" />
            <span>PASANG APLIKASI KE HP SEKARANG (1-KLIK)</span>
          </button>
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-black/60 border border-white/10 mb-4 text-xs font-bold font-mono">
          <button
            onClick={() => setActiveTab("DIRECT_PWA")}
            className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "DIRECT_PWA"
                ? "bg-cyan-500/25 text-cyan-300 border border-cyan-400/50 shadow-sm"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Pasang WebApp</span>
          </button>
          <button
            onClick={() => setActiveTab("GUIDE")}
            className={`py-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "GUIDE"
                ? "bg-cyan-500/25 text-cyan-300 border border-cyan-400/50 shadow-sm"
                : "text-gray-400 hover:text-white"
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Panduan HP</span>
          </button>
        </div>

        {/* Tab 1: Direct PWA Install Guide */}
        {activeTab === "DIRECT_PWA" && (
          <div className="space-y-3.5 text-xs text-gray-300 font-mono">
            <div className="p-3.5 rounded-xl bg-black/50 border border-cyan-500/30 space-y-2">
              <span className="text-[10px] font-bold text-cyan-300 uppercase tracking-widest block">
                3 Langkah Pasang di Chrome / Browser HP Android:
              </span>
              <ol className="list-decimal pl-4 space-y-1.5 text-gray-200 text-[11px] leading-relaxed">
                <li>Buka terminal ini di browser <strong>Chrome</strong> HP Android Anda.</li>
                <li>Ketuk ikon <strong>Menu Titik Tiga (⋮)</strong> di sudut kanan atas browser.</li>
                <li>Pilih <strong>&quot;Instal Aplikasi&quot;</strong> atau <strong>&quot;Tambahkan ke Layar Utama&quot;</strong>.</li>
                <li>Ikon <strong>ZRILL SHARK</strong> langsung muncul di menu aplikasi HP Anda, siap digunakan secara fullscreen!</li>
              </ol>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleCopyAppUrl}
                className="flex-1 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-gray-200 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Layers className="w-4 h-4 text-cyan-400" />}
                <span>{copiedLink ? "Link Terminal Tersalin!" : "Salin Link WebApp"}</span>
              </button>

              <button
                onClick={triggerFullscreenImmersive}
                className="py-2.5 px-4 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Maximize className="w-4 h-4" />
                <span>Layar Penuh</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 3: Detailed Compatibility & Browser Guide */}
        {activeTab === "GUIDE" && (
          <div className="space-y-3 text-xs text-gray-300 font-mono">
            <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2">
              <span className="font-bold text-cyan-300 block uppercase text-[10px]">
                Panduan Pasang di Berbagai Browser HP:
              </span>
              <div className="space-y-1.5 text-[11px] text-gray-300">
                <p><strong>Google Chrome:</strong> Titik 3 di kanan atas &rarr; Pilih &quot;Instal Aplikasi&quot;.</p>
                <p><strong>Samsung Internet:</strong> Menu garis 3 di kanan bawah &rarr; &quot;Tambahkan Halaman Ke&quot; &rarr; Layar Depan.</p>
                <p><strong>Xiaomi / Mi Browser:</strong> Titik 3 di bawah &rarr; Tambahkan ke Layar Utama.</p>
                <p><strong>Oppo / Vivo / Realme Browser:</strong> Menu &rarr; Pasang ke Beranda HP.</p>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};
