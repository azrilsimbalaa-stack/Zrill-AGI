import React, { useEffect, useRef, useState, memo } from "react";
import { Lock, Unlock, Sparkles } from "lucide-react";

interface TradingViewChartProps {
  symbol: string;
  timeframe: string;
  theme?: "dark" | "light";
  height?: number | string;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = memo(({
  symbol,
  timeframe,
  theme = "dark",
  height = "100%",
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const containerId = useRef(`tradingview_widget_${Math.random().toString(36).substring(2, 9)}`);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [isCreatorMode, setIsCreatorMode] = useState<boolean>(false);

  const getTradingViewSymbol = (sym: string): string => {
    const clean = (sym || "").toUpperCase().replace("/", "").trim();
    if (clean.includes("BTC") || clean.includes("BITCOIN")) return "COINBASE:BTCUSD";
    if (clean.includes("XAU") || clean.includes("GOLD")) return "OANDA:XAUUSD";
    if (clean.includes("EURUSD")) return "FX:EURUSD";
    if (clean.includes("GBPUSD")) return "FX:GBPUSD";
    if (clean.includes("USDJPY")) return "FX:USDJPY";
    if (clean.includes("AUDUSD")) return "FX:AUDUSD";
    if (clean.includes("USDCAD")) return "FX:USDCAD";
    if (clean.includes("USDCHF")) return "FX:USDCHF";
    if (clean.includes("NZDUSD")) return "FX:NZDUSD";
    if (clean.includes("ETH")) return "BINANCE:ETHUSDT";
    if (clean.includes("SOL")) return "BINANCE:SOLUSDT";
    return `OANDA:${clean}`;
  };

  const getTradingViewInterval = (tf: string): string => {
    const clean = (tf || "").toUpperCase().trim();
    if (clean === "M1" || clean === "1M" || clean === "1") return "1";
    if (clean === "M5" || clean === "5M" || clean === "5") return "5";
    if (clean === "M15" || clean === "15M" || clean === "15") return "15";
    if (clean === "M30" || clean === "30M" || clean === "30") return "30";
    if (clean === "H1" || clean === "1H" || clean === "60") return "60";
    if (clean === "H4" || clean === "4H" || clean === "240") return "240";
    if (clean === "D1" || clean === "1D" || clean === "D") return "D";
    if (clean === "W1" || clean === "1W" || clean === "W") return "W";
    return "15";
  };

  useEffect(() => {
    const currentContainer = containerRef.current;
    if (!currentContainer) return;

    currentContainer.innerHTML = "";
    const widgetDiv = document.createElement("div");
    widgetDiv.id = containerId.current;
    widgetDiv.style.width = "100%";
    widgetDiv.style.height = "100%";
    currentContainer.appendChild(widgetDiv);

    const initTvWidget = () => {
      if ((window as any).TradingView && widgetDiv) {
        new (window as any).TradingView.widget({
          autosize: true,
          symbol: getTradingViewSymbol(symbol),
          interval: getTradingViewInterval(timeframe),
          timezone: "Asia/Makassar",
          theme: theme,
          style: "1",
          locale: "en",
          toolbar_bg: "#060911",
          enable_publishing: isCreatorMode,
          allow_symbol_change: isCreatorMode,
          hide_side_toolbar: !isCreatorMode,
          hide_top_toolbar: !isCreatorMode,
          hide_legend: !isCreatorMode,
          withdateranges: isCreatorMode,
          save_image: isCreatorMode,
          container_id: containerId.current,
          studies: isCreatorMode ? [
            "RSI@tv-basicstudies",
            "MASimple@tv-basicstudies"
          ] : [],
          disabled_features: isCreatorMode ? [
            "widget_logo",
            "countdown"
          ] : [
            "header_widget",
            "left_toolbar",
            "control_bar",
            "timeframes_toolbar",
            "legend_widget",
            "symbol_info",
            "context_menus",
            "display_market_status",
            "volume_force_overlay",
            "create_volume_indicator_by_default",
            "show_interval_dialog_on_key_press",
            "snapshot_trading_drawings",
            "use_localstorage_for_settings",
            "edit_buttons_in_legend_widget",
            "property_pages",
            "go_to_date",
            "popup_hints",
            "show_object_tree",
            "source_selection_markers",
            "pane_context_menu",
            "scales_context_menu",
            "main_series_scale_menu",
            "chart_property_page_style",
            "chart_property_page_background",
            "chart_property_page_timezone_sessions",
            "chart_property_page_scales",
            "widget_logo",
            "countdown",
            "symbol_search_hot_key",
            "format_button_in_legend",
            "study_buttons_in_legend",
            "delete_button_in_legend",
            "show_hide_button_in_legend",
            "drawing_templates",
            "items_favoriting",
            "click_to_select_bar"
          ],
          enabled_features: isCreatorMode ? [
            "header_widget",
            "left_toolbar",
            "control_bar",
            "timeframes_toolbar",
            "legend_widget",
            "symbol_info"
          ] : [],
          loading_screen: { backgroundColor: "#060911", foregroundColor: "#2563eb" },
          overrides: {
            "mainSeriesProperties.candleStyle.upColor": "#2563eb",
            "mainSeriesProperties.candleStyle.downColor": "#ffffff",
            "mainSeriesProperties.candleStyle.drawWick": true,
            "mainSeriesProperties.candleStyle.drawBorder": true,
            "mainSeriesProperties.candleStyle.borderColor": "#2563eb",
            "mainSeriesProperties.candleStyle.borderUpColor": "#2563eb",
            "mainSeriesProperties.candleStyle.borderDownColor": "#ffffff",
            "mainSeriesProperties.candleStyle.wickColor": "#2563eb",
            "mainSeriesProperties.candleStyle.wickUpColor": "#2563eb",
            "mainSeriesProperties.candleStyle.wickDownColor": "#ffffff",
            "volumePaneSize": "none",
            "paneProperties.legendProperties.showVolume": false,
            "paneProperties.legendProperties.showSeriesTitle": false,
            "paneProperties.legendProperties.showSeriesOHLC": false,
            "paneProperties.legendProperties.showLegend": false,
            "paneProperties.legendProperties.showBarChange": false,
            "symbolWatermarkProperties.transparency": 100,
            "symbolWatermarkProperties.color": "rgba(0, 0, 0, 0)",
            "scalesProperties.showSymbolLabels": false,
            "scalesProperties.showStudyPlotLabels": false,
            "mainSeriesProperties.showPriceLine": true,
            "paneProperties.background": "#060911",
            "paneProperties.backgroundType": "solid",
            "paneProperties.vertGridProperties.color": "rgba(0, 0, 0, 0)",
            "paneProperties.horzGridProperties.color": "rgba(0, 0, 0, 0)",
            "paneProperties.crossHairProperties.color": "rgba(37, 99, 235, 0.4)",
            "scalesProperties.lineColor": "rgba(255, 255, 255, 0.06)",
            "scalesProperties.textColor": "#94a3b8",
            "paneProperties.topMargin": 12,
            "paneProperties.bottomMargin": 12,
          },
        });
      }
    };

    if (!(window as any).TradingView) {
      const existingScript = document.getElementById("tradingview-tv-js-script");
      if (!existingScript) {
        const script = document.createElement("script");
        script.id = "tradingview-tv-js-script";
        script.src = "https://s3.tradingview.com/tv.js";
        script.type = "text/javascript";
        script.onload = initTvWidget;
        document.head.appendChild(script);
      } else {
        existingScript.addEventListener("load", initTvWidget);
      }
    } else {
      initTvWidget();
    }

    return () => {
      if (currentContainer) {
        currentContainer.innerHTML = "";
      }
    };
  }, [symbol, timeframe, theme, isCreatorMode]);

  return (
    <div
      className="w-full h-full relative group overflow-hidden transform-gpu contain-paint will-change-transform"
      style={{ height, touchAction: isLocked ? "none" : "manipulation" }}
    >
      {/* Control Panel in Top Right */}
      <div className="absolute top-3 right-3 z-30 flex items-center gap-2 pointer-events-auto">
        {/* Lock/Unlock Control Button */}
        <button
          type="button"
          onClick={() => setIsLocked(!isLocked)}
          className={`px-3 py-1.5 rounded-xl text-[10px] font-mono font-bold tracking-wider flex items-center gap-1.5 backdrop-blur-md border transition-all cursor-pointer shadow-lg active:scale-95 ${
            isLocked
              ? "bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-[0_0_15px_rgba(244,63,94,0.3)] ring-1 ring-rose-500/50"
              : "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.3)] hover:bg-emerald-500/30"
          }`}
        >
          {isLocked ? (
            <>
              <Lock className="w-3 h-3 text-rose-400" />
              <span>LOCK</span>
            </>
          ) : (
            <>
              <Unlock className="w-3 h-3 text-emerald-400 animate-pulse" />
              <span>UNLOCKED</span>
            </>
          )}
        </button>
      </div>

      {/* Lock Overlay when isLocked is active to prevent dragging/shifting */}
      {isLocked && (
        <div
          className="absolute inset-0 z-20 bg-transparent cursor-not-allowed select-none"
          title="Chart dikunci. Klik tombol POSISI DIKUNCI untuk mengaktifkan geser bebas."
        />
      )}

      {/* Pure Candlestick Canvas Container */}
      <div className="w-full h-full relative transform-gpu" ref={containerRef} />
    </div>
  );
}, (prevProps, nextProps) => {
  return (
    prevProps.symbol === nextProps.symbol &&
    prevProps.timeframe === nextProps.timeframe &&
    prevProps.theme === nextProps.theme &&
    prevProps.height === nextProps.height
  );
});
