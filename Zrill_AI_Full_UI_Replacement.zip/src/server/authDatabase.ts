import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";

export interface UserRecord {
  id: string;
  name: string; // lowercase unique
  displayName: string;
  password: string; // bcrypt hash
  status: "pending" | "approved" | "banned";
  role: "user" | "admin" | "admin_limited";
  active_until: number | null; // timestamp ms or null for unlimited/permanent
  created_at: number;
  last_login: number;
  email?: string;
  is_banned?: boolean;
}

export interface SessionRecord {
  token: string;
  user_id: string;
  device_id?: string;
  expires_at: number;
}

export interface AdminLogRecord {
  id: string;
  admin_name?: string;
  admin_email?: string;
  action: string;
  target_user?: string;
  target?: string;
  timestamp: number;
}

export interface AuthDatabaseSchema {
  users: Record<string, UserRecord>;
  sessions: Record<string, SessionRecord>;
  admin_logs: AdminLogRecord[];
  access_codes: Record<string, any>;
  device_bindings: Record<string, any>;
}

const DB_FILE = path.join(process.cwd(), "data_auth_db.json");

export function hashPassword(plain: string): string {
  try {
    return bcrypt.hashSync(plain, 10);
  } catch (e) {
    // fallback if any
    return plain;
  }
}

export function comparePassword(plain: string, hash: string): boolean {
  try {
    if (!hash) return false;
    if (hash === plain) return true; // plain fallback compatibility
    return bcrypt.compareSync(plain, hash);
  } catch (e) {
    return hash === plain;
  }
}

function getDefaultData(): AuthDatabaseSchema {
  const defaultAzrilPass = hashPassword("azril");
  const now = Date.now();

  return {
    users: {
      azril: {
        id: "usr_azril_1",
        name: "azril",
        displayName: "Azril (Admin Utama)",
        password: defaultAzrilPass,
        status: "approved",
        role: "admin",
        active_until: null,
        created_at: now,
        last_login: now,
      }
    },
    sessions: {},
    admin_logs: [
      {
        id: "log_init_1",
        admin_name: "azril",
        action: "INITIALIZE_SYSTEM",
        target_user: "System",
        timestamp: now,
      },
    ],
    access_codes: {},
    device_bindings: {},
  };
}

export function loadAuthDb(): AuthDatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, "utf-8");
      const parsed = JSON.parse(content);
      
      const db: AuthDatabaseSchema = {
        users: parsed.users || {},
        sessions: parsed.sessions || {},
        admin_logs: parsed.admin_logs || [],
        access_codes: parsed.access_codes || {},
        device_bindings: parsed.device_bindings || {},
      };

      // Remove any legacy dummy users
      const dummyKeys = ["user a", "user b", "user c", "user d", "user e", "user f", "admin", "mirza"];
      let changed = false;
      for (const dKey of dummyKeys) {
        if (db.users[dKey]) {
          delete db.users[dKey];
          changed = true;
        }
      }

      // Ensure azril exists as primary admin
      const defaultData = getDefaultData();
      if (!db.users["azril"]) {
        db.users["azril"] = defaultData.users["azril"];
        changed = true;
      }

      if (changed) {
        saveAuthDb(db);
      }

      return db;
    }
  } catch (e) {
    console.error("Auth DB load warning:", e);
  }

  const defaultData = getDefaultData();
  saveAuthDb(defaultData);
  return defaultData;
}

export function saveAuthDb(db: AuthDatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (e) {
    console.error("Auth DB save error:", e);
  }
}
