#!/usr/bin/env python3
import urllib.request
import re
import json
import sys
from datetime import datetime, timezone, timedelta

def parse_ff_datetime(date_str, time_str, year=2026):
    months = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
              "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
    
    m_match = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\s*(\d+)", date_str, re.I)
    if not m_match:
        return datetime(year, 9, 11, 12, 0, tzinfo=timezone.utc).isoformat()
        
    month = months[m_match.group(1).lower()]
    day = int(m_match.group(2))
    
    hour = 12
    minute = 0
    t_match = re.search(r"(\d+)(?::(\d+))?\s*(am|pm)", time_str, re.I)
    if t_match:
        h = int(t_match.group(1))
        m = int(t_match.group(2) or 0)
        ampm = t_match.group(3).lower()
        if ampm == "pm" and h < 12:
            h += 12
        elif ampm == "am" and h == 12:
            h = 0
        hour = h
        minute = m
    
    # Forex Factory uses Eastern Time (EDT is UTC-4 in September)
    edt = timezone(timedelta(hours=-4))
    dt_local = datetime(year, month, day, hour, minute, tzinfo=edt)
    dt_utc = dt_local.astimezone(timezone.utc)
    return dt_utc.strftime("%Y-%m-%dT%H:%M:%S.000Z")

def scrape_week(week="this"):
    url = f"https://www.forexfactory.com/calendar?week={week}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate"
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=12) as resp:
        html = resp.read().decode("windows-1252", errors="ignore")
    
    rows = re.findall(r"<tr[^>]*data-event-id=\"(\d+)\"[^>]*>([\s\S]*?)</tr>", html)
    events = []
    curr_date = ""
    curr_time = ""
    
    for event_id, content in rows:
        cells = re.findall(r"<td[^>]*class=\"([^\"]*)\"[^>]*>([\s\S]*?)</td>", content)
        row_data = {
            "id": f"ff-{event_id}",
            "eventId": event_id
        }
        
        for cclass, cval in cells:
            clean = re.sub(r"<[^>]+>", " ", cval).strip()
            clean = re.sub(r"\s+", " ", clean)
            for key in ["date", "time", "currency", "impact", "event", "actual", "forecast", "previous"]:
                if f"calendar__{key}" in cclass:
                    row_data[key] = clean
                    if key == "impact":
                        m = re.search(r"icon--ff-impact-([a-z]+)", cval)
                        row_data["impact_code"] = m.group(1) if m else "yel"
        
        if row_data.get("date"):
            curr_date = row_data["date"]
        else:
            row_data["date"] = curr_date
            
        if row_data.get("time"):
            curr_time = row_data["time"]
        else:
            row_data["time"] = curr_time
            
        # Parse currency & country (Strictly USD Only)
        curr = (row_data.get("currency") or "USD").upper()
        if curr != "USD":
            continue
        country = "US"
        
        # Parse impact code to folder and importance
        code = row_data.get("impact_code", "yel")
        if code == "red":
            impact = "HIGH"
            folder = "RED_FOLDER"
            importance = 1
            label = "FOREX FACTORY HIGH IMPACT (RED FOLDER)"
        elif code == "ora":
            impact = "MEDIUM"
            folder = "ORANGE_FOLDER"
            importance = 0
            label = "FOREX FACTORY MEDIUM IMPACT (ORANGE FOLDER)"
        elif code == "gra":
            impact = "HOLIDAY"
            folder = "GRAY_FOLDER"
            importance = -1
            label = "FOREX FACTORY HOLIDAY (GRAY FOLDER)"
        else:
            impact = "LOW"
            folder = "YELLOW_FOLDER"
            importance = -1
            label = "FOREX FACTORY LOW IMPACT (YELLOW FOLDER)"
            
        # Generate ISO date
        iso_date = parse_ff_datetime(curr_date, curr_time, 2026)
        
        title = row_data.get("event") or "Economic Event"
        actual = row_data.get("actual") or None
        forecast = row_data.get("forecast") or None
        previous = row_data.get("previous") or None
        
        events.append({
            "id": row_data["id"],
            "title": title,
            "currency": curr,
            "country": country,
            "date": iso_date,
            "rawDate": curr_date,
            "rawTime": curr_time,
            "impact": impact,
            "importance": importance,
            "forexFactoryImpact": impact,
            "forexFactoryFolder": folder,
            "forexFactoryLabel": label,
            "forecast": forecast if forecast else "---",
            "previous": previous if previous else "---",
            "actual": actual if actual else None,
            "source": "Forex Factory Official (https://www.forexfactory.com/calendar)",
            "isForexFactoryOfficial": True,
            "isForexFactoryCalibrated": True
        })
    return events

def main():
    include_next = "--include-next" in sys.argv
    all_events = []
    seen_ids = set()
    
    try:
        this_week = scrape_week("this")
        for ev in this_week:
            if ev["id"] not in seen_ids:
                seen_ids.add(ev["id"])
                all_events.append(ev)
    except Exception as e:
        sys.stderr.write(f"Error scraping this week: {e}\n")
        
    if include_next:
        try:
            next_week = scrape_week("next")
            for ev in next_week:
                if ev["id"] not in seen_ids:
                    seen_ids.add(ev["id"])
                    all_events.append(ev)
        except Exception as e:
            sys.stderr.write(f"Error scraping next week: {e}\n")
            
    print(json.dumps(all_events))

if __name__ == "__main__":
    main()
