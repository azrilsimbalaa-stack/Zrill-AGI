import fs from "fs";
import path from "path";
import zlib from "zlib";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.resolve(__dirname, "../public");

function createPng(width, height, isMaskable = false) {
  // Generate RGBA buffer
  const rawData = Buffer.alloc(height * (1 + width * 4));

  const cx = width / 2;
  const cy = height / 2;
  const r = Math.min(width, height) / 2;

  let pos = 0;
  for (let y = 0; y < height; y++) {
    rawData[pos++] = 0; // Filter type: None
    for (let x = 0; x < width; x++) {
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Background gradient (Dark navy to dark slate)
      const grad = y / height;
      let red = Math.round(6 + 8 * (1 - grad));
      let green = Math.round(11 + 16 * grad);
      let blue = Math.round(20 + 25 * grad);
      let alpha = 255;

      // Outer glow / circle
      const safeRadius = isMaskable ? r * 0.75 : r * 0.88;
      if (dist < safeRadius) {
        // Emerald & Cyan Candlestick Bar elements in center
        const relX = (x - cx) / safeRadius; // -1 to 1
        const relY = (y - cy) / safeRadius; // -1 to 1

        // Candle 1 (Red Pullback): relX around -0.45
        if (relX >= -0.52 && relX <= -0.38 && relY >= -0.2 && relY <= 0.45) {
          red = 244; green = 63; blue = 94; // #f43f5e
        }
        // Candle 1 wick
        if (relX >= -0.46 && relX <= -0.44 && relY >= -0.4 && relY <= 0.6) {
          red = 244; green = 63; blue = 94;
        }

        // Candle 2 (Green Reversal): relX around -0.15
        if (relX >= -0.22 && relX <= -0.08 && relY >= -0.35 && relY <= 0.35) {
          red = 16; green = 185; blue = 129; // #10b981
        }
        // Candle 2 wick
        if (relX >= -0.16 && relX <= -0.14 && relY >= -0.55 && relY <= 0.55) {
          red = 16; green = 185; blue = 129;
        }

        // Candle 3 (Emerald Expansion): relX around 0.15
        if (relX >= 0.08 && relX <= 0.22 && relY >= -0.55 && relY <= 0.25) {
          red = 16; green = 185; blue = 129; // #10b981
        }
        // Candle 3 wick
        if (relX >= 0.14 && relX <= 0.16 && relY >= -0.75 && relY <= 0.45) {
          red = 16; green = 185; blue = 129;
        }

        // Candle 4 (Cyan ATH Break): relX around 0.45
        if (relX >= 0.38 && relX <= 0.52 && relY >= -0.7 && relY <= 0.05) {
          red = 56; green = 189; blue = 248; // #38bdf8
        }
        // Candle 4 wick
        if (relX >= 0.44 && relX <= 0.46 && relY >= -0.85 && relY <= 0.25) {
          red = 56; green = 189; blue = 248;
        }

        // Upward Trendline Curve (Golden yellow)
        const trendY = 0.5 - Math.pow((relX + 0.6) / 1.2, 1.4) * 1.1;
        if (Math.abs(relY - trendY) < 0.045 && relX >= -0.65 && relX <= 0.55) {
          red = 251; green = 191; blue = 36; // #fbbf24
        }
      }

      rawData[pos++] = red;
      rawData[pos++] = green;
      rawData[pos++] = blue;
      rawData[pos++] = alpha;
    }
  }

  // Compress IDAT chunk
  const compressed = zlib.deflateSync(rawData);

  // PNG Signature
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR Chunk
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth: 8
  ihdr[9] = 6; // Color type: RGBA
  ihdr[10] = 0; // Compression: deflate
  ihdr[11] = 0; // Filter: standard
  ihdr[12] = 0; // Interlace: none

  const ihdrChunk = makeChunk("IHDR", ihdr);
  const idatChunk = makeChunk("IDAT", compressed);
  const iendChunk = makeChunk("IEND", Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function makeChunk(type, data) {
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);

  const typeBuf = Buffer.from(type, "ascii");
  const crcData = Buffer.concat([typeBuf, data]);

  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcData), 0);

  return Buffer.concat([length, typeBuf, data, crc]);
}

// CRC32 implementation
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c >>> 0;
}

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

// Generate all standard PWA assets
fs.writeFileSync(path.join(publicDir, "pwa-192x192.png"), createPng(192, 192, false));
fs.writeFileSync(path.join(publicDir, "pwa-512x512.png"), createPng(512, 512, false));
fs.writeFileSync(path.join(publicDir, "pwa-maskable-512x512.png"), createPng(512, 512, true));
fs.writeFileSync(path.join(publicDir, "apple-touch-icon.png"), createPng(180, 180, false));
fs.writeFileSync(path.join(publicDir, "favicon.ico"), createPng(64, 64, false));

console.log("Successfully generated all compliant PWA PNG & ICO icon assets in /public!");
