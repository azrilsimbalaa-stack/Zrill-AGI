# Zrill AI Android Wrapper - Panduan Build Gradle

Aplikasi ini adalah Android WebView Wrapper performa tinggi yang memuat terminal web secara instan dalam **Immersive Fullscreen Mode** (Status bar & Navigation bar tersembunyi total).

## Fitur Utama Wrapper
1. **Full Immersive Mode**: Status bar dan navigation bar disembunyikan secara total dengan auto-hide saat kembali dari background.
2. **Short Edges Notch Support**: Menggunakan cutout mode `shortEdges` agar tampilan halaman web masuk ke area poni/notch secara penuh.
3. **Optimasi Zoom**: Pinch-to-zoom dimatikan total (`builtInZoomControls=false`, `displayZoomControls=false`, `setSupportZoom=false`) dengan viewport auto-fit.
4. **Kompatibilitas Penuh**: Mendukung Cookie accept, JS, LocalStorage, SessionStorage, IndexedDB, Geolocation, WebRTC (akses Kamera/Audio), WebSockets, Web Notification, dan HTML5 File Chooser untuk upload/download.
5. **Screen Awake**: Menggunakan flag `FLAG_KEEP_SCREEN_ON` agar layar ponsel tetap menyala saat memantau grafik harga realtime.
6. **Double Tap Back to Exit**: Mencegah penutupan tidak sengaja dengan navigasi tombol Back di home-screen yang mewajibkan pengetukan dua kali untuk keluar.
7. **External Scheme Handler**: Otomatis membuka aplikasi bawaan ponsel untuk skema `mailto:`, `tel:`, `whatsapp:` (wa), dan tautan eksternal `target="_blank"`.

---

## Persyaratan Sistem
1. **Java Development Kit (JDK)**: Versi 17 (Rekomendasi)
2. **Android SDK & Build-Tools**: Sesuai target SDK 34 (Android 14)

---

## Cara Build APK Menggunakan Gradle

### 1. Masuk ke direktori Android
Buka terminal Anda, lalu arahkan ke folder `android`:
```bash
cd android
```

### 2. Berikan izin eksekusi untuk `gradlew` (Khusus Linux / macOS)
```bash
chmod +x gradlew
```

### 3. Jalankan Kompilasi Build

#### Di Linux / macOS:
```bash
./gradlew assembleDebug
```

#### Di Windows:
```cmd
gradlew.bat assembleDebug
```

### 4. Lokasi Output APK
Setelah build berhasil, file APK hasil kompilasi yang siap dipasang di HP Android berada di direktori:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## Signing Configuration (Debug Key)
Kompilasi build di atas menggunakan konfigurasi debug signing otomatis yang disediakan oleh Gradle SDK. Kunci penandatanganan debug (`debug.keystore`) dibuat otomatis oleh Gradle di direktori home pengguna (`~/.android/debug.keystore`) untuk mempermudah pemasangan langsung di semua perangkat Android tanpa perlu konfigurasi keystore manual.

Jika ingin melakukan penandatanganan rilis (Release Signing) untuk Play Store, Anda cukup membuat keystore rilis menggunakan Java Keytool:
```bash
keytool -genkey -v -keystore zrill_release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias zrill
```
Lalu hubungkan file keystore rilis tersebut di blok `signingConfigs` pada `android/app/build.gradle`.
