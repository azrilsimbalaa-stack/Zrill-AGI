/* ==========================================
   BACKEND BAWAAN AI STUDIO - ADMIN PANEL SCRIPT (NO FIREBASE / NO IMPORTS)
   ========================================== */

const ADMIN_EMAILS = [
  "azrilsimbalaa@gmail.com",
  "mirzasimbala1@gmail.com"
];

let adminEmail = "";

/* ==========================================
   AUTHENTICATION CHECK & INITIALIZATION
   ========================================== */
document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('unauthorizedOverlay');
  const main = document.getElementById('adminMainContent');

  try {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      const u = JSON.parse(userStr);
      if (u.email && ADMIN_EMAILS.includes(u.email.toLowerCase())) {
        adminEmail = u.email.toLowerCase();
        if (overlay) overlay.style.display = 'none';
        if (main) main.style.display = 'block';
        loadAdminDashboardData();
        return;
      }
    }
  } catch (e) {}

  // Unauthorized
  if (overlay) overlay.style.display = 'flex';
  if (main) main.style.display = 'none';
});

/* ==========================================
   LOAD DASHBOARD DATA FROM AI STUDIO BACKEND
   ========================================== */
async function loadAdminDashboardData() {
  try {
    const res = await fetch('/api/admin/dashboard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Gagal memuat data admin');
    }

    // Render Stats
    document.getElementById('statTotalUsers').textContent = (data.stats.totalUsers || 0).toString();
    document.getElementById('statBannedUsers').textContent = (data.stats.bannedUsers || 0).toString();
    document.getElementById('statActiveCodes').textContent = (data.stats.activeCodes || 0).toString();
    document.getElementById('statUsedCodes').textContent = (data.stats.usedCodes || 0).toString();

    // Render Access Codes Table
    renderAccessCodesTable(data.accessCodes || []);

    // Render Users Table
    renderUsersTable(data.users || []);

    // Render Admin Logs Table
    renderLogsTable(data.adminLogs || []);

  } catch (err) {
    showToast(err.message || 'Gagal terhubung ke backend AI Studio', 'error');
  }
}

/* ==========================================
   RENDER ACCESS CODES TABLE
   ========================================== */
function renderAccessCodesTable(codes) {
  const tbody = document.getElementById('accessCodesTableBody');
  if (!tbody) return;

  if (!codes || codes.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:#94a3b8;">Belum ada kode akses yang dibuat.</td></tr>';
    return;
  }

  const now = Date.now();
  let html = '';

  // Sort newest first
  codes.sort((a, b) => b.created_at - a.created_at);

  codes.forEach(c => {
    const isRevoked = c.is_revoked === true;
    const isExpired = c.expires_at && now > c.expires_at;
    const isUsed = c.is_used === true;

    let badgeHtml = '<span class="badge badge-active">Aktif</span>';
    if (isRevoked) {
      badgeHtml = '<span class="badge badge-expired">Revoked</span>';
    } else if (isExpired) {
      badgeHtml = '<span class="badge badge-expired">Expired</span>';
    } else if (isUsed) {
      badgeHtml = '<span class="badge badge-used">Terpakai (Bound)</span>';
    }

    const expDateStr = c.expires_at ? new Date(c.expires_at).toLocaleDateString('id-ID', {
      day: 'numeric', month: 'short', year: 'numeric'
    }) : 'Tanpa batas';

    html += `
      <tr>
        <td style="font-family:monospace; font-weight:700; color:#38bdf8; font-size:14px;">${c.code}</td>
        <td>${c.label || '-'}</td>
        <td>${badgeHtml}</td>
        <td>${c.used_by_device ? `<code style="font-size:11px; color:#a78bfa;">${c.used_by_device}</code>` : '-'}</td>
        <td>${expDateStr}</td>
        <td>
          <button class="btn-action btn-copy" onclick="copyToClipboard('${c.code}')">Copy</button>
          ${isUsed ? `<button class="btn-action btn-unbind" onclick="unbindDevice('${c.code}', '${c.used_by_device}')">Unbind Device</button>` : ''}
          ${!isRevoked ? `<button class="btn-action btn-revoke" onclick="revokeAccessCode('${c.code}')">Revoke</button>` : ''}
        </td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

/* ==========================================
   RENDER USERS TABLE
   ========================================== */
function renderUsersTable(users) {
  const tbody = document.getElementById('usersTableBody');
  if (!tbody) return;

  if (!users || users.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px; color:#94a3b8;">Belum ada user login sosial.</td></tr>';
    return;
  }

  let html = '';
  // Sort newest first
  users.sort((a, b) => b.created_at - a.created_at);

  users.forEach(u => {
    const isBanned = u.is_banned === true;
    const createdStr = u.created_at ? new Date(u.created_at).toLocaleDateString('id-ID') : '-';

    let activeUntilStr = "Selamanya (Admin)";
    if (u.role !== 'admin') {
      if (u.active_until) {
        const isExpired = Date.now() > u.active_until;
        activeUntilStr = new Date(u.active_until).toLocaleDateString('id-ID');
        if (isExpired) {
          activeUntilStr += ' <span style="color:#ef4444; font-size:11px; font-weight:bold;">(Expired)</span>';
        } else {
          activeUntilStr += ' <span style="color:#22c55e; font-size:11px; font-weight:bold;">(Aktif)</span>';
        }
      } else {
        activeUntilStr = "Belum Diatur";
      }
    }

    html += `
      <tr>
        <td style="font-weight:600; color:#f1f5f9;">${u.email}</td>
        <td><span class="badge" style="background:rgba(139, 92, 246, 0.2); color:#c4b5fd;">${u.role || 'user'}</span></td>
        <td>${isBanned ? '<span class="badge badge-banned">Banned</span>' : '<span class="badge badge-active">Active</span>'}</td>
        <td>${activeUntilStr}</td>
        <td>${createdStr}</td>
        <td>
          ${isBanned ?
            `<button class="btn-action btn-unban" onclick="toggleBanUser('${u.email}', false)">Unban</button>` :
            `<button class="btn-action btn-ban" onclick="toggleBanUser('${u.email}', true)">Ban</button>`
          }
          ${u.role !== 'admin' ? `
            <button class="btn-action btn-unbind" style="background:rgba(34,197,94,0.15); color:#22c55e;" onclick="addActiveDays('${u.email}')">+ Hari</button>
            <button class="btn-action btn-revoke" onclick="revokeUserAccess('${u.email}')">Revoke</button>
            <button class="btn-action btn-revoke" style="background:rgba(239,68,68,0.3);" onclick="deleteUser('${u.email}')">Hapus</button>
          ` : ''}
        </td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

/* ==========================================
   RENDER ADMIN LOGS TABLE
   ========================================== */
function renderLogsTable(logs) {
  const tbody = document.getElementById('logsTableBody');
  if (!tbody) return;

  if (!logs || logs.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:20px; color:#94a3b8;">Belum ada log aktivitas admin.</td></tr>';
    return;
  }

  let html = '';
  logs.forEach(log => {
    const timeStr = new Date(log.timestamp).toLocaleString('id-ID');
    html += `
      <tr>
        <td style="color:#94a3b8;">${timeStr}</td>
        <td style="font-weight:bold; color:#a78bfa;">${log.admin_email}</td>
        <td><span class="badge" style="background:rgba(56,189,248,0.15); color:#38bdf8;">${log.action}</span></td>
        <td style="font-family:monospace; color:#f1f5f9;">${log.target}</td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
}

/* ==========================================
   GENERATE ACCESS CODE
   ========================================== */
window.generateNewAccessCode = async function () {
  const daysSelect = document.getElementById('genDurationSelect');
  const labelInput = document.getElementById('genLabelInput');

  const days = parseInt(daysSelect ? daysSelect.value : '30', 10);
  const label = labelInput ? labelInput.value.trim() : '';

  try {
    const res = await fetch('/api/admin/generate-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, days, label })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal membuat kode');

    if (labelInput) labelInput.value = '';

    copyToClipboard(data.codeRecord.code);
    showToast(`Kode Akses ${data.codeRecord.code} Berhasil Dibuat & Di-copy!`, 'success');
    loadAdminDashboardData();

  } catch (err) {
    showToast(err.message, 'error');
  }
};

/* ==========================================
   REVOKE CODE & UNBIND DEVICE
   ========================================== */
window.revokeAccessCode = async function (code) {
  if (!confirm(`Yakin ingin mencabut (revoke) kode akses ${code}?`)) return;

  try {
    const res = await fetch('/api/admin/revoke-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, code })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal me-revoke kode');

    showToast(`Kode ${code} berhasil di-revoke.`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.unbindDevice = async function (code, deviceId) {
  if (!confirm(`Unbind device ${deviceId} dari kode ${code}?`)) return;

  try {
    const res = await fetch('/api/admin/unbind-device', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, code, deviceId })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal unbind device');

    showToast(`Device berhasil di-unbind dari kode ${code}`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

/* ==========================================
   USERS MANAGEMENT (BAN / UNBAN / DELETE / EXTEND)
   ========================================== */
window.toggleBanUser = async function (targetEmail, isBanned) {
  const actionText = isBanned ? "Banned" : "Unbanned";
  if (!confirm(`Yakin ingin ${actionText} user ${targetEmail}?`)) return;

  try {
    const res = await fetch('/api/admin/toggle-ban-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, targetEmail, isBanned })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal merubah status ban user');

    showToast(`User ${targetEmail} berhasil di-${actionText}`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.deleteUser = async function (targetEmail) {
  if (!confirm(`Yakin ingin HAPUS user ${targetEmail} secara permanen dari database?`)) return;

  try {
    const res = await fetch('/api/admin/delete-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, targetEmail })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal menghapus user');

    showToast(`User ${targetEmail} berhasil dihapus`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.addActiveDays = async function (targetEmail) {
  const daysStr = prompt(`Masukkan jumlah hari tambahan untuk user ${targetEmail}:`, "30");
  if (!daysStr) return;
  const days = parseInt(daysStr, 10);
  if (isNaN(days) || days <= 0) {
    showToast("Jumlah hari tidak valid", "error");
    return;
  }

  try {
    const res = await fetch('/api/admin/add-active-days', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, targetEmail, days })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal menambah masa aktif');

    showToast(`Berhasil menambah +${days} hari untuk ${targetEmail}`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

window.revokeUserAccess = async function (targetEmail) {
  if (!confirm(`Revoke / cabut hak akses instan untuk user ${targetEmail}? (Status masa aktif akan langsung expired)`)) return;

  try {
    const res = await fetch('/api/admin/revoke-user-access', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminEmail, targetEmail })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Gagal revoke akses user');

    showToast(`Akses untuk ${targetEmail} berhasil dicabut (expired)`, 'success');
    loadAdminDashboardData();
  } catch (err) {
    showToast(err.message, 'error');
  }
};

/* ==========================================
   CLIPBOARD UTILITY
   ========================================== */
window.copyToClipboard = function (text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text);
    showToast(`Kode ${text} berhasil di-copy ke Clipboard!`, 'info');
  } else {
    showToast(`Kode: ${text}`, 'info');
  }
};

/* ==========================================
   TOAST NOTIFICATION UTILITY
   ========================================== */
function showToast(message, type = 'info') {
  const existing = document.getElementById('zrill-toast');
  if (existing) existing.remove();

  const colors = {
    success: { bg: 'rgba(34, 197, 94, 0.15)', border: '#22c55e', text: '#86efac' },
    error:   { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#fca5a5' },
    info:    { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#c4b5fd' }
  };
  const c = colors[type] || colors.info;

  const toast = document.createElement('div');
  toast.id = 'zrill-toast';
  toast.textContent = message;
  toast.style.cssText = [
    'position:fixed',
    'top:24px',
    'left:50%',
    'transform:translateX(-50%) translateY(-20px)',
    'background:' + c.bg,
    'border:1px solid ' + c.border,
    'color:' + c.text,
    'padding:12px 22px',
    'border-radius:14px',
    'font-size:13px',
    'font-weight:500',
    'backdrop-filter:blur(20px)',
    '-webkit-backdrop-filter:blur(20px)',
    'box-shadow:0 10px 40px rgba(0,0,0,0.6)',
    'z-index:99999',
    'opacity:0',
    'transition:all 0.35s cubic-bezier(0.16,1,0.3,1)',
    'max-width:90%',
    'text-align:center',
    'pointer-events:none',
    'font-family:inherit'
  ].join(';');

  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(-20px)';
    setTimeout(() => { toast.remove(); }, 400);
  }, 2800);
}
