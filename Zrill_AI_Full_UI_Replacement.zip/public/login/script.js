/* =========================================================================
   ZRILL AI - AUTHENTICATION SCRIPT (LOGIN & REGISTER - NAMA + PASSWORD)
   ========================================================================= */

// Check existing session on load (Auto Redirect to Terminal if already logged in)
document.addEventListener("DOMContentLoaded", async () => {
  const isLoginPage = window.location.pathname.includes("login.html") || window.location.pathname.endsWith("/login");
  const token = localStorage.getItem("token");

  if (isLoginPage && token) {
    try {
      const res = await fetch("/api/auth/session", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.user && data.user.status === "approved") {
          window.location.href = "/";
          return;
        }
      }
    } catch (e) {
      // offline or server busy
    }
  }

  // Bind Form Submit for Login Page
  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const nameInput = document.getElementById("loginName");
      const passInput = document.getElementById("loginPassword");
      const btn = document.getElementById("btnLogin");
      const btnText = document.getElementById("btnLoginText");

      if (!nameInput || !passInput) return;
      const name = nameInput.value.trim();
      const password = passInput.value;

      if (!name || !password) {
        showToast("Nama dan Password wajib diisi!", "error");
        return;
      }

      setLoading(btn, btnText, true, "Memeriksa Akun...");

      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, password })
        });

        const data = await res.json();

        if (!res.ok) {
          if (data.status === "pending") {
            showToast("Tunggu persetujuan admin", "warn");
          } else {
            showToast(data.error || "Nama atau password salah!", "error");
          }
          setLoading(btn, btnText, false, "Masuk");
          return;
        }

        // Save session in localStorage
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));

        try {
          if (window.parent && window.parent !== window) {
            window.parent.postMessage({ type: "ZRIL_LOGIN_SUCCESS", token: data.token, user: data.user }, "*");
          }
        } catch (e) {}

        showToast(`Selamat datang, ${data.user.displayName || data.user.name}! Masuk ke Terminal...`, "success");

        setTimeout(() => {
          window.location.href = "/";
        }, 500);
      } catch (err) {
        setLoading(btn, btnText, false, "Masuk");
        showToast("Gagal terhubung ke server. Periksa koneksi internet Anda.", "error");
      }
    });
  }

  // Bind Form Submit for Register Page
  const registerForm = document.getElementById("registerForm");
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const nameInput = document.getElementById("regName");
      const passInput = document.getElementById("regPassword");
      const confirmInput = document.getElementById("regConfirmPassword");
      const btn = document.getElementById("btnRegister");
      const btnText = document.getElementById("btnRegisterText");

      if (!nameInput || !passInput || !confirmInput) return;
      const name = nameInput.value.trim();
      const password = passInput.value;
      const confirmPassword = confirmInput.value;

      if (!name || !password || !confirmPassword) {
        showToast("Semua kolom formulir wajib diisi!", "error");
        return;
      }

      if (name.length < 3) {
        showToast("Nama minimal harus 3 karakter!", "error");
        return;
      }

      if (password.length < 6) {
        showToast("Password minimal harus 6 karakter!", "error");
        return;
      }

      if (password !== confirmPassword) {
        showToast("Konfirmasi password tidak cocok!", "error");
        return;
      }

      setLoading(btn, btnText, true, "Mendaftarkan...");

      try {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, password, confirmPassword })
        });

        const data = await res.json();

        if (!res.ok) {
          showToast(data.error || "Pendaftaran gagal. Nama mungkin sudah terdaftar.", "error");
          setLoading(btn, btnText, false, "Daftar");
          return;
        }

        showToast("Pendaftaran berhasil! Tunggu persetujuan admin.", "success");

        setTimeout(() => {
          window.location.href = "login.html";
        }, 1500);
      } catch (err) {
        setLoading(btn, btnText, false, "Daftar");
        showToast("Gagal menghubungi server pendaftaran.", "error");
      }
    });
  }
});

// Loading Button Helper
function setLoading(btn, btnText, isLoading, text) {
  if (!btn) return;
  btn.disabled = isLoading;
  if (btnText) btnText.textContent = text;
  if (isLoading) {
    btn.style.opacity = "0.7";
    btn.style.cursor = "not-allowed";
  } else {
    btn.style.opacity = "1";
    btn.style.cursor = "pointer";
  }
}

// Toast Notification matching Aurora glassmorphism theme
function showToast(message, type = "info") {
  const existing = document.getElementById("zrill-toast");
  if (existing) existing.remove();

  const colors = {
    success: { bg: "rgba(34, 197, 94, 0.16)", border: "#22c55e", text: "#86efac", shadow: "rgba(34, 197, 94, 0.35)" },
    error:   { bg: "rgba(239, 68, 68, 0.16)", border: "#ef4444", text: "#fca5a5", shadow: "rgba(239, 68, 68, 0.35)" },
    warn:    { bg: "rgba(251, 191, 36, 0.16)", border: "#fbbf24", text: "#fde68a", shadow: "rgba(251, 191, 36, 0.35)" },
    info:    { bg: "rgba(139, 92, 246, 0.16)", border: "#8b5cf6", text: "#c4b5fd", shadow: "rgba(139, 92, 246, 0.35)" }
  };

  const c = colors[type] || colors.info;

  const toast = document.createElement("div");
  toast.id = "zrill-toast";
  toast.textContent = message;
  toast.style.cssText = [
    "position: fixed",
    "top: 24px",
    "left: 50%",
    "transform: translateX(-50%) translateY(-20px)",
    "background: " + c.bg,
    "border: 1px solid " + c.border,
    "color: " + c.text,
    "padding: 12px 20px",
    "border-radius: 14px",
    "font-size: 13px",
    "font-weight: 700",
    "letter-spacing: -0.01em",
    "backdrop-filter: blur(24px)",
    "-webkit-backdrop-filter: blur(24px)",
    "box-shadow: 0 10px 40px rgba(0,0,0,0.8), 0 0 24px " + c.shadow,
    "z-index: 99999",
    "opacity: 0",
    "transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
    "max-width: 90%",
    "text-align: center",
    "pointer-events: none",
    "font-family: inherit"
  ].join(";");

  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.style.opacity = "1";
    toast.style.transform = "translateX(-50%) translateY(0)";
  });

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateX(-50%) translateY(-15px)";
    setTimeout(() => { toast.remove(); }, 350);
  }, 3500);
}
