/* ==========================================
   BACKEND BAWAAN AI STUDIO - ACCESS CODE & DEVICE BINDING (NO IMPORTS)
   ========================================== */

/* ==========================================
   DEVICE FINGERPRINT / DEVICE ID GENERATOR
   ========================================== */
async function generateDeviceId() {
  const storedId = localStorage.getItem('zrill_device_id');
  if (storedId) return storedId;

  const rawInfo = [
    navigator.userAgent,
    navigator.language,
    screen.width + 'x' + screen.height,
    screen.colorDepth,
    Intl.DateTimeFormat().resolvedOptions().timeZone,
    navigator.hardwareConcurrency || 4
  ].join('|');

  // Fast Hash String
  let hash = 0;
  for (let i = 0; i < rawInfo.length; i++) {
    const char = rawInfo.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  const deviceId = 'dev_' + Math.abs(hash).toString(36) + '_' + Date.now().toString(36);
  localStorage.setItem('zrill_device_id', deviceId);
  return deviceId;
}

/* ==========================================
   SUBMIT ACCESS CODE TO AI STUDIO BACKEND
   ========================================== */
window.handleAccessCodeSubmit = async function (e) {
  if (e && e.preventDefault) e.preventDefault();

  const input = document.getElementById('accessCodeInput');
  const btn = document.getElementById('accessBtn');
  const btnText = document.getElementById('accessBtnText');

  if (!input) return;
  const rawCode = input.value.trim().toUpperCase();

  if (!rawCode) {
    showToast('Masukkan kode akses terlebih dahulu', 'error');
    return;
  }

  btn.classList.add('loading');
  btn.disabled = true;
  if (btnText) btnText.textContent = 'Memverifikasi...';

  try {
    const deviceId = await generateDeviceId();

    // Call AI Studio Express Backend API
    const res = await fetch('/api/auth/access-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code: rawCode,
        deviceId,
        userAgent: navigator.userAgent,
        screen: `${screen.width}x${screen.height}`,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      })
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || 'Verifikasi kode akses gagal.');
    }

    // Save Session in localStorage
    localStorage.setItem('token', data.token);
    localStorage.setItem('user', JSON.stringify({
      uid: data.user.uid,
      email: data.user.email,
      name: data.user.name,
      role: 'user',
      accessCode: rawCode,
      isCodeAuth: true
    }));

    // Post Message to Parent Window (Main Zrill AI App)
    if (window.parent) {
      window.parent.postMessage({
        type: 'ZRIL_LOGIN_SUCCESS',
        token: data.token,
        user: data.user
      }, '*');
    }

    showToast('Otorisasi Perangkat Berhasil! Masuk ke Terminal...', 'success');

    setTimeout(() => {
      if (window.parent && window.parent !== window) {
        try { window.parent.location.reload(); } catch(e) {}
      }
      window.location.href = '/';
    }, 300);

  } catch (error) {
    btn.classList.remove('loading');
    btn.disabled = false;
    if (btnText) btnText.textContent = 'Masuk Terminal';
    showToast(error.message || 'Gagal memverifikasi kode akses', 'error');
  }
};

/* ==========================================
   TOAST NOTIFICATION UTILITY
   ========================================== */
function showToast(message, type = 'info') {
  const existing = document.getElementById('zrill-toast');
  if (existing) existing.remove();

  const colors = {
    success: { bg: 'rgba(34, 197, 94, 0.15)', border: '#22c55e', text: '#86efac' },
    error:   { bg: 'rgba(239, 68, 68, 0.15)', border: '#ef4444', text: '#fca5a5' },
    info:    { bg: 'rgba(139, 92, 246, 0.15)', border: '#8b5cf6', text: '#c4b5fd' }
  };
  const c = colors[type] || colors.info;

  const toast = document.createElement('div');
  toast.id = 'zrill-toast';
  toast.textContent = message;
  toast.style.cssText = [
    'position:fixed',
    'top:24px',
    'left:50%',
    'transform:translateX(-50%) translateY(-20px)',
    'background:' + c.bg,
    'border:1px solid ' + c.border,
    'color:' + c.text,
    'padding:12px 22px',
    'border-radius:14px',
    'font-size:13px',
    'font-weight:500',
    'backdrop-filter:blur(20px)',
    '-webkit-backdrop-filter:blur(20px)',
    'box-shadow:0 10px 40px rgba(0,0,0,0.6)',
    'z-index:9999',
    'opacity:0',
    'transition:all 0.35s cubic-bezier(0.16,1,0.3,1)',
    'max-width:90%',
    'text-align:center',
    'pointer-events:none',
    'font-family:inherit'
  ].join(';');

  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(-20px)';
    setTimeout(() => { toast.remove(); }, 400);
  }, 2800);
}
